import { createStore, combineReducers, applyMiddleware } from 'redux';
import { createForms } from 'react-redux-form';
import { Kirks, InitialKirk } from './kirks';
import { Inputs, InitialInput } from './inputs';
// import { kirkNum, InitialKirkNum } from './kirkNum';
import { Auth } from './auth';
import thunk from 'redux-thunk';
import logger from 'redux-logger';

export const ConfigureStore = () => {
  const store = createStore(
    combineReducers({
      // these are reducer functions, not values
      // 'cause not Dishes() but Dishes
      kirks: Kirks,
      auth: Auth,
      inputs: Inputs,
      // kirkNum,
      ...createForms({
        kirk: InitialKirk,
        input: InitialInput,
        // kirkNum: InitialKirkNum,
      }),
    }),
    applyMiddleware(thunk, logger)
  );
  return store;
};
