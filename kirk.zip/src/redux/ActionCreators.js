import * as ActionTypes from './ActionTypes';
// import { DISHES } from '../shared/dishes';
import { baseUrl } from '../shared/baseUrl';

export const kirksLoading = () => ({
  type: ActionTypes.KIRKS_LOADING,
});

export const inputsLoading = () => ({
  type: ActionTypes.INPUTS_LOADING,
});

export const proInputsLoading = () => ({
  // pro
  type: ActionTypes.PROINPUTS_LOADING,
});

export const fetchKirks = () => (dispatch) => {
  // dispatch(kirksLoading(true));

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return (
    fetch(baseUrl + 'kirks', {
      method: 'GET',
      // body: JSON.stringify(newKirk),
      headers: {
        'Content-Type': 'application/json',
        Authorization: bearer,
      },
      credentials: 'same-origin',
    })
      // return (

      //   fetch(baseUrl + 'kirks')
      //     // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            console.log('response.ng. response was ', response);
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          console.log('server does not respond');
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((kirks) => dispatch(addKirks(kirks)))
      // .catch((error) => dispatch(kirksFailed(error.message)))
      .catch((error) =>
        // dispatch(kirksFailed('Please Sign Up or Log In from the top menu.'))
        dispatch(
          kirksFailed(
            <div className="container main">
              <div>
                <span
                  style={{
                    fontSize: 18,
                    color: 'darkgrey',
                    fontWeight: 'bold',
                  }}
                >
                  &gt; Please SIGN UP or LOG IN from the top menu.
                </span>
              </div>
            </div>
          )
        )
      )
  );
};

export const fetchInputs = () => (dispatch) => {
  // dispatch(kirksLoading(true));

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return (
    //baseUrl = 'http://localhost:3000/'
    fetch(baseUrl + 'inputs', {
      method: 'GET',
      // body: JSON.stringify(newKirk),
      headers: {
        'Content-Type': 'application/json',
        Authorization: bearer,
      },
      credentials: 'same-origin',
    })
      // return (

      //   fetch(baseUrl + 'kirks')
      //     // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            console.log('response.ng. response was ', response);
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          console.log('server does not respond');
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((inputs) => dispatch(addInputs(inputs)))
      // .catch((error) => dispatch(inputsFailed(error.message)))
      .catch((error) =>
        dispatch(
          inputsFailed(
            <div className="container main">
              <div>
                <span
                  style={{
                    fontSize: 18,
                    color: 'darkgrey',
                    fontWeight: 'bold',
                  }}
                >
                  &gt; Please SIGN UP or LOG IN from the top menu.
                </span>
              </div>
            </div>
          )
        )
      )
  );
};

export const fetchProInputs = () => (dispatch) => {
  // dispatch(kirksLoading(true));

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return (
    //baseUrl = 'http://localhost:3000/'
    fetch(baseUrl + 'proInputs', {
      method: 'GET',
      // body: JSON.stringify(newKirk),
      headers: {
        'Content-Type': 'application/json',
        Authorization: bearer,
      },
      credentials: 'same-origin',
    })
      // return (

      //   fetch(baseUrl + 'kirks')
      //     // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            console.log('response.ng. response was ', response);
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          console.log('server does not respond');
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((proInputs) => dispatch(addProInputs(proInputs)))
      .catch((error) =>
        dispatch(
          proInputsFailed(
            <div className="container main">
              <div>
                <span
                  style={{
                    fontSize: 18,
                    color: 'darkgrey',
                    fontWeight: 'bold',
                  }}
                >
                  &gt; Please SIGN UP or LOG IN from the top menu.
                </span>
              </div>
            </div>
          )
        )
      )
  );
};

export const kirksFailed = (errmess) => ({
  type: ActionTypes.KIRKS_FAILED,
  payload: errmess,
});

export const inputsFailed = (errmess) => ({
  type: ActionTypes.INPUTS_FAILED,
  payload: errmess,
});

export const proInputsFailed = (errmess) => ({
  type: ActionTypes.PROINPUTS_FAILED,
  payload: errmess,
});

export const addKirks = (kirks) => ({
  type: ActionTypes.ADD_KIRKS,
  payload: kirks,
});

export const addInputs = (inputs) => ({
  type: ActionTypes.ADD_INPUTS,
  payload: inputs,
});

export const addProInputs = (proInputs) => ({
  type: ActionTypes.ADD_PROINPUTS,
  payload: proInputs,
});

export const addKirk = (kirk) => ({
  type: ActionTypes.ADD_KIRK,
  payload: kirk,
});

export const addInput = (input) => ({
  type: ActionTypes.ADD_INPUT,
  payload: input,
});

export const addProInput = (proInput) => ({
  type: ActionTypes.ADD_PROINPUT,
  payload: proInput,
});

export const editedKirk = (kirk) => ({
  type: ActionTypes.EDITED_KIRK,
  payload: kirk,
});

export const editedInput = (input) => ({
  type: ActionTypes.EDITED_INPUT,
  payload: input,
});

export const editedProInput = (proInput) => ({
  type: ActionTypes.EDITED_PROINPUT,
  payload: proInput,
});

export const postKirk = (
  date,
  place,
  person,
  subject,
  reason,
  how,
  data,
  work,
  news,
  buy,
  utilities,
  // symptoms,
  events,
  health,
  foods,
  invests
) => (dispatch) => {
  const newKirk = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    how: how,
    data: data,
    work: work,
    news: news,
    buy: buy,
    utilities: utilities,
    // symptoms: symptoms,
    events: events,
    health: health,
    foods: foods,
    invests: invests,
  };

  if (newKirk.date !== '') {
    newKirk.date = newKirk.date;
    // else newKirk.date = new Date().toISOString();
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newKirk.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return fetch(baseUrl + 'kirks', {
    method: 'POST',
    body: JSON.stringify(newKirk),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addKirk(response));
      // alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post kirks', error.message);
      alert('Your kirk could not be posted\nError: ' + error.message);
    });
};

export const postInput = (
  date,
  place,
  person,
  subject,
  reason,
  condition,
  data,
  unit
) => (dispatch) => {
  const newInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition: condition,
    data: data,
    unit: unit,
  };

  if (newInput.date !== '') {
    newInput.date = newInput.date;
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newInput.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return fetch(baseUrl + 'inputs', {
    method: 'POST',
    body: JSON.stringify(newInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addInput(response));
      // alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post input', error.message);
      alert('Your input could not be posted\nError: ' + error.message);
    });
};

export const postProInput = (
  date,
  place,
  person,
  subject,
  reason,
  condition1,
  condition2,
  condition3,
  condition4,
  condition5,
  condition6,
  condition7,
  condition8,
  condition9,
  condition10,
  condition11,
  condition12,
  condition13,
  condition14,
  condition15,
  condition16,
  condition17,
  condition18,
  condition19,
  condition20,
  data,
  unit
) => (dispatch) => {
  const newProInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition1: condition1,
    condition2: condition2,
    condition3: condition3,
    condition4: condition4,
    condition5: condition5,
    condition6: condition6,
    condition7: condition7,
    condition8: condition8,
    condition9: condition9,
    condition10: condition10,
    condition11: condition11,
    condition12: condition12,
    condition13: condition13,
    condition14: condition14,
    condition15: condition15,
    condition16: condition16,
    condition17: condition17,
    condition18: condition18,
    condition19: condition19,
    condition20: condition20,
    data: data,
    unit: unit,
  };

  if (newProInput.date !== '') {
    newProInput.date = newProInput.date;
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newProInput.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return fetch(baseUrl + 'proInputs', {
    method: 'POST',
    body: JSON.stringify(newProInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addProInput(response));
      // alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post proInput', error.message);
      alert('Your proInput could not be posted\nError: ' + error.message);
    });
};

export const requestLogin = (creds) => {
  return {
    type: ActionTypes.LOGIN_REQUEST,
    creds,
  };
};

export const requestPwChange = (creds) => {
  return {
    type: ActionTypes.PWCHANGE_REQUEST,
    creds,
  };
};

export const requestSignup = (creds) => {
  return {
    type: ActionTypes.SIGNUP_REQUEST,
    creds,
  };
};

export const requestForgotPassword = (email) => {
  return {
    type: ActionTypes.FORGOTPW_REQUEST,
    email,
  };
};

export const receiveLogin = (response) => {
  return {
    type: ActionTypes.LOGIN_SUCCESS,
    token: response.token,
    id: response.id,
  };
};

export const receivePwChange = (response) => {
  return {
    type: ActionTypes.PWCHANGE_SUCCESS,
    token: response.token,
    id: response.id,
  };
};

export const receiveSignup = (response) => {
  return {
    type: ActionTypes.SIGNUP_SUCCESS,
    token: response.token,
  };
};

export const receiveForgotPassword = (response) => {
  return {
    type: ActionTypes.FORGOTPW_SUCCESS,
    token: response.token,
  };
};

export const loginError = (message) => {
  return {
    type: ActionTypes.LOGIN_FAILURE,
    message,
  };
};

export const pwChangeError = (message) => {
  return {
    type: ActionTypes.PWCHANGE_FAILURE,
    message,
  };
};

export const signupError = (message) => {
  return {
    type: ActionTypes.SIGNUP_FAILURE,
    message,
  };
};

export const forgotPasswordError = (message) => {
  return {
    type: ActionTypes.FORGOTPW_FAILURE,
    message,
  };
};

export const getSearchWord = (value) => {
  return {
    type: ActionTypes.SEARCH_KIRKS,
    value,
  };
};

// export const showAll = (value) => {
//   return {
//     type: ActionTypes.SHOW_ALL,
//     value,
//   };
// };

export const showMine = (value) => {
  return {
    type: ActionTypes.SHOW_MINE,
    value,
  };
};
// export const updateKirkNum = (kirkNum) => ({
//   type: ActionTypes.UPDATE_KIRKNUM,
//   payload: kirkNum,
// });

export const updateKirkNum = (kirkNum) => {
  return {
    type: ActionTypes.UPDATE_KIRKNUM,
    kirkNum,
  };
};

export const getKirkNum = (kirkNum) => (dispatch) => {
  dispatch(updateKirkNum(kirkNum));
};

// export const setKirkNum = (kirks) => ({
//   type: ActionTypes.ADD_KIRKS,
//   payload: kirks,
// });

export const loginUser = (creds) => (dispatch) => {
  // We dispatch requestLogin to kickoff the call to the API
  dispatch(requestLogin(creds));

  return (
    fetch(baseUrl + 'users/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(creds),
    })
      .then(
        (response) => {
          console.log('1');
          if (response.ok) {
            return response;
          } else {
            var error = new Error(
              'Error ' + response.status + ': ' + response.statusText
            );
            error.response = response;
            throw error;
          }
        },
        (error) => {
          console.log('2');
          throw error;
        }
      )
      .then((response) => response.json())
      .then((response) => {
        if (response.success) {
          // If login was successful, set the token in local storage
          localStorage.setItem('token', response.token);
          localStorage.setItem('creds', JSON.stringify(creds));
          localStorage.setItem('id', response.id);
          console.log('In loginUser, response.id is ', response.id);
          // Dispatch the success action
          dispatch(receiveLogin(response));
          dispatch(fetchKirks());
          dispatch(fetchInputs());
          dispatch(fetchProInputs());
        } else {
          var error = new Error('Error ' + response.status);
          error.response = response;
          throw error;
        }
      })
      // .catch((error) => dispatch(loginError(error.message)));
      .catch((error) => {
        alert('Login Error');
        dispatch(loginError(error.message));
      })
  );
};

export const pwChangeUser = (creds) => (dispatch) => {
  // We dispatch requestLogin to kickoff the call to the API
  dispatch(requestPwChange(creds));

  return fetch(baseUrl + 'users/changepassword', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(creds),
  })
    .then(
      (response) => {
        console.log('PWChange1');
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        console.log('PWChange2');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      if (response.success) {
        // If login was successful, set the token in local storage
        localStorage.setItem('token', response.token);
        localStorage.setItem('creds', JSON.stringify(creds));
        localStorage.setItem('id', response.id);
        console.log('In PWChange, response.id is ', response.id);
        // Dispatch the success action
        dispatch(receivePwChange(response));
        // window.confirm('Password changed!');
        alert('Password changed');

        dispatch(fetchKirks());
        dispatch(fetchInputs());
        dispatch(fetchProInputs());
      } else {
        // alert('Password NOT changed1. ' + response.status);
        var error = new Error('Error ' + response.status);
        error.response = response;
        throw error;
      }
    })
    .catch((error) => {
      alert('Password NOT changed. ' + error.message);
      dispatch(pwChangeError(error.message));
    });
};

export const signupUser = (creds) => (dispatch) => {
  dispatch(requestSignup(creds));

  return fetch(baseUrl + 'users/signup', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(creds),
  })
    .then(
      (response) => {
        // console.log('1');
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        // console.log('2');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      if (response.success) {
        // If login was successful, set the token in local storage
        localStorage.setItem('token', response.token);
        localStorage.setItem('creds', JSON.stringify(creds));
        localStorage.setItem('id', response.id);
        // Dispatch the success action
        dispatch(receiveSignup(response));
        dispatch(loginUser(creds));
        // dispatch(receiveLogin(response)); // Added on 2023.1.9
        // dispatch(fetchKirks());
        // dispatch(fetchInputs());
      } else {
        var error = new Error('Error ' + response.status);
        error.response = response;
        throw error;
      }
    })
    .catch((error) => {
      alert(
        'Signup failed. Username and/or Email are already in use. Please use different one(s)'
      );
      dispatch(signupError(error.message));
    });
};

export const requestLogout = () => {
  return {
    type: ActionTypes.LOGOUT_REQUEST,
  };
};

export const receiveLogout = () => {
  return {
    type: ActionTypes.LOGOUT_SUCCESS,
  };
};

// Logs the user out
export const logoutUser = () => (dispatch) => {
  dispatch(requestLogout());
  localStorage.removeItem('token');
  localStorage.removeItem('creds');
  localStorage.removeItem('id');
  // dispatch(kirksFailed('Error 401: Unauthorized'));
  // dispatch(inputsFailed('Error 401: Unauthorized')); //2023.3.12, to clear all list
  dispatch(
    kirksFailed(
      <div className="container main">
        <div>
          <span
            style={{
              fontSize: 18,
              color: 'darkgrey',
              fontWeight: 'bold',
            }}
          >
            <p>&gt; Logged out.</p>
            <p>&gt; Please SIGN UP or LOG IN from the top menu.</p>
          </span>
        </div>
      </div>
    )
  );

  dispatch(
    inputsFailed(
      <div className="container main">
        <div>
          <span
            style={{
              fontSize: 18,
              color: 'darkgrey',
              fontWeight: 'bold',
            }}
          >
            <p>&gt; Logged out.</p>
            <p>&gt; Please SIGN UP or LOG IN from the top menu.</p>
          </span>
        </div>
      </div>
    )
  );

  dispatch(
    proInputsFailed(
      <div className="container main">
        <div>
          <span
            style={{
              fontSize: 18,
              color: 'darkgrey',
              fontWeight: 'bold',
            }}
          >
            <p>&gt; Logged out.</p>
            <p>&gt; Please SIGN UP or LOG IN from the top menu.</p>
          </span>
        </div>
      </div>
    )
  );

  dispatch(receiveLogout());
};

export const updateKirk = (
  kirkId,
  date,
  place,
  person,
  subject,
  reason,
  how,
  data,
  work,
  news,
  buy,
  utilities,
  // symptoms,
  events,
  health,
  foods,
  invests
) => (dispatch) => {
  const newKirk = {
    // kirkId,
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    how: how,
    data: data,
    work: work,
    news: news,
    buy: buy,
    utilities: utilities,
    // symptoms: symptoms,
    events: events,
    health: health,
    foods: foods,
    invests: invests,
  };

  const bearer = 'Bearer ' + localStorage.getItem('token');
  // console.log('kirkId is ', kirkId);
  // console.log('newKirk is ', newKirk);
  return fetch(baseUrl + 'kirks/' + kirkId, {
    method: 'PUT',
    body: JSON.stringify(newKirk),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          console.log('response is ok on updateKirk()');
          return response;
        } else {
          // reached the server but it says something wrong.
          console.log('response is error on updateKirk()');
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((kirk) => {
      dispatch(editedKirk(kirk));
      // alert('Server response' + JSON.stringify(kirk));
    })
    .catch((error) => {
      console.log('Update kirks', error.message);
      alert('Your kirk could not be updated\nError: ' + error.message);
    });
};

export const updateInput = (
  inputId,
  date,
  place,
  person,
  subject,
  reason,
  condition,
  data,
  unit
) => (dispatch) => {
  const newInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition: condition,
    data: data,
    unit: unit,
  };

  if (newInput.date !== '') {
    newInput.date = newInput.date;
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newInput.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'inputs/' + inputId, {
    method: 'PUT',
    body: JSON.stringify(newInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          console.log('response is error on updateInput()');
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((input) => {
      dispatch(editedInput(input));
      // alert('Server response' + JSON.stringify(kirk));
    })
    .catch((error) => {
      console.log('Update input', error.message);
      alert('Your input could not be updated\nError: ' + error.message);
    });
};

export const updateProInput = (
  proInputId,
  date,
  place,
  person,
  subject,
  reason,
  condition1,
  condition2,
  condition3,
  condition4,
  condition5,
  condition6,
  condition7,
  condition8,
  condition9,
  condition10,
  condition11,
  condition12,
  condition13,
  condition14,
  condition15,
  condition16,
  condition17,
  condition18,
  condition19,
  condition20,
  data,
  unit
) => (dispatch) => {
  const newProInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition1: condition1,
    condition2: condition2,
    condition3: condition3,
    condition4: condition4,
    condition5: condition5,
    condition6: condition6,
    condition7: condition7,
    condition8: condition8,
    condition9: condition9,
    condition10: condition10,
    condition11: condition11,
    condition12: condition12,
    condition13: condition13,
    condition14: condition14,
    condition15: condition15,
    condition16: condition16,
    condition17: condition17,
    condition18: condition18,
    condition19: condition19,
    condition20: condition20,
    data: data,
    unit: unit,
  };

  if (newProInput.date !== '') {
    newProInput.date = newProInput.date;
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newProInput.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'proInputs/' + proInputId, {
    method: 'PUT',
    body: JSON.stringify(newProInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          console.log('response is error on updateProInput()');
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((proInput) => {
      dispatch(editedProInput(proInput));
      // alert('Server response' + JSON.stringify(kirk));
    })
    .catch((error) => {
      console.log('Update proInput', error.message);
      alert('Your proInput could not be updated\nError: ' + error.message);
    });
};

export const deleteKirk = (kirkId) => (dispatch) => {
  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'kirks/' + kirkId, {
    method: 'DELETE',
    headers: {
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          console.log('if in deleteKirk');
          return response;
        } else {
          console.log('else in deleteKirk');
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        console.log('error in deleteKirk');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((kirks) => {
      dispatch(addKirks(kirks));
    })
    .catch((error) => dispatch(kirksFailed(error.message)));
};

export const deleteInput = (inputId) => (dispatch) => {
  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'inputs/' + inputId, {
    method: 'DELETE',
    headers: {
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        throw error;
      }
    )
    .then((response) => response.json())
    .then((inputs) => {
      dispatch(addInputs(inputs));
    })
    .catch((error) => dispatch(inputsFailed(error.message)));
};

export const deleteProInput = (proInputId) => (dispatch) => {
  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'proInputs/' + proInputId, {
    method: 'DELETE',
    headers: {
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        throw error;
      }
    )
    .then((response) => response.json())
    .then((proInputs) => {
      dispatch(addProInputs(proInputs));
    })
    .catch((error) => dispatch(proInputsFailed(error.message)));
};

export const forgotPassword = (email) => (dispatch) => {
  // const bearer = 'Bearer ' + localStorage.getItem('token');
  dispatch(requestForgotPassword(email));
  return fetch(baseUrl + 'users/forgot-password', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // Authorization: bearer,
      'Access-Control-Allow-Origin': '*',
    },
    // header('Access-Control-Allow-Origin', '*')
    body: JSON.stringify(email),
    // credentials: 'no-cors',
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      if (response.success) {
        // Email confirmed. Then go forward to reset password.
        // localStorage.setItem('token', response.token);
        // localStorage.setItem('creds', JSON.stringify(creds));
        // localStorage.setItem('id', response.id);
        // Dispatch the success action
        dispatch(receiveForgotPassword(response));
        alert('Server response' + JSON.stringify(response));
        // dispatch(resetPassword());
      } else {
        var error = new Error('Error ' + response.status);
        error.response = response;
        throw error;
      }
    })
    .catch((error) => {
      dispatch(forgotPasswordError(error.message));
      alert('Your email could not be posted\nError: ' + error.message);
    });
  // .then((response) => {
  //   dispatch(receiveForgotPassword(response));
  //   alert('Server response' + JSON.stringify(response));
  // })
  // .catch((error) => {
  //   console.log('Forgot Password', error.message);
  //   dispatch(forgotPasswordError(error.message));
  //   alert('Your email could not be posted\nError: ' + error.message);
  // });
};
