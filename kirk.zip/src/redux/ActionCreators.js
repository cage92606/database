import * as ActionTypes from './ActionTypes';
// import { DISHES } from '../shared/dishes';
import { baseUrl } from '../shared/baseUrl';

export const kirksLoading = () => ({
  type: ActionTypes.KIRKS_LOADING,
});

export const inputsLoading = () => ({
  type: ActionTypes.INPUTS_LOADING,
});

export const fetchKirks = () => (dispatch) => {
  // dispatch(kirksLoading(true));

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return (
    fetch(baseUrl + 'kirks', {
      method: 'GET',
      // body: JSON.stringify(newKirk),
      headers: {
        'Content-Type': 'application/json',
        Authorization: bearer,
      },
      credentials: 'same-origin',
    })
      // return (

      //   fetch(baseUrl + 'kirks')
      //     // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            console.log('response.ng. response was ', response);
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          console.log('server does not respond');
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((kirks) => dispatch(addKirks(kirks)))
      .catch((error) => dispatch(kirksFailed(error.message)))
  );
};

export const fetchInputs = () => (dispatch) => {
  // dispatch(kirksLoading(true));

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return (
    fetch(baseUrl + 'inputs', {
      method: 'GET',
      // body: JSON.stringify(newKirk),
      headers: {
        'Content-Type': 'application/json',
        Authorization: bearer,
      },
      credentials: 'same-origin',
    })
      // return (

      //   fetch(baseUrl + 'kirks')
      //     // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            console.log('response.ng. response was ', response);
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          console.log('server does not respond');
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((inputs) => dispatch(addInputs(inputs)))
      .catch((error) => dispatch(inputsFailed(error.message)))
  );
};

export const kirksFailed = (errmess) => ({
  type: ActionTypes.KIRKS_FAILED,
  payload: errmess,
});

export const inputsFailed = (errmess) => ({
  type: ActionTypes.INPUTS_FAILED,
  payload: errmess,
});

export const addKirks = (kirks) => ({
  type: ActionTypes.ADD_KIRKS,
  payload: kirks,
});

export const addInputs = (inputs) => ({
  type: ActionTypes.ADD_INPUTS,
  payload: inputs,
});

export const addKirk = (kirk) => ({
  type: ActionTypes.ADD_KIRK,
  payload: kirk,
});

export const addInput = (input) => ({
  type: ActionTypes.ADD_INPUT,
  payload: input,
});

export const editedKirk = (kirk) => ({
  type: ActionTypes.EDITED_KIRK,
  payload: kirk,
});

export const editedInput = (input) => ({
  type: ActionTypes.EDITED_INPUT,
  payload: input,
});

export const postKirk = (
  date,
  place,
  person,
  subject,
  reason,
  how,
  data,
  work,
  news,
  buy,
  utilities,
  // symptoms,
  events,
  health,
  foods,
  invests
) => (dispatch) => {
  const newKirk = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    how: how,
    data: data,
    work: work,
    news: news,
    buy: buy,
    utilities: utilities,
    // symptoms: symptoms,
    events: events,
    health: health,
    foods: foods,
    invests: invests,
  };

  if (newKirk.date !== '') {
    newKirk.date = newKirk.date;
    // else newKirk.date = new Date().toISOString();
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newKirk.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return fetch(baseUrl + 'kirks', {
    method: 'POST',
    body: JSON.stringify(newKirk),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addKirk(response));
      // alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post kirks', error.message);
      alert('Your kirk could not be posted\nError: ' + error.message);
    });
};

export const postInput = (
  date,
  place,
  person,
  subject,
  reason,
  condition,
  data,
  unit
) => (dispatch) => {
  const newInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition: condition,
    data: data,
    unit: unit,
  };

  if (newInput.date !== '') {
    newInput.date = newInput.date;
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    const options = { weekday: 'short' };
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const week = today.toLocaleDateString(undefined, options);
    const hour = today.getHours();
    const minute = today.getMinutes();
    newInput.date = year.concat(
      '-',
      month,
      '-',
      day,
      ' ',
      week,
      ' ',
      hour,
      ':',
      minute
    );
  }

  const bearer = 'Bearer ' + localStorage.getItem('token');

  return fetch(baseUrl + 'inputs', {
    method: 'POST',
    body: JSON.stringify(newInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addInput(response));
      // alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post input', error.message);
      alert('Your input could not be posted\nError: ' + error.message);
    });
};

export const requestLogin = (creds) => {
  return {
    type: ActionTypes.LOGIN_REQUEST,
    creds,
  };
};

export const requestSignup = (creds) => {
  return {
    type: ActionTypes.SIGNUP_REQUEST,
    creds,
  };
};

export const receiveLogin = (response) => {
  return {
    type: ActionTypes.LOGIN_SUCCESS,
    token: response.token,
    id: response.id,
  };
};

export const receiveSignup = (response) => {
  return {
    type: ActionTypes.SIGNUP_SUCCESS,
    token: response.token,
  };
};

export const loginError = (message) => {
  return {
    type: ActionTypes.LOGIN_FAILURE,
    message,
  };
};

export const signupError = (message) => {
  return {
    type: ActionTypes.SIGNUP_FAILURE,
    message,
  };
};

export const getSearchWord = (value) => {
  return {
    type: ActionTypes.SEARCH_KIRKS,
    value,
  };
};

// export const showAll = (value) => {
//   return {
//     type: ActionTypes.SHOW_ALL,
//     value,
//   };
// };

export const showMine = (value) => {
  return {
    type: ActionTypes.SHOW_MINE,
    value,
  };
};
// export const updateKirkNum = (kirkNum) => ({
//   type: ActionTypes.UPDATE_KIRKNUM,
//   payload: kirkNum,
// });

export const updateKirkNum = (kirkNum) => {
  return {
    type: ActionTypes.UPDATE_KIRKNUM,
    kirkNum,
  };
};

export const getKirkNum = (kirkNum) => (dispatch) => {
  dispatch(updateKirkNum(kirkNum));
};

// export const setKirkNum = (kirks) => ({
//   type: ActionTypes.ADD_KIRKS,
//   payload: kirks,
// });

export const loginUser = (creds) => (dispatch) => {
  // We dispatch requestLogin to kickoff the call to the API
  dispatch(requestLogin(creds));

  return fetch(baseUrl + 'users/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(creds),
  })
    .then(
      (response) => {
        console.log('1');
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        console.log('2');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      if (response.success) {
        // If login was successful, set the token in local storage
        localStorage.setItem('token', response.token);
        localStorage.setItem('creds', JSON.stringify(creds));
        localStorage.setItem('id', response.id);
        console.log('In loginUser, response.id is ', response.id);
        // Dispatch the success action
        dispatch(receiveLogin(response));
        dispatch(fetchKirks());
        dispatch(fetchInputs());
      } else {
        var error = new Error('Error ' + response.status);
        error.response = response;
        throw error;
      }
    })
    .catch((error) => dispatch(loginError(error.message)));
};

export const signupUser = (creds) => (dispatch) => {
  dispatch(requestSignup(creds));

  return fetch(baseUrl + 'users/signup', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(creds),
  })
    .then(
      (response) => {
        // console.log('1');
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        // console.log('2');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      if (response.success) {
        // If login was successful, set the token in local storage
        localStorage.setItem('token', response.token);
        localStorage.setItem('creds', JSON.stringify(creds));
        localStorage.setItem('id', response.id);
        // Dispatch the success action
        dispatch(receiveSignup(response));
        dispatch(fetchKirks());
        dispatch(fetchInputs());
      } else {
        var error = new Error('Error ' + response.status);
        error.response = response;
        throw error;
      }
    })
    .catch((error) => dispatch(signupError(error.message)));
};

export const requestLogout = () => {
  return {
    type: ActionTypes.LOGOUT_REQUEST,
  };
};

export const receiveLogout = () => {
  return {
    type: ActionTypes.LOGOUT_SUCCESS,
  };
};

// Logs the user out
export const logoutUser = () => (dispatch) => {
  dispatch(requestLogout());
  localStorage.removeItem('token');
  localStorage.removeItem('creds');
  localStorage.removeItem('id');
  dispatch(kirksFailed('Error 401: Unauthorized'));
  dispatch(receiveLogout());
};

export const updateKirk = (
  kirkId,
  date,
  place,
  person,
  subject,
  reason,
  how,
  data,
  work,
  news,
  buy,
  utilities,
  // symptoms,
  events,
  health,
  foods,
  invests
) => (dispatch) => {
  const newKirk = {
    // kirkId,
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    how: how,
    data: data,
    work: work,
    news: news,
    buy: buy,
    utilities: utilities,
    // symptoms: symptoms,
    events: events,
    health: health,
    foods: foods,
    invests: invests,
  };

  const bearer = 'Bearer ' + localStorage.getItem('token');
  console.log('kirkId is ', kirkId);
  console.log('newKirk is ', newKirk);
  return fetch(baseUrl + 'kirks/' + kirkId, {
    method: 'PUT',
    body: JSON.stringify(newKirk),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          console.log('response is ok on updateKirk()');
          return response;
        } else {
          // reached the server but it says something wrong.
          console.log('response is error on updateKirk()');
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((kirk) => {
      dispatch(editedKirk(kirk));
      // alert('Server response' + JSON.stringify(kirk));
    })
    .catch((error) => {
      console.log('Update kirks', error.message);
      alert('Your kirk could not be updated\nError: ' + error.message);
    });
};

export const updateInput = (
  inputId,
  date,
  place,
  person,
  subject,
  reason,
  condition,
  data,
  unit
) => (dispatch) => {
  const newInput = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    condition: condition,
    data: data,
    unit: unit,
  };

  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'inputs/' + inputId, {
    method: 'PUT',
    body: JSON.stringify(newInput),
    headers: {
      'Content-Type': 'application/json',
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          console.log('response is error on updateInput()');
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((input) => {
      dispatch(editedInput(input));
      // alert('Server response' + JSON.stringify(kirk));
    })
    .catch((error) => {
      console.log('Update input', error.message);
      alert('Your input could not be updated\nError: ' + error.message);
    });
};

export const deleteKirk = (kirkId) => (dispatch) => {
  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'kirks/' + kirkId, {
    method: 'DELETE',
    headers: {
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          console.log('if in deleteKirk');
          return response;
        } else {
          console.log('else in deleteKirk');
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        console.log('error in deleteKirk');
        throw error;
      }
    )
    .then((response) => response.json())
    .then((kirks) => {
      dispatch(addKirks(kirks));
    })
    .catch((error) => dispatch(kirksFailed(error.message)));
};

export const deleteInput = (inputId) => (dispatch) => {
  const bearer = 'Bearer ' + localStorage.getItem('token');
  return fetch(baseUrl + 'inputs/' + inputId, {
    method: 'DELETE',
    headers: {
      Authorization: bearer,
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          var error = new Error(
            'Error ' + response.status + ': ' + response.statusText
          );
          error.response = response;
          throw error;
        }
      },
      (error) => {
        throw error;
      }
    )
    .then((response) => response.json())
    .then((inputs) => {
      dispatch(addInputs(inputs));
    })
    .catch((error) => dispatch(inputsFailed(error.message)));
};
