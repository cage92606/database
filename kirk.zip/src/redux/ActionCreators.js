import * as ActionTypes from './ActionTypes';
// import { DISHES } from '../shared/dishes';
import { baseUrl } from '../shared/baseUrl';

export const kirksLoading = () => ({
  type: ActionTypes.KIRKS_LOADING,
});

export const fetchKirks = () => (dispatch) => {
  dispatch(kirksLoading(true));

  return (
    fetch(baseUrl + 'kirks')
      // handling responses from the server
      .then(
        (response) => {
          if (response.ok) {
            return response;
          } else {
            var error = new Error(
              `Error ${response.status} : ${response.statusText}`
            );
            error.response = response;
            throw error;
          }
        },
        // if you even didn't get response from the server
        (error) => {
          var errmess = new Error(error.message);
          throw errmess;
        }
      )
      .then((response) => response.json())
      .then((kirks) => dispatch(addKirks(kirks)))
      .catch((error) => dispatch(kirksFailed(error.message)))
  );
};

export const kirksFailed = (errmess) => ({
  type: ActionTypes.KIRKS_FAILED,
  payload: errmess,
});

export const addKirks = (kirks) => ({
  type: ActionTypes.ADD_KIRKS,
  payload: kirks,
});

export const addKirk = (kirk) => ({
  type: ActionTypes.ADD_KIRK,
  payload: kirk,
});

export const postKirk = (date, place, person, subject, reason, how) => (
  dispatch
) => {
  const newKirk = {
    date: date,
    place: place,
    person: person,
    subject: subject,
    reason: reason,
    how: how,
  };

  if (newKirk.date !== '') {
    newKirk.date = newKirk.date;
    // else newKirk.date = new Date().toISOString();
  } else {
    const today = new Date();
    const date = today.toLocaleDateString();
    // const time = today.toLocaleTimeString()
    const month = date.split('/')[0];
    const day = date.split('/')[1];
    const year = date.split('/')[2];
    const hour = today.getHours();
    const minute = today.getMinutes();
    newKirk.date = year.concat('-', month, '-', day, ' ', hour, ':', minute);
  }

  return fetch(baseUrl + 'kirks', {
    method: 'POST',
    body: JSON.stringify(newKirk),
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'same-origin',
  })
    .then(
      (response) => {
        if (response.ok) {
          return response;
        } else {
          // reached the server but it says something wrong.
          var error = new Error(
            `Error ${response.status} : ${response.statusText}`
          );
          error.response = response;
          throw error;
        }
      },
      // if you even didn't get response from the server
      (error) => {
        var errmess = new Error(error.message);
        throw errmess;
      }
    )
    .then((response) => response.json())
    .then((response) => {
      dispatch(addKirk(response));
      alert('Server response' + JSON.stringify(response));
    })
    .catch((error) => {
      console.log('Post kirks', error.message);
      alert('Your kirk could not be posted\nError: ' + error.message);
    });
};
