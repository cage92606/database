import * as ActionTypes from './ActionTypes';

export const InitialKirk = {
  date: '',
  place: '',
  person: '',
  subject: '',
  reason: '',
  how: '',
  data: '',
  work: false,
  news: false,
  buy: false,
  utilities: false,
  // symptoms: false,
  events: false,
  health: false,
  foods: false,
  invests: false,
};

export const Kirks = (
  state = {
    errMess: null,
    kirks: [],
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.ADD_KIRKS:
      return {
        ...state,
        isLoading: false,
        errMess: null,
        kirks: action.payload,
      };

    case ActionTypes.KIRKS_FAILED:
      return {
        ...state,
        isLoading: false,
        errMess: action.payload,
        kirks: [],
      };

    case ActionTypes.ADD_KIRK:
      var kirk = action.payload;
      return {
        ...state,
        kirks: state.kirks.concat(kirk),
      };

    case ActionTypes.EDITED_KIRK:
      // var kirk = action.payload;
      const index = state.kirks.findIndex((curr) => {
        return curr._id === action.payload._id;
      });
      state.kirks[index] = action.payload;
      return {
        ...state,
        isLoading: false,
        errMess: null,
        kirks: state.kirks,
      };

    default:
      return state;
  }
};
