import * as ActionTypes from './ActionTypes';

export const InitialInput = {
  date: '',
  place: '',
  person: '',
  subject: '',
  reason: '',
  condition: '',
  data: '',
  unit: '',
};

export const Inputs = (
  state = {
    errMess: null,
    inputs: [],
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.ADD_INPUTS:
      return {
        ...state,
        isLoading: false,
        errMess: null,
        inputs: action.payload,
      };

    case ActionTypes.INPUTS_FAILED:
      return {
        ...state,
        isLoading: false,
        errMess: action.payload,
        inputs: [],
      };

    case ActionTypes.ADD_INPUT:
      var input = action.payload;
      return {
        ...state,
        inputs: state.inputs.concat(input),
      };

    case ActionTypes.EDITED_INPUT:
      const index = state.inputs.findIndex((curr) => {
        return curr._id === action.payload._id;
      });
      state.inputs[index] = action.payload;
      return {
        ...state,
        isLoading: false,
        errMess: null,
        inputs: state.inputs,
      };

    default:
      return state;
  }
};
