export const KIRKS_LOADING = 'KIRKS_LOADING';
export const ADD_KIRK = 'ADD_KIRK';
export const ADD_KIRKS = 'ADD_KIRKS';
export const KIRKS_FAILED = 'KIRKS_FAILED';
