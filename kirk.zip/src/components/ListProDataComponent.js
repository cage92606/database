/* eslint-disable react/jsx-pascal-case */
import React, { useEffect, Fragment } from 'react';
import { useState } from 'react';
import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  Table,
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';
import { CSVLink, CSVDownload } from 'react-csv';
import Pagination from './Pagination';

function RenderProInputTable({
  proInput,
  deleteProInput,
  updateProInput,
  resetProInputForm,
  auth,
}) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    if (window.confirm('OK to change data?')) {
      updateProInput(
        proInput._id,
        value.date,
        value.place,
        value.person,
        value.subject,
        value.reason,
        value.condition1,
        value.condition2,
        value.condition3,
        value.condition4,
        value.condition5,
        value.condition6,
        value.condition7,
        value.condition8,
        value.condition9,
        value.condition10,
        value.condition11,
        value.condition12,
        value.condition13,
        value.condition14,
        value.condition15,
        value.condition16,
        value.condition17,
        value.condition18,
        value.condition19,
        value.condition20,
        value.data,
        value.unit
      );
      resetProInputForm();
    }
  };

  return (
    <tr>
      <Modal
        isOpen={isOpen}
        toggle={toggleModal}
        size="lg"
        style={{ maxWidth: '1000px', width: '100%' }}
      >
        <ModalHeader toggle={toggleModal}>Update ProInput</ModalHeader>
        <ModalBody>
          <Form onSubmit={handleSubmit} model="input">
            <Row className="form-group mb-2">
              <Label htmlFor="date">date</Label>
              <Col sm={10}>
                <Control.text
                  model=".date"
                  id="date"
                  name="date"
                  defaultValue={proInput.date}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="place">place</Label>
              <Col sm={10}>
                <Control.text
                  model=".place"
                  id="place"
                  name="place"
                  defaultValue={proInput.place}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="person">person</Label>
              <Col sm={10}>
                <Control.text
                  model=".person"
                  id="person"
                  name="person"
                  defaultValue={proInput.person}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="subject">subject</Label>
              <Col sm={10}>
                <Control.text
                  model=".subject"
                  id="subject"
                  name="subject"
                  defaultValue={proInput.subject}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="reason">reason</Label>
              <Col sm={10}>
                <Control.textarea
                  model=".reason"
                  id="reason"
                  name="reason"
                  defaultValue={proInput.reason}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label>condition</Label>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition1"
                  model=".condition1"
                  id="condition1"
                  name="condition1"
                  defaultValue={proInput.condition1}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition2"
                  model=".condition2"
                  id="condition2"
                  name="condition2"
                  defaultValue={proInput.condition2}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition3"
                  model=".condition3"
                  id="condition3"
                  name="condition3"
                  defaultValue={proInput.condition3}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition4"
                  model=".condition4"
                  id="condition4"
                  name="condition4"
                  defaultValue={proInput.condition4}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition5"
                  model=".condition5"
                  id="condition5"
                  name="condition5"
                  defaultValue={proInput.condition5}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Col sm={2}>
                <Control.text
                  htmlFor="condition6"
                  model=".condition6"
                  id="condition6"
                  name="condition6"
                  defaultValue={proInput.condition6}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition7"
                  model=".condition7"
                  id="condition7"
                  name="condition7"
                  defaultValue={proInput.condition7}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition8"
                  model=".condition8"
                  id="condition8"
                  name="condition8"
                  defaultValue={proInput.condition8}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition9"
                  model=".condition9"
                  id="condition9"
                  name="condition9"
                  defaultValue={proInput.condition9}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition10"
                  model=".condition10"
                  id="condition10"
                  name="condition10"
                  defaultValue={proInput.condition10}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Col sm={2}>
                <Control.text
                  htmlFor="condition11"
                  model=".condition11"
                  id="condition11"
                  name="condition11"
                  defaultValue={proInput.condition11}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition12"
                  model=".condition12"
                  id="condition12"
                  name="condition12"
                  defaultValue={proInput.condition12}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition13"
                  model=".condition13"
                  id="condition13"
                  name="condition13"
                  defaultValue={proInput.condition13}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition14"
                  model=".condition14"
                  id="condition14"
                  name="condition14"
                  defaultValue={proInput.condition14}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition15"
                  model=".condition15"
                  id="condition15"
                  name="condition15"
                  defaultValue={proInput.condition15}
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Col sm={2}>
                <Control.text
                  htmlFor="condition16"
                  model=".condition16"
                  id="condition16"
                  name="condition16"
                  defaultValue={proInput.condition16}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition17"
                  model=".condition17"
                  id="condition17"
                  name="condition17"
                  defaultValue={proInput.condition17}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition18"
                  model=".condition18"
                  id="condition18"
                  name="condition18"
                  defaultValue={proInput.condition18}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition19"
                  model=".condition19"
                  id="condition19"
                  name="condition19"
                  defaultValue={proInput.condition19}
                  className="form-control"
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor="condition20"
                  model=".condition20"
                  id="condition20"
                  name="condition20"
                  defaultValue={proInput.condition20}
                  className="form-control"
                />
              </Col>
            </Row>

            <Row className="form-group mb-2">
              <Label htmlFor="data">data</Label>
              <Col sm={4}>
                <Control.text
                  model=".data"
                  id="data"
                  name="data"
                  defaultValue={proInput.data}
                  className="form-control"
                />
              </Col>
              {/* </Row>
              <Row className="form-group mb-2"> */}
              <Label htmlFor="unit">unit</Label>
              <Col sm={4}>
                <Control.text
                  model=".unit"
                  id="unit"
                  name="unit"
                  defaultValue={proInput.unit}
                  className="form-control"
                />
              </Col>
            </Row>
            <Button type="submit" value="submit" color="primary">
              Submit
            </Button>
          </Form>
        </ModalBody>
      </Modal>

      <td className="sticky-td">
        {auth.id === proInput.user ? (
          <Button outline color="primary" onClick={toggleModal}>
            <span className="fa fa-edit"></span>
          </Button>
        ) : (
          <Button outline color="secondary">
            <span className="fa fa-edit"></span>
          </Button>
        )}
      </td>
      <td>{proInput.date}</td>
      <td>
        {proInput.place.indexOf('http') === 0 ||
        proInput.place.indexOf('/') === 0 ? (
          proInput.place ? (
            proInput.place.indexOf('http') === 0 ? (
              <a href={proInput.place} target="_blank" rel="noreferrer">
                <span className="fa fa-link"></span>
              </a>
            ) : (
              <a
                href={`file:${proInput.place}`}
                target="_blank"
                rel="noreferrer"
              >
                <span className="fa fa-folder-open"></span>
              </a>
            )
          ) : (
            ''
          )
        ) : (
          <span>{proInput.place}</span>
        )}
      </td>
      <td>{proInput.person}</td>
      <td>
        <b>{proInput.subject}</b>
      </td>
      <td>{proInput.reason}</td>
      <td>{proInput.condition1}</td>
      <td>{proInput.condition2}</td>
      <td>{proInput.condition3}</td>
      <td>{proInput.condition4}</td>
      <td>{proInput.condition5}</td>
      <td>{proInput.condition6}</td>
      <td>{proInput.condition7}</td>
      <td>{proInput.condition8}</td>
      <td>{proInput.condition9}</td>
      <td>{proInput.condition10}</td>
      <td>{proInput.condition11}</td>
      <td>{proInput.condition12}</td>
      <td>{proInput.condition13}</td>
      <td>{proInput.condition14}</td>
      <td>{proInput.condition15}</td>
      <td>{proInput.condition16}</td>
      <td>{proInput.condition17}</td>
      <td>{proInput.condition18}</td>
      <td>{proInput.condition19}</td>
      <td>{proInput.condition20}</td>
      <td>
        {proInput.data.indexOf('http') === 0 ? (
          proInput.data ? (
            <a href={proInput.data} target="_blank" rel="noreferrer">
              {/* <span className="fa fa-link" color="pink"></span> */}
              <span className="fa fa-link" style={{ color: 'crimson' }} />
            </a>
          ) : (
            ''
          )
        ) : (
          <code>{proInput.data}</code>
        )}
      </td>
      <td>{proInput.unit}</td>
      <td className="sticky-td">
        {auth.id === proInput.user ? (
          <Button
            outline
            color="danger"
            onClick={() => {
              if (window.confirm('Are you sure?')) deleteProInput(proInput._id);
            }}
          >
            <span className="fa fa-times"></span>
          </Button>
        ) : (
          <span></span>
        )}
      </td>
    </tr>
  );
}

export let proInput_num;
console.log('proInput_num in ListProData is ', proInput_num);

export default function ListData(props) {
  // const searchDone = (display) => {
  //   setDisplay(display);
  // };

  const [isDateAscending, setIsDateAscending] = useState(true);
  const [isPlaceAscending, setIsPlaceAscending] = useState(true);
  const [isPersonAscending, setIsPersonAscending] = useState(true);
  const [isSubjectAscending, setIsSubjectAscending] = useState(true);
  const [isReasonAscending, setIsReasonAscending] = useState(true);
  const [isConditionAscending, setIsConditionAscending] = useState(true);
  const [isDataAscending, setIsDataAscending] = useState(true);
  const [isUnitAscending, setIsUnitAscending] = useState(true);
  const [isAnyFieldBtnPushed, setIsAnyFieldBtnPushed] = useState(false);
  const [isKeywordChanged, setIsKeywordChanged] = useState(true);

  const [isDateBtnPushed, setIsDateBtnPushed] = useState(false);
  const [isPlaceBtnPushed, setIsPlaceBtnPushed] = useState(false);
  const [isPersonBtnPushed, setIsPersonBtnPushed] = useState(false);
  const [isSubjectBtnPushed, setIsSubjectBtnPushed] = useState(false);
  const [isReasonBtnPushed, setIsReasonBtnPushed] = useState(false);
  const [isConditionBtnPushed, setIsConditionBtnPushed] = useState(false);
  const [isDataBtnPushed, setIsDataBtnPushed] = useState(false);
  const [isUnitBtnPushed, setIsUnitBtnPushed] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [proInputListPerPage] = useState(1000);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    console.log('you are in keyword');
    // console.log('setIsKeywordChanged is now ', setIsKeywordChanged);

    const keywordAndArray = props.keyword.split('|');
    var keywords = [];
    var exwords = [];
    for (let k = 0; k < keywordAndArray.length; k++) {
      let keywordArray = keywordAndArray[k].split(/(\s+)/);
      var keywords_temp = [];
      var exwords_temp = [];
      let j = 0;
      let m = 0;
      for (let i = 0; i < keywordArray.length; i++) {
        if ((keywordArray[i] !== ' ') & (keywordArray[i] !== '')) {
          if (keywordArray[i].split('')[0] === '!') {
            exwords_temp[m] = keywordArray[i]
              .toLowerCase()
              .split('')
              .splice(1)
              .join('');
            m = m + 1;
          } else {
            keywords_temp[j] = keywordArray[i].toLowerCase();
            j = j + 1;
          }
        }
      }
      keywords.push(keywords_temp); // OR演算子で分割した各々のキーワード群
      exwords.push(exwords_temp);
    }
    console.log(`keywords is ${keywords}`);
    console.log(`exwords is ${exwords}`);
    var foundProInputs = [];
    for (let i = 0; i < keywords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs_temp = props.proInputs.filter((curr) => {
        const test = keywords[i].map(
          (keyword) =>
            curr.date.toLowerCase().includes(keyword) ||
            curr.place.toLowerCase().includes(keyword) ||
            curr.person.toLowerCase().includes(keyword) ||
            curr.subject.toLowerCase().includes(keyword) ||
            curr.reason.toLowerCase().includes(keyword) ||
            curr.condition1.toLowerCase().includes(keyword) ||
            curr.condition2.toLowerCase().includes(keyword) ||
            curr.condition3.toLowerCase().includes(keyword) ||
            curr.condition4.toLowerCase().includes(keyword) ||
            curr.condition5.toLowerCase().includes(keyword) ||
            curr.condition6.toLowerCase().includes(keyword) ||
            curr.condition7.toLowerCase().includes(keyword) ||
            curr.condition8.toLowerCase().includes(keyword) ||
            curr.condition9.toLowerCase().includes(keyword) ||
            curr.condition10.toLowerCase().includes(keyword) ||
            curr.condition11.toLowerCase().includes(keyword) ||
            curr.condition12.toLowerCase().includes(keyword) ||
            curr.condition13.toLowerCase().includes(keyword) ||
            curr.condition14.toLowerCase().includes(keyword) ||
            curr.condition15.toLowerCase().includes(keyword) ||
            curr.condition16.toLowerCase().includes(keyword) ||
            curr.condition17.toLowerCase().includes(keyword) ||
            curr.condition18.toLowerCase().includes(keyword) ||
            curr.condition19.toLowerCase().includes(keyword) ||
            curr.condition20.toLowerCase().includes(keyword) ||
            curr.data.toLowerCase().includes(keyword) ||
            curr.unit.toLowerCase().includes(keyword)
        );
        return test.every((logic) => logic === true);
      });
      foundProInputs = foundProInputs.concat(foundProInputs_temp);
      //     }
    }
    var foundProInputs2 = [];
    for (let i = 0; i < exwords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs2_temp = foundProInputs.filter((curr) => {
        const test = exwords[i].map(
          (exword) =>
            curr.date.toLowerCase().includes(exword) ||
            curr.place.toLowerCase().includes(exword) ||
            curr.person.toLowerCase().includes(exword) ||
            curr.subject.toLowerCase().includes(exword) ||
            curr.reason.toLowerCase().includes(exword) ||
            curr.condition1.toLowerCase().includes(exword) ||
            curr.condition2.toLowerCase().includes(exword) ||
            curr.condition3.toLowerCase().includes(exword) ||
            curr.condition4.toLowerCase().includes(exword) ||
            curr.condition5.toLowerCase().includes(exword) ||
            curr.condition6.toLowerCase().includes(exword) ||
            curr.condition7.toLowerCase().includes(exword) ||
            curr.condition8.toLowerCase().includes(exword) ||
            curr.condition9.toLowerCase().includes(exword) ||
            curr.condition10.toLowerCase().includes(exword) ||
            curr.condition11.toLowerCase().includes(exword) ||
            curr.condition12.toLowerCase().includes(exword) ||
            curr.condition13.toLowerCase().includes(exword) ||
            curr.condition14.toLowerCase().includes(exword) ||
            curr.condition15.toLowerCase().includes(exword) ||
            curr.condition16.toLowerCase().includes(exword) ||
            curr.condition17.toLowerCase().includes(exword) ||
            curr.condition18.toLowerCase().includes(exword) ||
            curr.condition19.toLowerCase().includes(exword) ||
            curr.condition20.toLowerCase().includes(exword) ||
            curr.data.toLowerCase().includes(exword) ||
            curr.unit.toLowerCase().includes(exword)
        );
        return test.every((logic) => logic === false);
      });
      foundProInputs2 = foundProInputs2.concat(foundProInputs2_temp);
      //     }
    }

    // 2023.5.5
    // Field buttons didn't work upon listing search result because it is always
    // overwritten by the sort here. So added this condition to not execute it
    // if one of the buttons are being pushed

    console.log('isAnyFieldBtnPushed is ', isAnyFieldBtnPushed);
    console.log('isPlaceAscending is ', isPlaceAscending);

    if (
      // isDateAscending &
      // isPlaceAscending &
      // isPersonAscending &
      // isSubjectAscending &
      // isReasonAscending &
      // isConditionAscending &
      // isDataAscending &
      // isUnitAscending
      !isAnyFieldBtnPushed
    ) {
      foundProInputs2.sort((a, b) => {
        return a._id.localeCompare(b._id);
      });
    } else {
      if (isDateBtnPushed) {
        const conv = (kirkDate) => {
          let day = kirkDate
            .split(' ')
            .find((element) => element.includes('-'));
          if (day) {
            const len = day.split('-')[0].length;
            const firstnumber = day.split('-')[0];
            const secondnumber = day.split('-')[1];
            const thirdnumber = day.split('-')[2];

            if (len === 1 || len === 2) {
              // In the case of like "25-2023-1"
              if (thirdnumber === '1')
                day = `January-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '2')
                day = `Febrary-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '3')
                day = `March-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '4')
                day = `April-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '5')
                day = `May-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '6')
                day = `June-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '7')
                day = `July-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '8')
                day = `August-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '9')
                day = `September-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '10')
                day = `October-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '11')
                day = `November-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '12')
                day = `December-${secondnumber}-${firstnumber}`;
            }
          }

          const time = kirkDate
            .split(' ')
            .find((element) => element.includes(':'));

          return day;
        };
        if (isDateAscending === false) {
          foundProInputs2.sort((a, b) => {
            // return a.date.localeCompare(b.date);
            return new Date(conv(a.date)) - new Date(conv(b.date));
          });
        } else {
          foundProInputs2.sort((a, b) => {
            // return a.date.localeCompare(b.date).reverse();
            return new Date(conv(b.date)) - new Date(conv(a.date));
          });
        }
      } else if (isPlaceBtnPushed) {
        if (isPlaceAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.place.localeCompare(b.place);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.place.localeCompare(a.place);
          });
        }
        // setIsPlaceBtnPushed(false);
      } else if (isPersonBtnPushed) {
        if (isPersonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.person.localeCompare(b.person);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.person.localeCompare(a.person);
          });
        }
        // setIsPersonBtnPushed(false);
      } else if (isSubjectBtnPushed) {
        if (isSubjectAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.subject.localeCompare(b.subject);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.subject.localeCompare(a.subject);
          });
        }
        // setIsSubjectBtnPushed(false);
      } else if (isReasonBtnPushed) {
        if (isReasonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.reason.localeCompare(b.reason);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.reason.localeCompare(a.reason);
          });
        }
      } else if (isConditionBtnPushed) {
        if (isConditionAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition.localeCompare(b.condition);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition.localeCompare(a.condition);
          });
        }
      } else if (isDataBtnPushed) {
        if (isDataAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.data.localeCompare(b.data);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.data.localeCompare(a.data);
          });
        }
      } else if (isUnitBtnPushed) {
        if (isUnitAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.unit.localeCompare(b.unit);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.unit.localeCompare(a.unit);
          });
        }
      }
    }

    function onlyUnique(value, index, array) {
      return array.indexOf(value) === index;
    }
    foundProInputs2 = foundProInputs2.filter(onlyUnique);

    const csvData = foundProInputs2;

    const proInputList = foundProInputs2.map((proInput) => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    const toggleDateSort = async () => {
      setIsDateAscending(!isDateAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(true);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const togglePlaceSort = () => {
      setIsPlaceAscending(!isPlaceAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(true);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const togglePersonSort = () => {
      setIsPersonAscending(!isPersonAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(true);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleSubjectSort = () => {
      setIsSubjectAscending(!isSubjectAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(true);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleReasonSort = () => {
      setIsReasonAscending(!isReasonAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(true);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleConditionSort = () => {
      setIsConditionAscending(!isConditionAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(true);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleDataSort = () => {
      setIsDataAscending(!isDataAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(true);
      setIsUnitBtnPushed(false);
    };

    const toggleUnitSort = () => {
      setIsUnitAscending(!isUnitAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsConditionBtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(true);
    };

    proInput_num = proInputList.length;
    console.log('number of inputs found is ', proInput_num);

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <div className="row">
                  <div className="col-6">
                    <h5>{proInput_num} items</h5>
                  </div>
                  <div className="col-6">
                    <CSVLink
                      data={csvData}
                      className="fa fa-arrow-down"
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped>
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleDateSort}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={togglePlaceSort}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={togglePersonSort}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleSubjectSort}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleReasonSort}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c1
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c2
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c3
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c4
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c5
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c6
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c7
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c8
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c9
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleDataSort}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleUnitSort}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else if (props.proInputs !== null) {
    console.log('you are in proInputs');
    console.log('keyword is ', props.keyword);

    const proInputList = props.proInputs.map((proInput) => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    const toggleDateSort = async () => {
      const conv = (kirkDate) => {
        let day = kirkDate.split(' ').find((element) => element.includes('-'));
        if (day) {
          const len = day.split('-')[0].length;
          const firstnumber = day.split('-')[0];
          const secondnumber = day.split('-')[1];
          const thirdnumber = day.split('-')[2];

          if (len === 1 || len === 2) {
            // In the case of like "25-2023-1"
            if (thirdnumber === '1')
              day = `January-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '2')
              day = `Febrary-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '3')
              day = `March-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '4')
              day = `April-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '5')
              day = `May-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '6')
              day = `June-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '7')
              day = `July-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '8')
              day = `August-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '9')
              day = `September-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '10')
              day = `October-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '11')
              day = `November-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '12')
              day = `December-${secondnumber}-${firstnumber}`;
          }
        }

        const time = kirkDate
          .split(' ')
          .find((element) => element.includes(':'));

        return day;
      };

      if (isDateAscending === false) {
        props.proInputs.sort((a, b) => {
          // return a.date.localeCompare(b.date);
          return new Date(conv(a.date)) - new Date(conv(b.date));
        });
      } else {
        props.proInputs.sort((a, b) => {
          // return a.date.localeCompare(b.date).reverse();
          return new Date(conv(b.date)) - new Date(conv(a.date));
        });
      }
      setIsDateAscending(!isDateAscending);
    };

    const togglePlaceSort = () => {
      setIsPlaceAscending(!isPlaceAscending);

      if (isPlaceAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.place.localeCompare(b.place);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.place.localeCompare(b.place).reverse();
        });
      }
    };

    const togglePersonSort = () => {
      setIsPersonAscending(!isPersonAscending);

      if (isPersonAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.person.localeCompare(b.person);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.person.localeCompare(b.person).reverse();
        });
      }
    };

    const toggleSubjectSort = () => {
      setIsSubjectAscending(!isSubjectAscending);

      if (isSubjectAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.subject.localeCompare(b.subject);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.subject.localeCompare(b.subject).reverse();
        });
      }
    };

    const toggleReasonSort = () => {
      setIsReasonAscending(!isReasonAscending);

      if (isReasonAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.reason.localeCompare(b.reason);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.reason.localeCompare(b.reason).reverse();
        });
      }
    };

    const toggleConditionSort = () => {
      setIsConditionAscending(!isConditionAscending);

      if (isConditionAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition.localeCompare(b.condition);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition.localeCompare(b.condition).reverse();
        });
      }
    };

    const toggleDataSort = () => {
      setIsDataAscending(!isDataAscending);

      if (isDataAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.data.localeCompare(b.data);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.data.localeCompare(b.data).reverse();
        });
      }
    };

    const toggleUnitSort = () => {
      setIsUnitAscending(!isUnitAscending);

      if (isUnitAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.unit.localeCompare(b.unit);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.unit.localeCompare(b.unit).reverse();
        });
      }
    };

    proInput_num = proInputList.length;
    console.log('number of proInputs found is ', proInput_num);
    const csvData = props.proInputs;

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div class="table-responsive">
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <div className="row">
                  <div className="col-6">
                    <h5>{proInput_num} items</h5>
                  </div>
                  <div className="col-6">
                    <CSVLink
                      data={csvData}
                      className="fa fa-arrow-down"
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped class="table">
                  {/* <Table bordered responsive hover striped class="tableFixHead"> */}
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleDateSort}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={togglePlaceSort}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={togglePersonSort}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleSubjectSort}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleReasonSort}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c01
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c02
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c03
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c04
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c05
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c06
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c07
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c08
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c09
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleConditionSort}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleDataSort}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color="secondary"
                          onClick={toggleUnitSort}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else {
    return <div></div>;
  }
}
