import React, { Component, useState } from 'react';
import ListKirk from './ListKirkComponent';

export default function Search({ findKirks }) {
  const [keyword, setKeyword] = useState('');

  const handleChange = (event) => {
    setKeyword(event.target.value);
    findKirks(event.target.value);
  };
  return (
    <div>
      {/* <form onSubmit={handleSubmit}> */}
      <form>
        <input
          type="text"
          id="keyword"
          name="keyword"
          value={keyword}
          // onChange={() => findKirks()}
          onChange={handleChange}
          placeholder="Search"
        />
        {/* <input type="submit" value="Submit" /> */}
      </form>
    </div>
  );
}
