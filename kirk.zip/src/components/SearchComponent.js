import React, { Component, useState, Fragment } from 'react';
import ListKirk from './ListKirkComponent';
// import { XIcon } from '@heroicons/react/solid';
// import { Input } from 'semantic-ui-react';

export default function Search({ findKirks }) {
  const [keyword, setKeyword] = useState('');
  // const [value, setValue] = useState('')

  const handleChange = (event) => {
    setKeyword(event.target.value);
    findKirks(event.target.value);
  };
  return (
    <Fragment>
      {/* <form onSubmit={handleSubmit}> */}
      <form>
        <input
          // icon="search"
          type="search"
          id="keyword"
          name="keyword"
          value={keyword}
          // onChange={() => findKirks()}
          onChange={handleChange}
          placeholder="Search..."
        />
        {/* <input type="submit" value="Submit" /> */}
        {/* {keyword && <span className="h-5">x</span>} */}
      </form>
    </Fragment>
  );
}
