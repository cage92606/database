import React, { Component, useState } from 'react';
import ListKirk from './ListKirkComponent';
// const Search = () => {
//   return (
//     // <Row className="form mb-2">
//     //   {/* <Label htmlFor="data" md={2}>
//     //       data
//     //     </Label> */}
//     //   <Col md={10}>
//     //     <Control.text
//     //       model=".search"
//     //       id="search"
//     //       name="search"
//     //       placeholder="search?"
//     //       className="form-control"
//     //     />
//     //   </Col>
//     // </Row>

//     <form>
//       {/* <label>
//         Name: */}
//       <input type="text" name="name" placeholder="Search" />
//       {/* </label> */}
//       {/* <input type="submit" value="Submit" /> */}
//     </form>
//   );
// };

export default function Search({ findKirks }) {
  const [keyword, setKeyword] = useState('');

  const handleChange = (event) => {
    setKeyword(event.target.value);
    findKirks(event.target.value);
    // this.props.getSearchWord(event.target.value);
    // getKeyword(keyword);
    // console.log('value is:', event.target.value);
  };
  return (
    <div>
      {/* <form onSubmit={handleSubmit}> */}
      <form>
        <input
          type="text"
          id="keyword"
          name="keyword"
          value={keyword}
          // onChange={() => findKirks()}
          onChange={handleChange}
          placeholder="Search"
        />
        {/* <input type="submit" value="Submit" /> */}
      </form>
    </div>
  );
}

// class Search extends Component {
//   constructor(props) {
//     super(props);
//     this.state = { value: '' };
//     this.state = { foundKirks: '' };
//     this.handleChange = this.handleChange.bind(this);
//     // this.handleSubmit = this.handleSubmit.bind(this);
//   }

//   handleChange(event) {
//     this.setState({ value: event.target.value });
//     console.log('handleChange called with value: ', this.state.value);
//     // console.log('props: ', this.props.kirks);
//     // this.props.searchKirks({
//     //   keyword: this.state.value,
//     // });

//     const foundKirks = this.props.kirks.filter((curr) =>
//       curr.subject.includes(this.state.value)
//     );
//     this.setState({ foundKirks: foundKirks });
//     console.log(foundKirks);
//   }

// handleSubmit(event) {
//   // alert('A kirk was submitted: ' + this.state.value);
//   event.preventDefault();
// }

//   render() {
//     return (
//       <div>
//         <form onSubmit={this.handleSubmit}>
//           <input
//             type="text"
//             value={this.state.value}
//             // onChange={this.handleChange}
//             onChange={() => this.props.findKirks(this.state.value)}
//             placeholder="Search"
//           />
//           {/* <input type="submit" value="Submit" /> */}
//         </form>
//       </div>
//     );
//   }
// }

// export default Search;
