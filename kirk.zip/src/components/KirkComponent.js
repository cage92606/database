/* eslint-disable react/jsx-pascal-case */
import React, { Component } from 'react';
import {
  Breadcrumb,
  BreadcrumbItem,
  Button,
  // Form,
  FormGroup,
  Label,
  // Input,
  Col,
  // FormFeedback,
  Row,
  Input,
} from 'reactstrap';
import { Link } from 'react-router-dom';
import { Control, Form, Errors, actions } from 'react-redux-form';

class Kirk extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit = (value, event) => {
    this.props.postKirk(
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.how,
      value.data,
      value.work,
      value.news,
      value.buy,
      value.utilities,
      value.events,
      value.health,
      value.foods,
      value.invests
    );
    // alert('Current State is: ' + JSON.stringify(values));
    this.props.resetKirkForm();
    // e.preventDefault();
  };

  render() {
    return (
      <div className="container main">
        {/* <div className="row row-content"> */}
        {/* <div className="col-12"> */}
        <div className="mb-2">
          <h1>
            <b>Kirk</b>
          </h1>
        </div>
        {/* <div className="col-12 col-md-9"> */}
        <p>
          Take all your Kirks and look them back sometimes. You will find
          something good.
        </p>
        <Form
          model="kirk"
          onSubmit={(value, event) => this.handleSubmit(value, event)}
          // onSubmit={this.handleSubmit}
        >
          {/*  this FormGroup row allows us to use bootstrap's grid inside the form to lay out the various form elements.  */}
          <Row className="form-group mb-2">
            <Label htmlFor="date" md={2}>
              date
            </Label>
            <Col md={10}>
              <Control.text
                model=".date"
                id="date"
                name="date"
                placeholder="when?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="place" md={2}>
              place
            </Label>
            <Col md={10}>
              <Control.text
                model=".place"
                id="place"
                name="place"
                placeholder="where?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="person" md={2}>
              person
            </Label>
            <Col md={10}>
              <Control.text
                model=".person"
                id="person"
                name="person"
                placeholder="who?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="subject" md={2}>
              subject
            </Label>
            <Col md={10}>
              <Control.text
                model=".subject"
                id="subject"
                name="subject"
                placeholder="what?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="reason" md={2}>
              reason
            </Label>
            <Col md={10}>
              <Control.text
                model=".reason"
                id="reason"
                name="reason"
                placeholder="why?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="how" md={2}>
              how
            </Label>
            <Col md={10}>
              <Control.text
                model=".how"
                id="how"
                name="how"
                placeholder="how?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="data" md={2}>
              data
            </Label>
            <Col md={10}>
              <Control.text
                model=".data"
                id="data"
                name="data"
                placeholder="data?"
                className="form-control"
              />
            </Col>
          </Row>

          <br></br>

          <Row className="form-group">
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".work"
                    name="work"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>work</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".buy"
                    name="buy"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                    // disabled
                  />{' '}
                  <strong>buy</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".news"
                    name="news"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>news</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".utilities"
                    name="utilities"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>utilities</strong>
                </Label>
              </div>
            </Col>
          </Row>
          <Row className="form-group">
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".events"
                    name="events"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>events</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".health"
                    name="health"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>health</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".foods"
                    name="foods"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>foods</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".invests"
                    name="invests"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>invests</strong>
                </Label>
              </div>
            </Col>
          </Row>

          <Row className="form-group mt-5">
            {/* <Col> */}
            <Button type="submit" color="secondary">
              Submit
            </Button>
            {/* </Col> */}
          </Row>
        </Form>
        {/* </div> */}
      </div>
      // </div>
    );
  }
}

export default Kirk;
