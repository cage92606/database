import React from 'react';
import {
  Card,
  CardImg,
  CardBody,
  CardTitle,
  CardText,
  Button,
  Form,
  FormGroup,
  Label,
  Col,
  Row,
  Input,
  Media,
} from 'reactstrap';
import {
  ListGroup,
  ListGroupItemHeading,
  ListGroupItemText,
  ListGroupItem,
} from 'reactstrap';
import { Loading } from './LoadingComponent';

function RenderKirkItem({ kirk, deleteKirk, editKirk }) {
  return (
    // <div className="container">
    //   <div className="col-12">
    <ListGroup>
      <ListGroupItem>
        <Button outline color="primary" onClick={() => editKirk(kirk._id)}>
          <span className="fa fa-edit"></span>
        </Button>
        {`  ${kirk.date} `}
        {`${kirk.place} `}
        {`${kirk.person} `}
        {`${kirk.subject} `}
        {`${kirk.reason} `}
        {`${kirk.how} `}
        {kirk.data !== undefined ? (kirk.data ? `${kirk.data} ` : '') : ''}
        {kirk.work !== undefined ? (kirk.work ? 'work ' : '') : ''}
        {kirk.news !== undefined ? (kirk.news ? 'news ' : '') : ''}
        {kirk.buy !== undefined ? (kirk.buy ? 'buy ' : '') : ''}
        {kirk.utilities !== undefined
          ? kirk.utilities
            ? 'utilities '
            : ''
          : ''}
        {kirk.symptoms !== undefined ? (kirk.symptoms ? 'symptoms ' : '') : ''}
        {kirk.events !== undefined ? (kirk.events ? 'events ' : '') : ''}
        {kirk.health !== undefined ? (kirk.health ? 'health ' : '') : ''}
        {kirk.foods !== undefined ? (kirk.foods ? 'foods ' : '') : ''}
        {kirk.invests !== undefined ? (kirk.invests ? 'invests ' : '') : ''}
        {/* {kirk.work ? 'work ' : ''}
        {kirk.news ? 'news ' : ''}
        {kirk.buy ? 'buy ' : ''}
        {kirk.utilities ? 'utilities ' : ''}
        {kirk.symptoms ? 'symptoms ' : ''}
        {kirk.events ? 'events ' : ''}
        {kirk.health ? 'health ' : ''}
        {kirk.foods ? 'foods ' : ''}
        {kirk.invests ? 'invests ' : ''} */}
        {/* <Button outline color="danger" onClick={() => deleteKirk(kirk._id)}>
          <span className="fa fa-times"></span>
        </Button> */}
        <Button outline color="danger" onClick={() => deleteKirk(kirk._id)}>
          <span className="fa fa-times"></span>
        </Button>
      </ListGroupItem>
    </ListGroup>
    //   </div>
    // </div>
  );
}

const ListKirk = (props) => {
  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.kirks != null) {
    const kirkList = props.kirks.map((kirk) => {
      return (
        <div key={kirk.id}>
          <RenderKirkItem kirk={kirk} deleteKirk={props.deleteKirk} />
        </div>
      );
    });

    return (
      <Card>
        <Row className="form-group">
          <Col>
            <CardBody>{kirkList.reverse()}</CardBody>
          </Col>
        </Row>
      </Card>
    );
  } else {
    return <div></div>;
  }
};

export default ListKirk;
