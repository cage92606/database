/* eslint-disable react/jsx-pascal-case */
import React from 'react';
import { useState } from 'react';
// import { Control } from 'react-redux-form';
import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';

function RenderKirkItem({ kirk, deleteKirk, updateKirk, resetKirkForm }) {
  const [isOpen, setIsOpen] = useState(false);
  // const [date, setDate] = useState('');
  // const [place, setPlace] = useState('');
  // const [person, setPerson] = useState('');
  // const [subject, setSubject] = useState('');
  // const [reason, setReason] = useState('');
  // const [how, setHow] = useState('');
  // const [data, setData] = useState('');

  // const [work, setWork] = useState(false);
  // const [news, setNews] = useState(false);
  // const [buy, setBuy] = useState(false);
  // const [utilities, setUtilities] = useState(false);
  // // const [symptoms, setSymptoms] = useState('');
  // const [events, setEvents] = useState(false);
  // const [health, setHealth] = useState(false);
  // const [foods, setFoods] = useState(false);
  // const [invests, setInvests] = useState(false);

  // const handleSubmit = useCallback(() =>)

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    updateKirk(
      kirk._id,
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.how,
      value.data,
      value.work,
      value.news,
      value.buy,
      value.utilities,
      // value.symptoms,
      value.events,
      value.health,
      value.foods,
      value.invests
    );
    console.log('In handleSubmit, date is ', value.date);
    console.log('In handleSubmit, foods is ', value.foods);

    resetKirkForm();
  };

  return (
    <ListGroup>
      <ListGroupItem>
        <Button outline color="primary" onClick={toggleModal}>
          <span className="fa fa-edit"></span>
        </Button>
        <Modal
          isOpen={isOpen}
          toggle={toggleModal}
          size="lg"
          style={{ maxWidth: '1000px', width: '100%' }}
        >
          <ModalHeader toggle={toggleModal}>Update Kirk</ModalHeader>
          <ModalBody>
            <Form onSubmit={handleSubmit} model="kirk">
              <Row className="form-group mb-2">
                <Label htmlFor="date">date</Label>
                <Control.text
                  model=".date"
                  id="date"
                  name="date"
                  defaultValue={kirk.date}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="place">place</Label>
                <Control.text
                  model=".place"
                  id="place"
                  name="place"
                  defaultValue={kirk.place}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="person">person</Label>
                <Control.text
                  model=".person"
                  id="person"
                  name="person"
                  defaultValue={kirk.person}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="subject">subject</Label>
                <Control.text
                  model=".subject"
                  id="subject"
                  name="subject"
                  defaultValue={kirk.subject}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="reason">reason</Label>
                <Control.text
                  model=".reason"
                  id="reason"
                  name="reason"
                  defaultValue={kirk.reason}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="how">how</Label>
                <Control.text
                  model=".how"
                  id="how"
                  name="how"
                  defaultValue={kirk.how}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="data">data</Label>
                <Control.text
                  model=".data"
                  id="data"
                  name="data"
                  defaultValue={kirk.data}
                  className="form-control"
                />
              </Row>
              <Row className="form-group">
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".work"
                        name="work"
                        className="form-check-input"
                        defaultChecked={kirk.work}
                      />{' '}
                      work
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".news"
                        name="news"
                        className="form-check-input"
                        defaultChecked={kirk.news}
                      />{' '}
                      news
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".buy"
                        name="buy"
                        defaultChecked={kirk.buy}
                        className="form-check-input"
                      />{' '}
                      buy
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".utilities"
                        name="ulitities"
                        defaultChecked={kirk.ulitities}
                        className="form-check-input"
                      />{' '}
                      ulitities
                    </Label>
                  </div>
                </Col>
              </Row>
              <Row>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".events"
                        name="events"
                        defaultChecked={kirk.events}
                        className="form-check-input"
                      />{' '}
                      events
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".health"
                        name="health"
                        defaultChecked={kirk.health}
                        className="form-check-input"
                      />{' '}
                      health
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".foods"
                        name="foods"
                        defaultChecked={kirk.foods}
                        className="form-check-input"
                      />{' '}
                      foods
                    </Label>
                  </div>
                </Col>
                <Col md={{ size: 3, offset: 0 }}>
                  <div className="form-check">
                    <Label check>
                      <Control.checkbox
                        model=".invests"
                        name="invests"
                        defaultChecked={kirk.invests}
                        className="form-check-input"
                      />{' '}
                      invests
                    </Label>
                  </div>
                </Col>
              </Row>
              <Button type="submit" value="submit" color="primary">
                Submit
              </Button>
            </Form>
          </ModalBody>
        </Modal>
        {`  ${kirk.date} `}
        {kirk.place.indexOf('http') === 0 ? (
          kirk.place ? (
            // <a href="http://www.google.com">Googe</a>
            <a href={kirk.place} target="_blank" rel="noreferrer">
              {kirk.place + ' '}{' '}
            </a>
          ) : (
            ''
          )
        ) : (
          // `${kirk.place}  `
          kirk.place + ' '
        )}
        {/* {`${kirk.person} `} */}
        {kirk.person + ' '}
        {/* {<b>{kirk.subject}</b>}  */}
        {<b>{kirk.subject} </b>}
        {/* {`${kirk.reason} `} */}
        {kirk.reason + ' '}
        {/* {`${kirk.how} `} */}
        {kirk.how + ' '}
        {/* {kirk.data !== undefined ? (kirk.data ? `${kirk.data} ` : '') : ''} */}
        {kirk.data !== undefined ? (
          kirk.data ? (
            <code>{kirk.data}</code>
          ) : (
            ''
          )
        ) : (
          ''
        )}
        {kirk.work !== undefined ? kirk.work ? <b>work </b> : '' : ''}
        {kirk.news !== undefined ? kirk.news ? <b>news </b> : '' : ''}
        {kirk.buy !== undefined ? kirk.buy ? <b>buy </b> : '' : ''}
        {kirk.utilities !== undefined ? (
          kirk.utilities ? (
            <b>utilities </b>
          ) : (
            ''
          )
        ) : (
          ''
        )}
        {kirk.events !== undefined ? kirk.events ? <b>events </b> : '' : ''}
        {kirk.health !== undefined ? kirk.health ? <b>health </b> : '' : ''}
        {kirk.foods !== undefined ? kirk.foods ? <b>foods </b> : '' : ''}
        {kirk.invests !== undefined ? kirk.invests ? <b>invests </b> : '' : ''}
        <Button
          outline
          color="danger"
          onClick={() => {
            if (window.confirm('Are you sure?')) deleteKirk(kirk._id);
          }}
        >
          <span className="fa fa-times"></span>
        </Button>
      </ListGroupItem>
    </ListGroup>
    //   </div>
    // </div>
  );
}

export let num;
console.log('num in List is ', num);

export default function ListKirk(props) {
  // const [kirkNum2, setKirkNum2] = useState(0);

  // props.getKirkNum2(num);

  // useEffect(() => {
  //   // code to run after render goes here
  //   // props.getKirkNum2(kirkNum2);
  //   console.log('you are in useEffect');
  // });

  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    console.log('you are in keyword');
    const keywordArray = props.keyword.split(/(\s+)/);
    console.log('keyword array', keywordArray);
    console.log('keywordArray length is', keywordArray.length);
    var keywords = [];
    let j = 0;
    for (let i = 0; i < keywordArray.length; i++) {
      if (keywordArray[i] !== ' ') {
        keywords[j] = keywordArray[i].toLowerCase();
        j = j + 1;
      }
    }
    console.log('keywords is ', keywords);

    // const test = currentKeyWord => currentKeyWord
    const foundKirks2 = props.kirks.filter(
      (curr) =>
        keywords.every((word) => curr.date.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.place.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.person.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.subject.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.reason.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.how.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.data.toLowerCase().includes(word))
    );

    // const foundKirks = props.kirks.filter(
    //   (curr) =>
    //     curr.date.includes(props.keyword) ||
    //     curr.place.includes(props.keyword) ||
    //     curr.person.includes(props.keyword) ||
    //     curr.subject.includes(props.keyword) ||
    //     curr.reason.includes(props.keyword) ||
    //     curr.how.includes(props.keyword) ||
    //     curr.data.includes(props.keyword)
    // );

    const kirkList = foundKirks2.map((kirk) => {
      return (
        <div key={kirk._id}>
          <RenderKirkItem
            kirk={kirk}
            deleteKirk={props.deleteKirk}
            updateKirk={props.updateKirk}
            resetKirkForm={props.resetKirkForm}
          />
        </div>
      );
    });

    num = kirkList.length;
    // props.getKirkNum2(num);

    console.log('number of kirks found is ', num);
    // setKirkNum(num);
    // props.getKirkNum2(num);
    // setKirkNum2(num);

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                {' '}
                <h5>{num} items</h5>
                {kirkList.reverse()}
                {/* {props.updateKirkNum(num)} */}
                {/* <CardLink
                  href="http://www.google.com"
                  target="_blank"
                  rel="noreferrer"
                ></CardLink> */}
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else if (props.kirks !== null) {
    console.log('you are in kirks');
    console.log('keyword is ', props.keyword);
    const kirkList = props.kirks.map((kirk) => {
      return (
        <div key={kirk._id}>
          <RenderKirkItem
            kirk={kirk}
            deleteKirk={props.deleteKirk}
            updateKirk={props.updateKirk}
            resetKirkForm={props.resetKirkForm}
          />
        </div>
      );
    });

    num = kirkList.length;
    // props.getKirkNum2(num);
    console.log('number of kirks found is ', num);
    // setKirkNum(num);
    // props.getKirkNum(num);
    // props.getKirkNum2(num);
    // setKirkNum2(num);

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                {' '}
                <h5>{num} items</h5>
                {kirkList.reverse()}
                {/* {props.updateKirkNum(num)} */}
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else {
    return <div></div>;
  }
}

// export default ListKirk;
