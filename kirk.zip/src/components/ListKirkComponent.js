import React from 'react';
import {
  Card,
  CardImg,
  CardBody,
  CardTitle,
  CardText,
  Button,
  Form,
  FormGroup,
  Label,
  Col,
  Row,
  Input,
} from 'reactstrap';
import { ListGroup, ListGroupItemHeading, ListGroupItemText } from 'reactstrap';
import { Loading } from './LoadingComponent';

const ListKirk = (props) => {
  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.kirks != null) {
    console.log(`props.kirks : ${props.kirks}`);
    const kirk_temp = props.kirks.map((curr) => {
      return (
        <div key={curr.id}>
          <ListGroup>
            {/* <ListGroupItemText style={{ fontSize: '18px' }}> */}
            <ListGroupItemText>
              {curr.date}
              {', '}
              {curr.place}
              {', '}
              {curr.person}
              {', '}
              {curr.subject}
              {', '}
              {curr.reason}
              {', '}
              {curr.how}
            </ListGroupItemText>
          </ListGroup>
        </div>
      );
    });

    return (
      <Card>
        <Row className="form-group">
          <Col>
            <CardBody>{kirk_temp.reverse()}</CardBody>
          </Col>
        </Row>
      </Card>
    );
  } else {
    console.log(`props.kirks : ${props.kirks}`);
    return <div></div>;
  }
};

export default ListKirk;
