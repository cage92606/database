/* eslint-disable react/jsx-pascal-case */
import React from 'react';
import { useState } from 'react';
// import { Control } from 'react-redux-form';
import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';
import { CSVLink, CSVDownload } from 'react-csv';

function RenderKirkItem({ kirk, deleteKirk, updateKirk, resetKirkForm, auth }) {
  const [isOpen, setIsOpen] = useState(false);
  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    updateKirk(
      kirk._id,
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.condition,
      value.data,
      value.unit
      // value.work,
      // value.news,
      // value.buy,
      // value.utilities,
      // // value.symptoms,
      // value.events,
      // value.health,
      // value.foods,
      // value.invests
    );
    console.log('In handleSubmit, date is ', value.date);
    console.log('In handleSubmit, foods is ', value.foods);

    resetKirkForm();
  };

  return (
    <ListGroup>
      <ListGroupItem>
        {auth.id === kirk.user ? (
          <Button outline color="primary" onClick={toggleModal}>
            <span className="fa fa-edit"></span>
          </Button>
        ) : (
          <Button outline color="secondary">
            <span className="fa fa-edit"></span>
          </Button>
        )}
        <Modal
          isOpen={isOpen}
          toggle={toggleModal}
          size="lg"
          style={{ maxWidth: '1000px', width: '100%' }}
        >
          <ModalHeader toggle={toggleModal}>Update Kirk</ModalHeader>
          <ModalBody>
            <Form onSubmit={handleSubmit} model="input">
              <Row className="form-group mb-2">
                <Label htmlFor="date">date</Label>
                <Control.text
                  model=".date"
                  id="date"
                  name="date"
                  defaultValue={kirk.date}
                  className="form-control"
                />
                {/* </Row>
              <Row className="form-group mb-2"> */}
                <Label htmlFor="place">place</Label>
                <Control.text
                  model=".place"
                  id="place"
                  name="place"
                  defaultValue={kirk.place}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="person">person</Label>
                <Control.text
                  model=".person"
                  id="person"
                  name="person"
                  defaultValue={kirk.person}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="subject">subject</Label>
                <Control.text
                  model=".subject"
                  id="subject"
                  name="subject"
                  defaultValue={kirk.subject}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="reason">reason</Label>
                <Control.textarea
                  model=".reason"
                  id="reason"
                  name="reason"
                  defaultValue={kirk.reason}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="condition">condition</Label>
                <Control.textarea
                  model=".condition"
                  id="condition"
                  name="condition"
                  defaultValue={kirk.condition}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="data">data</Label>
                <Control.text
                  model=".data"
                  id="data"
                  name="data"
                  defaultValue={kirk.data}
                  className="form-control"
                />
                <Label htmlFor="unit">unit</Label>
                <Control.text
                  model=".unit"
                  id="unit"
                  name="unit"
                  defaultValue={kirk.unit}
                  className="form-control"
                />
              </Row>
              <Button type="submit" value="submit" color="primary">
                Submit
              </Button>
            </Form>
          </ModalBody>
        </Modal>
        {`  ${kirk.date} `}
        {kirk.place.indexOf('http') === 0 ? (
          kirk.place ? (
            // <a href="http://www.google.com">Googe</a>
            <a
              href={kirk.place}
              target="_blank"
              rel="noreferrer"
              // style={{ flex: 1 }}
              // style="text-overflow: ellipsis"
            >
              {/* {kirk.place + ' '}{' '} */}
              <span className="fa fa-link"></span>
            </a>
          ) : (
            ''
          )
        ) : (
          // `${kirk.place}  `
          kirk.place + ' '
        )}
        {/* {`${kirk.person} `} */}
        {kirk.person + ' '}
        {/* {<b>{kirk.subject}</b>}  */}
        {<b>{kirk.subject} </b>}
        {/* {`${kirk.reason} `} */}
        {kirk.reason + ' '}
        {/* {`${kirk.condition} `} */}
        {kirk.condition + ' '}
        {/* {kirk.data !== undefined ? (
          kirk.data ? (
            <code>{kirk.data}</code>
          ) : (
            ''
          )
        ) : (
          ''
        )} */}
        {kirk.data !== undefined ? (
          kirk.data.indexOf('http') === 0 ? (
            kirk.data ? (
              <a href={kirk.data} target="_blank" rel="noreferrer">
                {/* <span className="fa fa-link" color="pink"></span> */}
                <span className="fa fa-link" style={{ color: 'crimson' }} />
              </a>
            ) : (
              ''
            )
          ) : (
            <code>{kirk.data}</code>
          )
        ) : (
          <code>{kirk.data}</code>
        )}
        {kirk.unit + ' '}
        {/* {kirk.work !== undefined ? kirk.work ? <b>work </b> : '' : ''}
        {kirk.news !== undefined ? kirk.news ? <b>news </b> : '' : ''}
        {kirk.buy !== undefined ? kirk.buy ? <b>buy </b> : '' : ''}
        {kirk.utilities !== undefined ? (
          kirk.utilities ? (
            <b>utilities </b>
          ) : (
            ''
          )
        ) : (
          ''
        )}
        {kirk.events !== undefined ? kirk.events ? <b>events </b> : '' : ''}
        {kirk.health !== undefined ? kirk.health ? <b>health </b> : '' : ''}
        {kirk.foods !== undefined ? kirk.foods ? <b>foods </b> : '' : ''}
        {kirk.invests !== undefined ? kirk.invests ? <b>invests </b> : '' : ''} */}
        {auth.id === kirk.user ? (
          <Button
            outline
            color="danger"
            onClick={() => {
              if (window.confirm('Are you sure?')) deleteKirk(kirk._id);
            }}
          >
            <span className="fa fa-times"></span>
          </Button>
        ) : (
          <span></span>
        )}
      </ListGroupItem>
    </ListGroup>
    //   </div>
    // </div>
  );
}

export let num;
console.log('num in List is ', num);

export default function ListKirk2(props) {
  // const [kirkNum2, setKirkNum2] = useState(0);

  // props.getKirkNum2(num);

  // useEffect(() => {
  //   // code to run after render goes here
  //   // props.getKirkNum2(kirkNum2);
  //   console.log('you are in useEffect');
  // });

  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    console.log('you are in keyword');
    const keywordArray = props.keyword.split(/(\s+)/);
    var keywords = [];
    let j = 0;
    for (let i = 0; i < keywordArray.length; i++) {
      if (keywordArray[i] !== ' ') {
        keywords[j] = keywordArray[i].toLowerCase();
        j = j + 1;
      }
    }
    console.log('keywords is ', keywords);

    const foundKirks2 = props.kirks.filter((curr) => {
      const test = keywords.map(
        (keyword) =>
          curr.date.toLowerCase().includes(keyword) ||
          curr.place.toLowerCase().includes(keyword) ||
          curr.person.toLowerCase().includes(keyword) ||
          curr.subject.toLowerCase().includes(keyword) ||
          curr.reason.toLowerCase().includes(keyword) ||
          curr.condition.toLowerCase().includes(keyword) ||
          curr.data.toLowerCase().includes(keyword) ||
          curr.unit.toLowerCase().includes(keyword)
      );
      return test.every((logic) => logic === true);
      // return test.some((logic) => logic === true);
    });

    const csvData = foundKirks2;

    const kirkList = foundKirks2.map((kirk) => {
      return (
        <div key={kirk._id}>
          <RenderKirkItem
            kirk={kirk}
            deleteKirk={props.deleteKirk}
            updateKirk={props.updateKirk}
            resetKirkForm={props.resetKirkForm}
            auth={props.auth} // added on 2022.12.13
          />
        </div>
      );
    });

    num = kirkList.length;
    // props.getKirkNum2(num);

    // console.log('number of kirks found is ', num);
    // setKirkNum(num);
    // props.getKirkNum2(num);
    // setKirkNum2(num);

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <div className="row">
                  <div className="col-6">
                    <h5>{num} items</h5>
                  </div>
                  <div className="col-6">
                    <CSVLink
                      data={csvData}
                      className="fa fa-arrow-down"
                    ></CSVLink>
                  </div>
                </div>
                {kirkList.reverse()}
                {/* {props.updateKirkNum(num)} */}
                {/* <CardLink
                  href="http://www.google.com"
                  target="_blank"
                  rel="noreferrer"
                ></CardLink> */}
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else if (props.kirks !== null) {
    console.log('you are in kirks');
    console.log('keyword is ', props.keyword);
    const kirkList = props.kirks.map((kirk) => {
      return (
        <div key={kirk._id}>
          <RenderKirkItem
            kirk={kirk}
            deleteKirk={props.deleteKirk}
            updateKirk={props.updateKirk}
            resetKirkForm={props.resetKirkForm}
            auth={props.auth}
          />
        </div>
      );
    });

    num = kirkList.length;
    // props.getKirkNum2(num);
    console.log('number of kirks found is ', num);
    // setKirkNum(num);
    // props.getKirkNum(num);
    // props.getKirkNum2(num);
    // setKirkNum2(num);

    const csvData = props.kirks;

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <div className="row">
                  <div className="col-6">
                    <h5>{num} items</h5>
                  </div>
                  <div className="col-6">
                    <CSVLink
                      data={csvData}
                      className="fa fa-arrow-down"
                    ></CSVLink>
                  </div>
                </div>
                {kirkList.reverse()}
                {/* {props.updateKirkNum(num)} */}
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else {
    return <div></div>;
  }
}

// export default ListKirk;
