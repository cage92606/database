/* eslint-disable react/jsx-pascal-case */
import React, { Component, useState } from 'react';
import { Col, Row, Label, Input, Button, FormText } from 'reactstrap';
import { Control, Form, Errors, actions } from 'react-redux-form';

class Pro extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit = (value) => {
    this.props.postProInput(
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.condition1,
      value.condition2,
      value.condition3,
      value.condition4,
      value.condition5,
      value.condition6,
      value.condition7,
      value.condition8,
      value.condition9,
      value.condition10,
      value.condition11,
      value.condition12,
      value.condition13,
      value.condition14,
      value.condition15,
      value.condition16,
      value.condition17,
      value.condition18,
      value.condition19,
      value.condition20,
      value.data,
      value.unit
    );
    console.log('event.target.value are ', value);
    this.props.resetProInputForm();
  };

  render() {
    return (
      <div className="container main">
        <div className="mb-2">
          <h1>
            <b>Pro</b>
          </h1>
        </div>
        {/* <div className="col-12 col-md-9"> */}
        <p>
          Take any engineering data, create datasets for data science or machine
          learning{' '}
        </p>
        <Form model="input" onSubmit={(value) => this.handleSubmit(value)}>
          <Row className="form-group mb-2">
            <Label sm={2} htmlFor="date">
              date
            </Label>
            <Col sm={10}>
              <Control.text
                model=".date"
                id="date"
                name="date"
                placeholder="2022-1-1"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label sm={2} htmlFor="place">
              place
            </Label>
            <Col sm={10}>
              <Control.text
                model=".place"
                id="place"
                name="place"
                placeholder="where?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label sm={2} htmlFor="person">
              person
            </Label>
            <Col sm={10}>
              <Control.text
                model=".person"
                id="person"
                name="person"
                placeholder="who?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label sm={2} htmlFor="subject">
              subject
            </Label>
            <Col sm={10}>
              <Control.text
                model=".subject"
                id="subject"
                name="subject"
                placeholder="what?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label sm={2} htmlFor="reason">
              reason
            </Label>
            <Col sm={10}>
              <Control.textarea
                model=".reason"
                id="reason"
                name="reason"
                placeholder="why?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label sm={2}>condition</Label>
            <Col sm={2}>
              <Control.text
                htmlFor="condition1"
                model=".condition1"
                type="text"
                id="condition1"
                name="condition1"
                placeholder="1"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition2"
                model=".condition2"
                type="text"
                id="condition2"
                name="condition2"
                placeholder="2"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition3"
                model=".condition3"
                type="text"
                id="condition3"
                name="condition3"
                placeholder="3"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition4"
                model=".condition4"
                type="text"
                id="condition4"
                name="condition4"
                placeholder="4"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition5"
                model=".condition5"
                type="text"
                id="condition5"
                name="condition5"
                placeholder="5"
                className="form-control"
              />
            </Col>
          </Row>

          <Row className="form-group mb-2">
            <Label sm={2}></Label>
            <Col sm={2}>
              <Control.text
                htmlFor="condition6"
                model=".condition6"
                type="text"
                id="condition6"
                name="condition6"
                placeholder="6"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition7"
                model=".condition7"
                type="text"
                id="condition7"
                name="condition7"
                placeholder="7"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition8"
                model=".condition8"
                type="text"
                id="condition8"
                name="condition8"
                placeholder="8"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition9"
                model=".condition9"
                type="text"
                id="condition9"
                name="condition9"
                placeholder="9"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition10"
                model=".condition10"
                type="text"
                id="condition10"
                name="condition10"
                placeholder="10"
                className="form-control"
              />
            </Col>
          </Row>

          <Row className="form-group mb-2">
            <Label sm={2}></Label>
            <Col sm={2}>
              <Control.text
                htmlFor="condition11"
                model=".condition11"
                type="text"
                id="condition11"
                name="condition11"
                placeholder="11"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition12"
                model=".condition12"
                type="text"
                id="condition12"
                name="condition12"
                placeholder="12"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition13"
                model=".condition13"
                type="text"
                id="condition13"
                name="condition13"
                placeholder="13"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition14"
                model=".condition14"
                type="text"
                id="condition14"
                name="condition14"
                placeholder="14"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition15"
                model=".condition15"
                type="text"
                id="condition15"
                name="condition15"
                placeholder="15"
                className="form-control"
              />
            </Col>
          </Row>

          <Row className="form-group mb-2">
            <Label sm={2}></Label>
            <Col sm={2}>
              <Control.text
                htmlFor="condition16"
                model=".condition16"
                type="text"
                id="condition16"
                name="condition16"
                placeholder="16"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition17"
                model=".condition17"
                type="text"
                id="condition17"
                name="condition17"
                placeholder="17"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition18"
                model=".condition18"
                type="text"
                id="condition18"
                name="condition18"
                placeholder="18"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition19"
                model=".condition19"
                type="text"
                id="condition19"
                name="condition19"
                placeholder="19"
                className="form-control"
              />
            </Col>
            <Col sm={2}>
              <Control.text
                htmlFor="condition20"
                model=".condition20"
                type="text"
                id="condition20"
                name="condition20"
                placeholder="20"
                className="form-control"
              />
            </Col>
          </Row>

          <Row className="form-group mb-2">
            <Label xs={2} htmlFor="data">
              data
            </Label>
            <Col xs={4}>
              <Control.text
                model=".data"
                id="data"
                name="data"
                placeholder="12.3"
                className="form-control"
              />
            </Col>
            <Label xs={2} htmlFor="unit">
              unit
            </Label>
            <Col xs={4}>
              <Control.text
                model=".unit"
                id="unit"
                name="unit"
                placeholder="g"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mt-5">
            <Button type="submit" color="secondary">
              Submit
            </Button>
          </Row>
          {/* </FormGroup> */}
        </Form>
      </div>
    );
  }
}

export default Pro;
