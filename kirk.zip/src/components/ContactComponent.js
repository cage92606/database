/* eslint-disable react/jsx-pascal-case */
import React, { Component } from 'react';
import {
  Breadcrumb,
  BreadcrumbItem,
  Button,
  // Form,
  // FormGroup,
  Label,
  // Input,
  Col,
  // FormFeedback,
  Row,
} from 'reactstrap';
import { Link } from 'react-router-dom';
import { Control, Form, Errors, actions } from 'react-redux-form';
import 'materialize-css/dist/css/materialize.min.css';
// import ListKirk from './ListKirkComponent';

const required = (val) => val && val.length; // check if val is greater than 0
const maxLength = (len) => (val) => !val || val.length <= len; // check if val length is less than len
const minLength = (len) => (val) => val && val.length >= len; // check if val length is greater than len
const isNumber = (val) => !isNaN(Number(val));
const validEmail = (val) =>
  /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(val);

class Contact extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    // this.handleBlur = this.handleBlur.bind(this);
  }

  handleSubmit(values) {
    console.log('Current State is: ' + JSON.stringify(values));
    this.props.postKirk(
      values.date,
      values.place,
      values.person,
      values.subject,
      values.reason,
      values.how
    );
    // alert('Current State is: ' + JSON.stringify(values));
    this.props.resetKirkForm();
  }

  render() {
    return (
      <div className="container">
        {/* <div className="row row-content"> */}
        <div className="col-12">
          <h1>
            <b>Kirk</b>
          </h1>
        </div>
        <div className="col-12 col-md-9">
          <p>
            Take all your Kirks and look them back sometimes. You will find
            something good.
          </p>
          <Form model="kirk" onSubmit={(value) => this.handleSubmit(value)}>
            {/*  this FormGroup row allows us to use bootstrap's grid inside the form to lay out the various form elements.  */}
            <Row className="form-group mb-2">
              <Label htmlFor="date" md={2}>
                date
              </Label>
              <Col md={10}>
                <Control.text
                  model=".date"
                  id="date"
                  name="date"
                  placeholder="when?"
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="place" md={2}>
                place
              </Label>
              <Col md={10}>
                <Control.text
                  model=".place"
                  id="place"
                  name="place"
                  placeholder="where?"
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="person" md={2}>
                person
              </Label>
              <Col md={10}>
                <Control.text
                  model=".person"
                  id="person"
                  name="person"
                  placeholder="who?"
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="subject" md={2}>
                subject
              </Label>
              <Col md={10}>
                <Control.text
                  model=".subject"
                  id="subject"
                  name="subject"
                  placeholder="what?"
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="reason" md={2}>
                reason
              </Label>
              <Col md={10}>
                <Control.text
                  model=".reason"
                  id="reason"
                  name="reason"
                  placeholder="why?"
                  className="form-control"
                />
              </Col>
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="how" md={2}>
                how
              </Label>
              <Col md={10}>
                <Control.text
                  model=".how"
                  id="how"
                  name="how"
                  placeholder="how?"
                  className="form-control"
                />
              </Col>
            </Row>

            <Row className="form-group mt-5">
              {/* <Col> */}
              <Button type="submit" color="btn-secondary">
                Submit
              </Button>
              {/* </Col> */}
            </Row>
          </Form>
          {/* </div> */}
        </div>
      </div>
    );
  }
}

export default Contact;
