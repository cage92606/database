/* eslint-disable react/jsx-pascal-case */
import React, { Component } from 'react';
import {
  Breadcrumb,
  BreadcrumbItem,
  Button,
  // Form,
  // FormGroup,
  Label,
  // Input,
  Col,
  // FormFeedback,
  Row,
} from 'reactstrap';
import { Link } from 'react-router-dom';
import { Control, Form, Errors, actions } from 'react-redux-form';
// import 'materialize-css/dist/css/materialize.min.css';
// import ListKirk from './ListKirkComponent';

const required = (val) => val && val.length; // check if val is greater than 0
const maxLength = (len) => (val) => !val || val.length <= len; // check if val length is less than len
const minLength = (len) => (val) => val && val.length >= len; // check if val length is greater than len
const isNumber = (val) => !isNaN(Number(val));
const validEmail = (val) =>
  /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(val);

class Contact extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    // this.handleBlur = this.handleBlur.bind(this);
  }

  // handleLogin(event) {
  //   this.toggleModal(); // Close the modal once the forms submitted
  //   // alert(
  //   //   `Username: ${this.username.value} Password: ${this.password.value} Remember: ${this.remember.checked}`
  //   // );
  //   this.props.loginUser({
  //     username: this.username.value,
  //     password: this.password.value,
  //   });
  //   event.preventDefault();
  // }

  handleSubmit(value, event) {
    // console.log('Current State is: ' + JSON.stringify(values));
    // event.preventDefault();
    this.props.postKirk(
      // data: this.date,
      // place: this.place,
      // person: this.person,
      // subject: this.subject,
      // reason: this.reason,
      // how: this.how,
      // work: this.work,
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.how,
      value.data,
      value.work,
      value.news,
      value.buy,
      value.utilities,
      value.symptoms,
      value.events,
      value.health,
      value.foods,
      value.invests
    );
    // alert('Current State is: ' + JSON.stringify(values));
    // event.preventDefault();
    this.props.resetKirkForm();
  }

  render() {
    return (
      <div className="container">
        {/* <div className="row row-content"> */}
        <div className="col-12">
          <h1>
            <b>Kirk</b>
          </h1>
        </div>
        {/* <div className="col-12 col-md-9"> */}
        <p>
          Take all your Kirks and look them back sometimes. You will find
          something good.
        </p>
        <Form
          model="kirk"
          // onSubmit={(e, value) => this.handleSubmit(value)}
          onSubmit={this.handleSubmit}
        >
          {/*  this FormGroup row allows us to use bootstrap's grid inside the form to lay out the various form elements.  */}
          <Row className="form-group mb-2">
            <Label htmlFor="date" md={2}>
              date
            </Label>
            <Col md={10}>
              <Control.text
                model=".date"
                id="date"
                name="date"
                placeholder="when?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="place" md={2}>
              place
            </Label>
            <Col md={10}>
              <Control.text
                model=".place"
                id="place"
                name="place"
                placeholder="where?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="person" md={2}>
              person
            </Label>
            <Col md={10}>
              <Control.text
                model=".person"
                id="person"
                name="person"
                placeholder="who?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="subject" md={2}>
              subject
            </Label>
            <Col md={10}>
              <Control.text
                model=".subject"
                id="subject"
                name="subject"
                placeholder="what?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="reason" md={2}>
              reason
            </Label>
            <Col md={10}>
              <Control.text
                model=".reason"
                id="reason"
                name="reason"
                placeholder="why?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="how" md={2}>
              how
            </Label>
            <Col md={10}>
              <Control.text
                model=".how"
                id="how"
                name="how"
                placeholder="how?"
                className="form-control"
              />
            </Col>
          </Row>
          <Row className="form-group mb-2">
            <Label htmlFor="data" md={2}>
              data
            </Label>
            <Col md={10}>
              <Control.text
                model=".data"
                id="data"
                name="data"
                placeholder="data?"
                className="form-control"
              />
            </Col>
          </Row>

          <br></br>

          <Row className="form-group">
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".work"
                    name="work"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>work</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".buy"
                    name="buy"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                    // disabled
                  />{' '}
                  <strong>buy</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".news"
                    name="news"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>news</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".utilities"
                    name="utilities"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>utilities</strong>
                </Label>
              </div>
            </Col>
          </Row>
          <Row className="form-group">
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".events"
                    name="events"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>events</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".health"
                    name="health"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>health</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".foods"
                    name="foods"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>foods</strong>
                </Label>
              </div>
            </Col>
            <Col md={{ size: 3, offset: 0 }}>
              <div className="form-check">
                <Label check>
                  <Control.checkbox
                    model=".invests"
                    name="invests"
                    className="form-check-input"
                    style={{
                      transform: 'scale(1.3)',
                    }}
                  />{' '}
                  <strong>invests</strong>
                </Label>
              </div>
            </Col>
          </Row>

          <Row className="form-group mt-5">
            {/* <Col> */}
            <Button type="submit" color="secondary">
              Submit
            </Button>
            {/* </Col> */}
          </Row>
        </Form>
        {/* </div> */}
      </div>
      // </div>
    );
  }
}

export default Contact;
