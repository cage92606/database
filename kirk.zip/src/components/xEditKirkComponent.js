import React, { Component, Fragment } from 'react';
import { useState } from 'react';
import {
  Navbar,
  NavbarBrand,
  Nav,
  NavbarToggler,
  Collapse,
  NavItem,
  Jumbotron,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';

export default function EditKirk() {
  const [isOpen, setIsOpen] = useState(false);
  const [date, setDate] = useState('');
  const [subject, setSubject] = useState('');
  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  return (
    // <Fragment>
    <Modal isOpen={isOpen} toggle={toggleModal}>
      <ModalHeader toggle={toggleModal}>Edit</ModalHeader>
      <ModalBody>
        <Form onSubmit={this.handleEdit}>
          <FormGroup>
            <Label htmlFor="date">date</Label>
            <Input
              type="text"
              id="date"
              name="date"
              value={date}
              innerRef={(date) => setDate(date)}
            />
          </FormGroup>
          <FormGroup>
            <Label htmlFor="subject">subject</Label>
            <Input
              type="text"
              id="subject"
              name="subject"
              value={subject}
              innerRef={(input) => setSubject(input)}
            />
          </FormGroup>
          <Button type="submit" value="submit" color="primary">
            Submit
          </Button>
        </Form>
      </ModalBody>
    </Modal>
    // </Fragment>
  );
}

// export default EditKirk;
