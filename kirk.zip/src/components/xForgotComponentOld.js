import React, { Component } from 'react';
import axios from 'axios';
export class Forgot extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      email: this.email,
    };
    fetch('/forgot', {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      body: data,
    }).catch((err) => {
      console.log(err);
    });

    // var data = new FormData();
    // data.append('first_name', 'name');
    // data.append('email', 'email@example.com');

    // fetch('/forgot', {
    //   method: 'POST',
    //   body: data,
    // });
  };

  render() {
    return (
      <div className="container main">
        <form onSubmit={this.handleSubmit}>
          <h3>Forgot Password</h3>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              className="form-control"
              placeholder="email"
              onChange={(e) => (this.email = e.target.value)}
            />
          </div>

          <button className="btn btn-primary btn-block">Submit</button>
        </form>
      </div>
    );
  }
}
export default Forgot;
