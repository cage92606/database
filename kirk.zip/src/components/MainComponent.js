import React, { Component } from 'react';
import Contact from './ContactComponent';
import Header from './HeaderComponent';
// import LoadFile, { array } from './LoadFileComponent';
import LoadFile from './LoadFileComponent';
import { Switch, Route, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  postKirk,
  fetchKirks,
  loginUser,
  signupUser,
  deleteKirk,
  editKirk,
  logoutUser,
} from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
    auth: state.auth,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  loginUser: (creds) => dispatch(loginUser(creds)),
  signupUser: (creds) => dispatch(signupUser(creds)),
  logoutUser: () => dispatch(logoutUser()),
  postKirk: (
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      postKirk(
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  deleteKirk: (kirkId) => dispatch(deleteKirk(kirkId)),
  editKirk: (kirkId) => dispatch(editKirk(kirkId)),
});

class Main extends Component {
  constructor(props) {
    super(props);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
    // console.log(array);
  }

  // onDishSelect(dishId) {
  //   this.setState({ selectedDish: dishId });
  // }

  // prettier-ignoreee
  render() {
    return (
      <div>
        <Header
          auth={this.props.auth}
          loginUser={this.props.loginUser}
          signupUser={this.props.signupUser}
          logoutUser={this.props.logoutUser}
        />
        <LoadFile>
          {/* <div style={{ textAlign: 'center' }}>
            <form>
              <input type={'file'} accept={'.csv'} />
              <button>IMPORT CSV</button>
            </form>
          </div> */}
        </LoadFile>
        <Switch>
          <Route
            path="/kirks"
            component={() => (
              <Contact
                resetKirkForm={this.props.resetKirkForm}
                postKirk={this.props.postKirk}
                // postKirk={array}
              />
            )}
          />
          <Redirect to="/kirks" />
        </Switch>
        {/* <div className="container"> */}
        {/* <div className="row"> */}
        <div className="col-12 mt-3">
          <ListKirk
            kirks={this.props.kirks.kirks}
            isLoading={this.props.kirks.isLoading}
            errMess={this.props.kirks.errMess}
            deleteKirk={this.props.deleteKirk}
            editKirk={this.props.editKirk}
          />
        </div>
        {/* </div> */}
        {/* </div> */}
      </div>
    );
  }
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Main));
