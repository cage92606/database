import React, { Component, useEffect } from 'react';
import ReactSearchBox from 'react-search-box';
import Kirk from './KirkComponent';
import Data from './DataComponent';
import Header from './HeaderComponent';
import { Link, BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  postKirk,
  fetchKirks,
  loginUser,
  signupUser,
  deleteKirk,
  updateKirk,
  logoutUser,
  postInput,
  fetchInputs,
  deleteInput,
  updateInput,
  // getSearchWord,
  // updateKirkNum,
  // getKirkNum,
  // updateKirkNum,
} from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';
import ListData from './ListDataComponent';
import { foundKirks } from './SearchComponent';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
// import * as ReactDOM from 'react-dom/client';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
    auth: state.auth,
    inputs: state.inputs,
    // kirkNum: state.kirkNum,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  fetchInputs: () => {
    dispatch(fetchInputs());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  resetInputForm: () => {
    dispatch(actions.reset('input'));
  }, // This is a THUNK
  loginUser: (creds) => dispatch(loginUser(creds)),
  signupUser: (creds) => dispatch(signupUser(creds)),
  logoutUser: () => dispatch(logoutUser()),
  postKirk: (
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      postKirk(
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  postInput: (date, place, person, subject, reason, condition, data, unit) =>
    dispatch(
      postInput(date, place, person, subject, reason, condition, data, unit)
    ),
  deleteKirk: (kirkId) => dispatch(deleteKirk(kirkId)),
  deleteInput: (inputId) => dispatch(deleteInput(inputId)),
  updateKirk: (
    kirkId,
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      updateKirk(
        kirkId,
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  updateInput: (
    inputId,
    date,
    place,
    person,
    subject,
    reason,
    condition,
    data,
    unit
  ) =>
    dispatch(
      updateInput(
        inputId,
        date,
        place,
        person,
        subject,
        reason,
        condition,
        data,
        unit
      )
    ),
});

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
      // kirkNum2: 0,
    };
    // To use a method on JSX you have to bind it here.
    this.getKeyword = this.getKeyword.bind(this);
    // this.getKirkNum2 = this.getKirkNum2.bind(this);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
    this.props.fetchInputs();
    // console.log('kirkNum on main is ', this.props.kirkNum);
  }

  componentDidUpdate() {
    setInterval(() => this.props.fetchKirks(), 1800000); // 30 min
    // setInterval(() => this.props.fetchInputs(), 1800000); // 30 min
  }

  getKeyword(keyword) {
    this.setState({
      keyword: keyword,
    });
    console.log('keyword on main is ', keyword);
    console.log('this.state.keyword on main is ', this.state.keyword);
  }

  // prettier-ignoreee
  render() {
    const KirkPage = () => {
      return (
        <div>
          <Kirk
            resetKirkForm={this.props.resetKirkForm}
            postKirk={this.props.postKirk}
          />

          <div className="col-12 mt-3">
            <ListKirk
              resetKirkForm={this.props.resetKirkForm}
              kirks={this.props.kirks.kirks}
              isLoading={this.props.kirks.isLoading}
              errMess={this.props.kirks.errMess}
              deleteKirk={this.props.deleteKirk}
              updateKirk={this.props.updateKirk}
              keyword={this.state.keyword}
              // kirkNum2={this.props.kirkNum2}
              // getKirkNum2={this.getKirkNum2}
            />
          </div>
        </div>
      );
    };

    const DataPage = () => {
      return (
        <div>
          <Data
            resetInputForm={this.props.resetInputForm}
            postInput={this.props.postInput}
            fetchInputs={this.props.fetchInputs}
          />

          <div className="col-12 mt-3">
            <ListData
              resetInputForm={this.props.resetInputForm}
              inputs={this.props.inputs.inputs}
              isLoading={this.props.inputs.isLoading}
              errMess={this.props.inputs.errMess}
              deleteInput={this.props.deleteInput}
              updateInput={this.props.updateInput}
              keyword={this.state.keyword}
            />
          </div>
        </div>
      );
    };

    return (
      <div>
        <Header
          auth={this.props.auth}
          loginUser={this.props.loginUser}
          signupUser={this.props.signupUser}
          logoutUser={this.props.logoutUser}
          kirks={this.props.kirks.kirks}
          getKeyword={this.getKeyword}
          // kirkNum2={this.props.kirkNum2}
        />

        {/* <Kirk
          resetKirkForm={this.props.resetKirkForm}
          postKirk={this.props.postKirk}
        /> */}

        {/* <BrowserRouter> */}
        <Routes>
          {/* <Route path="/" element={<Home />} /> */}
          <Route path="/" element={<KirkPage />} />
          <Route path="/inputs" element={<DataPage />} />
          {/* <Route path="/home" element={<Navigate replace to="/" />} /> */}
          {/* <Route path="/home" element={<Navigate replace to="/" />} /> */}

          {/* <Route exact path="/body" component={() => <Body />} />
          <Navigate to="/" /> */}
        </Routes>
        {/* </BrowserRouter> */}
        {/* <Route path="/body" exact>
          <Navigate to="/body" />
        </Route> */}

        {/* <div className="col-12 mt-3">
          <ListKirk
            resetKirkForm={this.props.resetKirkForm}
            kirks={this.props.kirks.kirks}
            isLoading={this.props.kirks.isLoading}
            errMess={this.props.kirks.errMess}
            deleteKirk={this.props.deleteKirk}
            updateKirk={this.props.updateKirk}
            keyword={this.state.keyword}
            // kirkNum2={this.props.kirkNum2}
            // getKirkNum2={this.getKirkNum2}
          />
        </div> */}
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Main);
