import React, { Component, useEffect } from 'react';
import ReactSearchBox from 'react-search-box';
import Kirk from './KirkComponent';
import Data from './DataComponent';
import Header from './HeaderComponent';
import { Link, BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  postKirk,
  fetchKirks,
  loginUser,
  pwChangeUser,
  signupUser,
  deleteKirk,
  updateKirk,
  logoutUser,
  postInput,
  fetchInputs,
  deleteInput,
  updateInput,
  forgotPassword,
  // showAll,
  // showMine,
  // getSearchWord,
  // updateKirkNum,
  // getKirkNum,
  // updateKirkNum,
} from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';
import ListKirk2 from './ListKirk2Component';
import ListData from './ListDataComponent';
import { foundKirks } from './SearchComponent';
import Forgot from './ForgotComponent';
import Reset from './ResetComponent';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
// import * as ReactDOM from 'react-dom/client';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
    auth: state.auth,
    inputs: state.inputs,
    // kirkNum: state.kirkNum,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  fetchInputs: () => {
    dispatch(fetchInputs());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  resetInputForm: () => {
    dispatch(actions.reset('input'));
  }, // This is a THUNK
  loginUser: (creds) => dispatch(loginUser(creds)),
  pwChangeUser: (creds) => dispatch(pwChangeUser(creds)),
  // showAll: (value) => dispatch(showAll(value)),
  // showMine: () => dispatch(showMine()),
  signupUser: (creds) => dispatch(signupUser(creds)),
  logoutUser: () => dispatch(logoutUser()),
  forgotPassword: (email) => dispatch(forgotPassword(email)),
  postKirk: (
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      postKirk(
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  postInput: (date, place, person, subject, reason, condition, data, unit) =>
    dispatch(
      postInput(date, place, person, subject, reason, condition, data, unit)
    ),
  deleteKirk: (kirkId) => dispatch(deleteKirk(kirkId)),
  deleteInput: (inputId) => dispatch(deleteInput(inputId)),
  updateKirk: (
    kirkId,
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      updateKirk(
        kirkId,
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  updateInput: (
    inputId,
    date,
    place,
    person,
    subject,
    reason,
    condition,
    data,
    unit
  ) =>
    dispatch(
      updateInput(
        inputId,
        date,
        place,
        person,
        subject,
        reason,
        condition,
        data,
        unit
      )
    ),
});

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
      showAll: true,
      view: true,
      display: [],
      // refresh: false,
      // kirkNum2: 0,
    };
    // if (window.performance) {
    //   if (performance.navigation.type === 1) {
    //     alert('This page is reloaded');
    //   } else {
    //     alert('This page is not reloaded');
    //   }
    // }
    // To use a method on JSX you have to bind it here.
    this.getKeyword = this.getKeyword.bind(this);
    this.getShowAll = this.getShowAll.bind(this);
    this.getView = this.getView.bind(this);
    this.getDisplay = this.getDisplay.bind(this);
    // this.getKirkNum2 = this.getKirkNum2.bind(this);
    // this.setDisplay = this.setDisplay.bind(this);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
    this.props.fetchInputs();
    // console.log('kirkNum on main is ', this.props.kirkNum);
  }

  // componentDidUpdate() {
  //   setInterval(() => this.props.fetchKirks(), 1800000); // 30 min
  //   // setInterval(() => this.props.fetchInputs(), 1800000); // 30 min
  // }

  getKeyword(keyword) {
    this.setState({
      keyword: keyword,
    });
    // console.log('keyword on main is ', keyword);
    // console.log('this.state.keyword on main is ', this.state.keyword);
  }

  getShowAll(showAll) {
    // console.log('showAll on main is ', showAll);
    this.setState({ showAll: showAll });
  }

  getView(view) {
    // console.log('view on main is ', view);
    this.setState({ view: view });
  }

  getDisplay(display) {
    console.log('display on main is ', display);
    this.setState({ display: display });
    //これだけで暴走する
    //ListDataで親stateの書き換えを行うからだろうか？
    //しかし、それはgetViewでも同じことをしている
    //Headerからview情報を得て、このviewをListDataに渡している...
    //いや、いない。mainの中で使っている
    //しかし、子コンポで親stateを変えているという構造は同じ
    //暴走すること以外にはうまく行っている
    //検索した結果のdisplayがmainでもheaderでも参照できている
    //問題は暴走することだ
    //これは親→子→親...と続く暴走なのだろう
    //どうすれば断ち切れるのか？
    //検索を無限に繰り返している？
    //今表示している状態というのはどこかのstateにあるはずでそれをheaderで参照すればいい

    // return display;
    // this.props.state = { display: display };
  }
  // display = this.getDisplay();

  // setDisplay(display) {
  //   this.setState({
  //     display: this.getDisplay(display),
  //   });
  // }

  // prettier-ignoree
  // search(myInputs) {
  //   console.log('you are in keyword');
  //   const keywordArray = this.state.keyword.split(/(\s+)/);
  //   var keywords = [];
  //   let j = 0;
  //   for (let i = 0; i < keywordArray.length; i++) {
  //     if (keywordArray[i] !== ' ') {
  //       keywords[j] = keywordArray[i].toLowerCase();
  //       j = j + 1;
  //     }
  //   }
  //   // new Promise((resolve) => {
  //   const foundInputs2 = myInputs.filter((curr) => {
  //     const test = keywords.map(
  //       (keyword) =>
  //         curr.date.toLowerCase().includes(keyword) ||
  //         curr.place.toLowerCase().includes(keyword) ||
  //         curr.person.toLowerCase().includes(keyword) ||
  //         curr.subject.toLowerCase().includes(keyword) ||
  //         curr.reason.toLowerCase().includes(keyword) ||
  //         curr.condition.toLowerCase().includes(keyword) ||
  //         curr.data.toLowerCase().includes(keyword) ||
  //         curr.unit.toLowerCase().includes(keyword)
  //     );
  //     return test.every((logic) => logic === true);
  //   });
  //   //   resolve(foundInputs2);
  //   // }).then((foundInputs2) => {
  //   //   this.setState({ display: foundInputs2 });
  //   return foundInputs2;
  // }

  render() {
    const ForgotPasswordPage = () => {
      return (
        <div>
          <Forgot forgotPassword={this.props.forgotPassword} />
        </div>
      );
    };
    const ResetPasswordPage = () => {
      return (
        <div>
          <Reset />
        </div>
      );
    };
    const KirkPage = () => {
      let myKirks = [];
      // console.log('showAll on main is ', this.props.showAll.value);
      // console.log('showAll on DataPage of main is ', this.state.showAll);
      for (let i = 0; i < this.props.kirks.kirks.length; i++) {
        if (this.state.showAll === true) {
          myKirks = this.props.kirks.kirks;
          break;
        } else if (this.props.kirks.kirks[i].user === this.props.auth.id) {
          myKirks.push(this.props.kirks.kirks[i]);
        } else {
          // meaning if the data is someone else's, go on next.
          continue;
        }
      }
      return (
        <div>
          <Kirk
            resetKirkForm={this.props.resetKirkForm}
            postKirk={this.props.postKirk}
            // fetchKirks={this.props.fetchKirks}
          />

          <div className="col-12 mt-3">
            <ListKirk
              resetKirkForm={this.props.resetKirkForm}
              // kirks={this.props.kirks.kirks}
              kirks={myKirks}
              isLoading={this.props.kirks.isLoading}
              errMess={this.props.kirks.errMess}
              deleteKirk={this.props.deleteKirk}
              updateKirk={this.props.updateKirk}
              keyword={this.state.keyword}
              auth={this.props.auth}
              // kirkNum2={this.props.kirkNum2}
              // getKirkNum2={this.getKirkNum2}
            />
          </div>
        </div>
      );
    };

    const DataPage = () => {
      let myInputs = [];
      // console.log('showAll on main is ', this.props.showAll.value);
      // console.log('showAll on DataPage of main is ', this.state.showAll);
      for (let i = 0; i < this.props.inputs.inputs.length; i++) {
        if (this.state.showAll === true) {
          myInputs = this.props.inputs.inputs;
          break;
        } else if (this.props.inputs.inputs[i].user === this.props.auth.id) {
          myInputs.push(this.props.inputs.inputs[i]);
        } else {
          // meaning if the data is someone else's, go on next.
          continue;
        }
      }

      // let foundInputs2 = this.search(myInputs)
      // // if (this.state.keyword) {
      // this.search(myInputs);
      // // }

      console.log('myInputs is ', myInputs);
      // if (window.innerWidth < 720) {
      //   this.setState({ view: false });
      // }
      return (
        <div>
          <Data
            resetInputForm={this.props.resetInputForm}
            postInput={this.props.postInput}
            // fetchInputs={this.props.fetchInputs}
          />
          <div className="col-12 mt-3">
            {this.state.view ? (
              <ListData
                resetInputForm={this.props.resetInputForm}
                // inputs={this.props.inputs.inputs}
                inputs={myInputs}
                isLoading={this.props.inputs.isLoading}
                errMess={this.props.inputs.errMess}
                deleteInput={this.props.deleteInput}
                updateInput={this.props.updateInput}
                keyword={this.state.keyword}
                auth={this.props.auth}
                getDisplay={this.getDisplay}
              />
            ) : (
              <ListKirk2
                resetKirkForm={this.props.resetInputForm}
                // kirks={this.props.kirks.kirks}
                kirks={myInputs}
                isLoading={this.props.inputs.isLoading}
                errMess={this.props.inputs.errMess}
                deleteKirk={this.props.deleteInput}
                updateKirk={this.props.updateInput}
                keyword={this.state.keyword}
                auth={this.props.auth}
                // kirkNum2={this.props.kirkNum2}
                // getKirkNum2={this.getKirkNum2}
              />
            )}
          </div>
        </div>
      );
    };

    return (
      <div>
        <Header
          auth={this.props.auth}
          loginUser={this.props.loginUser}
          pwChangeUser={this.props.pwChangeUser}
          signupUser={this.props.signupUser}
          logoutUser={this.props.logoutUser}
          kirks={this.props.kirks.kirks}
          inputs={this.props.inputs.inputs}
          getKeyword={this.getKeyword}
          getShowAll={this.getShowAll}
          getView={this.getView}
          resetInputForm={this.props.resetInputForm}
          display={this.state.display}
          // display={foundInputs2}
          // kirkNum2={this.props.kirkNum2}
        />
        <Routes>
          <Route path="/" element={<DataPage />} />
          <Route exact path="/inputs" element={<DataPage />} />
          <Route exact path="/kirks" element={<KirkPage />} />
          <Route
            exact
            path="/users/forgot-password"
            element={<ForgotPasswordPage />}
          />
          {/* <Route
            exact
            path="/users/reset-password/:id/:token"
            element={<ResetPasswordPage />}
          /> */}
        </Routes>
        <div className="row justify-content-center">
          <div className="col-auto">
            <p>© Copyright 2022~2024 Cage</p>
          </div>
        </div>
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Main);
