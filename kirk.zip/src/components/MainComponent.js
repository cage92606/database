import React, { Component } from 'react';
import ReactSearchBox from 'react-search-box';
import Contact from './ContactComponent';
import Header from './HeaderComponent';
// import LoadFile, { array } from './LoadFileComponent';
import LoadFile from './LoadFileComponent';
import { Routes, Route, Navigate } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  postKirk,
  fetchKirks,
  loginUser,
  signupUser,
  deleteKirk,
  updateKirk,
  logoutUser,
  getSearchWord,
} from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';
import { foundKirks } from './SearchComponent';
import withRouter from './withRouterComponent';
// import { Table } from 'reactstrap';
// import Table from './TableComponent';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
    auth: state.auth,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  loginUser: (creds) => dispatch(loginUser(creds)),
  signupUser: (creds) => dispatch(signupUser(creds)),
  logoutUser: () => dispatch(logoutUser()),
  postKirk: (
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      postKirk(
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  deleteKirk: (kirkId) => dispatch(deleteKirk(kirkId)),
  // updateKirk: (kirkId) => dispatch(updateKirk(kirkId)),
  updateKirk: (
    kirkId,
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      updateKirk(
        kirkId,
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  // getKeyword: (keyword) => dispatch(getKeyword(keyword)),
});

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
    };
    // To use a method on JSX you have to bind it here.
    this.getKeyword = this.getKeyword.bind(this);
    // this.getFoundKirks = this.getFoundKirks.bind(this);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
    // console.log(array);
  }

  // getFoundKirks = (foundKirks) => {
  //   this.props.kirks.kirks = foundKirks;
  //   // this.searchResults = foundKirks;
  //   // this.setState({
  //   //   kirks: foundKirks,
  //   // });
  //   // propskirks: foundKirks
  // };

  getKeyword(keyword) {
    this.setState({
      // keyword: this.state.keyword,
      keyword: keyword,
    });
    console.log('keyword on main is ', keyword);
    console.log('this.state.keyword on main is ', this.state.keyword);
    // console.log(this.state.keyword);
    // return keyword;
  }

  // prettier-ignoreee
  render() {
    return (
      <div>
        <Header
          auth={this.props.auth}
          loginUser={this.props.loginUser}
          signupUser={this.props.signupUser}
          logoutUser={this.props.logoutUser}
          kirks={this.props.kirks.kirks}
          getKeyword={this.getKeyword}
          // getFoundKirks={this.getFoundKirks}
          // foundKirks={this.state.foundKirks}
        />
        {/* <LoadFile>
          <div style={{ textAlign: 'center' }}>
            <form>
              <input type={'file'} accept={'.csv'} />
              <button>IMPORT CSV</button>
            </form>
          </div>
        </LoadFile> */}

        {/* <Routes> */}
        {/* <Table></Table> */}
        {/* <Routes
          path="/kirks"
          component={() => (
            <Contact
              resetKirkForm={this.props.resetKirkForm}
              postKirk={this.props.postKirk}
              // postKirk={array}
            />
          )}
        /> */}

        <Contact
          resetKirkForm={this.props.resetKirkForm}
          postKirk={this.props.postKirk}
          // postKirk={array}
        />

        <Routes to="/kirks" />
        {/* </Routes> */}
        {/* <div className="container"> */}
        {/* <div className="row"> */}
        <div className="col-12 mt-3">
          {/* <CSVLink data={csvData}>Download</CSVLink> */}
          {/* <ReactSearchBox
            placeholder="Placeholder"
            value="Doe"
            data={this.kirks.kirks}
            callback={(record) => console.log(record)}
          /> */}
          <ListKirk
            resetKirkForm={this.props.resetKirkForm}
            kirks={this.props.kirks.kirks}
            // keyword={this.props.keyword}
            isLoading={this.props.kirks.isLoading}
            errMess={this.props.kirks.errMess}
            deleteKirk={this.props.deleteKirk}
            updateKirk={this.props.updateKirk}
            // getFoundKirks={this.getFoundKirks}
            keyword={this.state.keyword}
            // keyword={this.getKeyword()}
            // keyword={this.props.keyword}
          />
        </div>
        {/* </div> */}
        {/* </div> */}
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Main);

// export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Main));
