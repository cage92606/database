import React, { Component } from 'react';
import Contact from './ContactComponent';
import Header from './HeaderComponent';
import { Switch, Route, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { postKirk, fetchKirks } from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  postKirk: (date, place, person, subject, reason, how) =>
    dispatch(postKirk(date, place, person, subject, reason, how)),
});

class Main extends Component {
  constructor(props) {
    super(props);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
  }

  // onDishSelect(dishId) {
  //   this.setState({ selectedDish: dishId });
  // }

  // prettier-ignoreee
  render() {
    return (
      <div>
        <Header />
        <Switch>
          <Route
            path="/kirks"
            component={() => (
              <Contact
                resetKirkForm={this.props.resetKirkForm}
                postKirk={this.props.postKirk}
              />
            )}
          />
          <Redirect to="/kirks" />
        </Switch>
        {/* <div className="container"> */}
        {/* <div className="row"> */}
        <div className="col-12 mt-3">
          <ListKirk
            kirks={this.props.kirks.kirks}
            isLoading={this.props.kirks.isLoading}
            errMess={this.props.kirks.errMess}
          />
        </div>
        {/* </div> */}
        {/* </div> */}
      </div>
    );
  }
}
export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Main));
