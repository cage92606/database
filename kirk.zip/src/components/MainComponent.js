import React, { Component, useEffect } from 'react';
import ReactSearchBox from 'react-search-box';
import Kirk from './KirkComponent';
import Data from './DataComponent';
import Header from './HeaderComponent';
import { Link, BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { connect } from 'react-redux';
import {
  postKirk,
  fetchKirks,
  loginUser,
  signupUser,
  deleteKirk,
  updateKirk,
  logoutUser,
  postInput,
  fetchInputs,
  deleteInput,
  updateInput,
  // showAll,
  // showMine,
  // getSearchWord,
  // updateKirkNum,
  // getKirkNum,
  // updateKirkNum,
} from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import ListKirk from './ListKirkComponent';
import ListKirk2 from './ListKirk2Component';
import ListData from './ListDataComponent';
import { foundKirks } from './SearchComponent';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
// import * as ReactDOM from 'react-dom/client';

const mapStateToProps = (state) => {
  return {
    kirks: state.kirks,
    auth: state.auth,
    inputs: state.inputs,
    // kirkNum: state.kirkNum,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchKirks: () => {
    dispatch(fetchKirks());
  }, // This is a THUNK
  fetchInputs: () => {
    dispatch(fetchInputs());
  }, // This is a THUNK
  resetKirkForm: () => {
    dispatch(actions.reset('kirk'));
  }, // This is a THUNK
  resetInputForm: () => {
    dispatch(actions.reset('input'));
  }, // This is a THUNK
  loginUser: (creds) => dispatch(loginUser(creds)),
  // showAll: (value) => dispatch(showAll(value)),
  // showMine: () => dispatch(showMine()),
  signupUser: (creds) => dispatch(signupUser(creds)),
  logoutUser: () => dispatch(logoutUser()),
  postKirk: (
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      postKirk(
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  postInput: (date, place, person, subject, reason, condition, data, unit) =>
    dispatch(
      postInput(date, place, person, subject, reason, condition, data, unit)
    ),
  deleteKirk: (kirkId) => dispatch(deleteKirk(kirkId)),
  deleteInput: (inputId) => dispatch(deleteInput(inputId)),
  updateKirk: (
    kirkId,
    date,
    place,
    person,
    subject,
    reason,
    how,
    data,
    work,
    news,
    buy,
    utilities,
    // symptoms,
    events,
    health,
    foods,
    invests
  ) =>
    dispatch(
      updateKirk(
        kirkId,
        date,
        place,
        person,
        subject,
        reason,
        how,
        data,
        work,
        news,
        buy,
        utilities,
        // symptoms,
        events,
        health,
        foods,
        invests
      )
    ),
  updateInput: (
    inputId,
    date,
    place,
    person,
    subject,
    reason,
    condition,
    data,
    unit
  ) =>
    dispatch(
      updateInput(
        inputId,
        date,
        place,
        person,
        subject,
        reason,
        condition,
        data,
        unit
      )
    ),
});

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keyword: '',
      showAll: true,
      view: true,
      // refresh: false,
      // kirkNum2: 0,
    };
    // To use a method on JSX you have to bind it here.
    this.getKeyword = this.getKeyword.bind(this);
    this.getShowAll = this.getShowAll.bind(this);
    this.getView = this.getView.bind(this);
    // this.getKirkNum2 = this.getKirkNum2.bind(this);
  }
  // a lifecycle method, will be called or will be executed just after this component gets mounted into the view of my application.
  componentDidMount() {
    this.props.fetchKirks();
    this.props.fetchInputs();
    // console.log('kirkNum on main is ', this.props.kirkNum);
  }

  // componentDidUpdate() {
  //   setInterval(() => this.props.fetchKirks(), 1800000); // 30 min
  //   // setInterval(() => this.props.fetchInputs(), 1800000); // 30 min
  // }

  getKeyword(keyword) {
    this.setState({
      keyword: keyword,
    });
    console.log('keyword on main is ', keyword);
    console.log('this.state.keyword on main is ', this.state.keyword);
  }

  getShowAll(showAll) {
    console.log('showAll on main is ', showAll);
    this.setState({ showAll: showAll });
  }

  getView(view) {
    console.log('view on main is ', view);
    this.setState({ view: view });
  }

  // prettier-ignoreee
  render() {
    const KirkPage = () => {
      let myKirks = [];
      // console.log('showAll on main is ', this.props.showAll.value);
      // console.log('showAll on DataPage of main is ', this.state.showAll);
      for (let i = 0; i < this.props.kirks.kirks.length; i++) {
        if (this.state.showAll === true) {
          myKirks = this.props.kirks.kirks;
          break;
        } else if (this.props.kirks.kirks[i].user === this.props.auth.id) {
          myKirks.push(this.props.kirks.kirks[i]);
        } else {
          // meaning if the data is someone else's, go on next.
          continue;
        }
      }
      return (
        <div>
          <Kirk
            resetKirkForm={this.props.resetKirkForm}
            postKirk={this.props.postKirk}
            // fetchKirks={this.props.fetchKirks}
          />

          <div className="col-12 mt-3">
            <ListKirk
              resetKirkForm={this.props.resetKirkForm}
              // kirks={this.props.kirks.kirks}
              kirks={myKirks}
              isLoading={this.props.kirks.isLoading}
              errMess={this.props.kirks.errMess}
              deleteKirk={this.props.deleteKirk}
              updateKirk={this.props.updateKirk}
              keyword={this.state.keyword}
              auth={this.props.auth}
              // kirkNum2={this.props.kirkNum2}
              // getKirkNum2={this.getKirkNum2}
            />
          </div>
        </div>
      );
    };

    const DataPage = () => {
      let myInputs = [];
      // console.log('showAll on main is ', this.props.showAll.value);
      console.log('showAll on DataPage of main is ', this.state.showAll);
      for (let i = 0; i < this.props.inputs.inputs.length; i++) {
        if (this.state.showAll === true) {
          myInputs = this.props.inputs.inputs;
          break;
        } else if (this.props.inputs.inputs[i].user === this.props.auth.id) {
          myInputs.push(this.props.inputs.inputs[i]);
        } else {
          // meaning if the data is someone else's, go on next.
          continue;
        }
      }
      console.log('myInputs is ', myInputs);
      return (
        <div>
          <Data
            resetInputForm={this.props.resetInputForm}
            postInput={this.props.postInput}
            // fetchInputs={this.props.fetchInputs}
          />
          <div className="col-12 mt-3">
            {this.state.view ? (
              <ListData
                resetInputForm={this.props.resetInputForm}
                // inputs={this.props.inputs.inputs}
                inputs={myInputs}
                isLoading={this.props.inputs.isLoading}
                errMess={this.props.inputs.errMess}
                deleteInput={this.props.deleteInput}
                updateInput={this.props.updateInput}
                keyword={this.state.keyword}
                auth={this.props.auth}
              />
            ) : (
              <ListKirk2
                resetKirkForm={this.props.resetInputForm}
                // kirks={this.props.kirks.kirks}
                kirks={myInputs}
                isLoading={this.props.inputs.isLoading}
                errMess={this.props.inputs.errMess}
                deleteKirk={this.props.deleteInput}
                updateKirk={this.props.updateInput}
                keyword={this.state.keyword}
                auth={this.props.auth}
                // kirkNum2={this.props.kirkNum2}
                // getKirkNum2={this.getKirkNum2}
              />
            )}
          </div>
        </div>
      );
    };

    return (
      <div>
        <Header
          auth={this.props.auth}
          loginUser={this.props.loginUser}
          signupUser={this.props.signupUser}
          logoutUser={this.props.logoutUser}
          kirks={this.props.kirks.kirks}
          inputs={this.props.inputs.inputs}
          getKeyword={this.getKeyword}
          getShowAll={this.getShowAll}
          getView={this.getView}
          resetInputForm={this.props.resetInputForm}
          // kirkNum2={this.props.kirkNum2}
        />
        <Routes>
          <Route exact path="/kirks" element={<KirkPage />} />
          <Route exact path="/" element={<DataPage />} />
        </Routes>
        <div className="row justify-content-center">
          <div className="col-auto">
            <p>(c) Copyright 2022 Cage</p>
          </div>
        </div>
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Main);
