import React, { Component, Fragment } from 'react';
import { useState } from 'react';
import {
  Navbar,
  NavbarBrand,
  Nav,
  NavbarToggler,
  Collapse,
  NavItem,
  Jumbotron,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  FormGroup,
  Label,
  Input,
} from 'reactstrap';
import ReactFileReader from 'react-file-reader';
import { NavLink } from 'react-router-dom';
import { CSVLink, CSVDownload } from 'react-csv';
import Search from './SearchComponent';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isNavOpen: false,
      isModalOpen: false,
      isSignupModalOpen: false,
      keyword: '',
    };
    // To use a method on JSX you have to bind it here.
    this.toggleNav = this.toggleNav.bind(this);
    this.toggleModal = this.toggleModal.bind(this);
    this.toggleSignupModal = this.toggleSignupModal.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
    this.handleSignup = this.handleSignup.bind(this);
    this.handleLogout = this.handleLogout.bind(this);
    this.handleFiles = this.handleFiles.bind(this);
    this.findKirks = this.findKirks.bind(this);
    // this.getKeyword = this.getKeyword.bind(this);
    // this.getSearchWord = this.getSearchWord.bind(this);
    // this.getFoundKirks = this.getFoundKirks.bind(this);
  }

  toggleNav() {
    this.setState({
      isNavOpen: !this.state.isNavOpen,
    });
  }

  toggleModal() {
    this.setState({
      isModalOpen: !this.state.isModalOpen,
    });
  }

  toggleSignupModal() {
    this.setState({
      isSignupModalOpen: !this.state.isSignupModalOpen,
    });
  }

  handleLogin(event) {
    this.toggleModal(); // Close the modal once the forms submitted
    // alert(
    //   `Username: ${this.username.value} Password: ${this.password.value} Remember: ${this.remember.checked}`
    // );
    this.props.loginUser({
      username: this.username.value,
      password: this.password.value,
    });
    event.preventDefault();
  }

  handleSignup(event) {
    this.toggleSignupModal(); // Close the modal once the forms submitted
    // alert(
    //   `Username: ${this.username.value} Password: ${this.password.value} Remember: ${this.remember.checked}`
    // );
    this.props.signupUser({
      username: this.signupUsername.value,
      password: this.signupPassword.value,
    });
    event.preventDefault();
  }

  handleLogout() {
    this.props.logoutUser();
  }

  handleFiles = (files) => {
    var reader = new FileReader();
    reader.onload = function (e) {
      // Use reader.result
      alert(reader.result);
    };
    reader.readAsText(files[0]);
  };

  findKirks = (keyword) => {
    this.setState({
      keyword: this.state.keyword,
    });
    const foundKirks = this.props.kirks.filter((curr) =>
      curr.subject.includes(keyword)
    );
    // getKeyword(keyword);
    // this.props.getFoundKirks(foundKirks);
    // console.log('kirks', this.props.kirks.kirks);
    this.props.getKeyword(keyword);
    // console.log('keyword', keyword);
    // console.log('foundKirks', foundKirks);
  };

  // prettier-ignore ignore
  render() {
    const csvData = [
      ['firstname', 'lastname', 'email'],
      ['John', 'Doe', 'john.doe@xyz.com'],
      ['Jane', 'Doe', 'jane.doe@xyz.com'],
    ];

    // const [keyword, setData] = useState('');
    // const findKirks = (keyword) => {
    //   this.setState({
    //     keyword: this.state.keyword,
    //   });
    //   const foundKirks = this.props.kirks.filter((curr) =>
    //     curr.subject.includes(keyword)
    //   );
    //   console.log(keyword);
    //   console.log(foundKirks);
    // };

    return (
      <Fragment>
        {/* <Navbar className="mr-auto" dark expand="md"> */}
        <Navbar dark expand="md" className="mr-auto" fixed="top">
          <div className="container">
            <NavbarToggler onClick={this.toggleNav} />
            {/* <NavbarBrand className="mr-auto" href="/">
              <img
                // src="assets/images/logo.png"
                height="30"
                width="41"
                alt="Kirk"
              />
            </NavbarBrand> */}
            {/* <div className="container">
              <div className="col-12">
                <Search />
              </div>
            </div> */}
            <Collapse isOpen={this.state.isNavOpen} navbar>
              <Nav navbar>
                <NavItem>
                  {/* <Search kirks={this.props.kirks} />{' '} */}
                  <Search
                    findKirks={this.findKirks}
                    // getKeyword={this.props.getKeyword}
                  />{' '}
                </NavItem>
                <NavItem>
                  <ReactFileReader
                    handleFiles={this.handleFiles}
                    fileTypes={'.csv'}
                  >
                    <button className="btn fa fa-upload">Upload</button>
                  </ReactFileReader>
                </NavItem>
                <NavItem>
                  {/* <CSVLink data={csvData}>Download</CSVLink> */}
                  <CSVLink data={csvData} className="btn fa fa-download">
                    Download
                  </CSVLink>
                </NavItem>
              </Nav>
              <Nav className="ms-auto" navbar>
                <NavItem>
                  {!this.props.auth.isAuthenticated ? (
                    <Fragment>
                      <Button outline onClick={this.toggleSignupModal}>
                        <span className="fa fa-sign-in fa-lg"></span> Signup
                        {this.props.auth.isFetching ? (
                          <span className="fa fa-spinner fa-pulse fa-fw"></span>
                        ) : null}
                      </Button>
                      {'  '}
                      <Button outline onClick={this.toggleModal}>
                        <span className="fa fa-sign-in fa-lg"></span> Login
                        {this.props.auth.isFetching ? (
                          <span className="fa fa-spinner fa-pulse fa-fw"></span>
                        ) : null}
                      </Button>
                    </Fragment>
                  ) : (
                    <div className="navbar-text mr-3">
                      {this.props.auth.user.username}
                      <Button outline onClick={this.handleLogout}>
                        <span className="fa fa-sign-out fa-lg"></span> Logout
                        {this.props.auth.isFetching ? (
                          <span className="fa fa-spinner fa-pulse fa-fw"></span>
                        ) : null}
                      </Button>
                    </div>
                  )}
                </NavItem>
              </Nav>
            </Collapse>
          </div>
        </Navbar>
        <Modal isOpen={this.state.isModalOpen} toggle={this.toggleModal}>
          <ModalHeader toggle={this.toggleModal}>Login</ModalHeader>
          <ModalBody>
            <Form onSubmit={this.handleLogin}>
              <FormGroup>
                <Label htmlFor="username">Username</Label>
                <Input
                  type="text"
                  id="username"
                  name="username"
                  innerRef={(input) => (this.username = input)}
                />
              </FormGroup>
              <FormGroup>
                <Label htmlFor="password">Password</Label>
                <Input
                  type="password"
                  id="password"
                  name="password"
                  innerRef={(input) => (this.password = input)}
                />
              </FormGroup>
              <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="remember"
                    innerRef={(input) => (this.remember = input)}
                  />{' '}
                  Remember me
                </Label>
              </FormGroup>
              <Button type="submit" value="submit" color="primary">
                Login
              </Button>
            </Form>
          </ModalBody>
        </Modal>

        <Modal
          isOpen={this.state.isSignupModalOpen}
          toggle={this.toggleSignupModal}
        >
          <ModalHeader toggle={this.toggleSignupModal}>Signup</ModalHeader>
          <ModalBody>
            <Form onSubmit={this.handleSignup}>
              <FormGroup>
                <Label htmlFor="signupUsername">Username</Label>
                <Input
                  type="text"
                  id="signupUsername"
                  name="signupUsername"
                  innerRef={(input) => (this.signupUsername = input)}
                />
              </FormGroup>
              <FormGroup>
                <Label htmlFor="signupPassword">Password</Label>
                <Input
                  type="password"
                  id="signupPassword"
                  name="signupPassword"
                  innerRef={(input) => (this.signupPassword = input)}
                />
              </FormGroup>
              {/* <FormGroup check>
                <Label check>
                  <Input
                    type="checkbox"
                    name="remember"
                    innerRef={(input) => (this.remember = input)}
                  />{' '}
                  Remember me
                </Label>
              </FormGroup> */}
              <Button type="submit" value="submit" color="primary">
                Signup
              </Button>
            </Form>
          </ModalBody>
        </Modal>
      </Fragment>
    );
  }
}

export default Header;
