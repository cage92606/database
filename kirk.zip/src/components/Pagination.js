import React from 'react';
import {
  Navbar,
  NavbarBrand,
  Nav,
  NavbarToggler,
  Collapse,
  NavItem,
  Jumbotron,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  FormGroup,
  Label,
  Input,
  Dropdown,
  DropdownItem,
  DropdownToggle,
  DropdownMenu,
  NavLink,
  Container,
} from 'reactstrap';

const Pagination = ({ inputListPerPage, totalInputList, paginate }) => {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalInputList / inputListPerPage); i++) {
    pageNumbers.push(i);
  }
  return (
    <div>
      <ul className="pagination ">
        {pageNumbers.map((number) => (
          <li key={number} className="page-item">
            {/* <Button onClick={() => paginate(number)}>{number}</Button> */}
            <a onClick={() => paginate(number)} href="#!" className="page-link">
              {number}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Pagination;
