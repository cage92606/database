import React, { Component, useState } from 'react';
import Kirk from './KirkComponent';
import ListKirk from './ListKirkComponent';

export default function Home() {
  return (
    <div>
      <Kirk
        resetKirkForm={this.props.resetKirkForm}
        postKirk={this.props.postKirk}
      />
      <div className="col-12 mt-3">
        <ListKirk
          resetKirkForm={this.props.resetKirkForm}
          kirks={this.props.kirks.kirks}
          isLoading={this.props.kirks.isLoading}
          errMess={this.props.kirks.errMess}
          deleteKirk={this.props.deleteKirk}
          updateKirk={this.props.updateKirk}
          keyword={this.state.keyword}
          // kirkNum2={this.props.kirkNum2}
          // getKirkNum2={this.getKirkNum2}
        />
      </div>
    </div>
  );
}
