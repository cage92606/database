import React, { Component } from 'react';
// import axios from 'axios';
export class Reset extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit = (e) => {
    e.preventDefault();

    const data = {
      token: this.props.match.params.id,
      passwrod: this.password,
      password_confirm: this.password_confirm,
    };

    fetch('/reset', {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      body: data,
    }).catch((err) => {
      console.log(err);
    });
  };

  render() {
    return (
      <div className="container main">
        <form onSubmit={this.handleSubmit}>
          <h3>Reset Password</h3>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              onChange={(e) => (this.password = e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Password Confirm</label>
            <input
              type="password"
              className="form-control"
              placeholder="Password Confirm"
              onChange={(e) => (this.password_confirm = e.target.value)}
            />
          </div>

          <button className="btn btn-primary btn-block">Submit</button>
        </form>
      </div>
    );
  }
}
export default Reset;
