import React, { Component } from 'react';
import axios from 'axios';
import { baseUrl } from '../shared/baseUrl';
export class Forgot extends Component {
  // handleSubmit = (e) => {
  //   e.preventDefault();

  //   const data = {
  //     email: this.email,
  //   };

  //   axios
  //     .post('forgot', data)
  //     .then((res) => {
  //       console.log(res);
  //     })
  //     .catch((err) => console.log(err));
  // };

  constructor(props) {
    super(props);
    this.state = {
      email: '',
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { email } = this.state;
    console.log({ email });
    // alert('Current State is: ' + JSON.stringify(values));
    // this.props.resetKirkForm();
    // event.stopImmediatePropagation();
    // this.props.forgotPassword(value.email);
    this.props.forgotPassword({ email });
  };

  // handleSubmit(e) {
  //   e.preventDefault();
  //   const { email } = this.state;
  //   console.log(email);
  //   fetch(baseUrl + 'users/forgot-password', {
  //     method: 'POST',
  //     crossDomain: true,
  //     headers: {
  //       'Content-Type': 'application/json',
  //       Accept: 'application/json',
  //       // 'Access-Control-Allow-Origin': '*',
  //     },
  //     body: JSON.stringify(email),
  //     credentials: 'same-origin',
  //   })
  //     .then((res) => res.json())
  //     .then((data) => {
  //       console.log(data, 'userRegister');
  //       alert(data.status);
  //     });
  // }

  render() {
    return (
      <div className="container main">
        {/* <form onSubmit={this.handleSubmit}> */}
        <form onSubmit={this.handleSubmit}>
          <h3>Forgot Password</h3>

          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              className="form-control"
              placeholder="email"
              onChange={(e) => this.setState({ email: e.target.value })}
            />
          </div>

          <button className="btn btn-primary btn-block">Submit</button>
        </form>
      </div>
    );
  }
}
export default Forgot;
