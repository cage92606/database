export const baseUrl = 'https://kirk009.herokuapp.com/'
// export const baseUrl = 'http://localhost:3000/';
// test  22
// export const baseUrl = 'https://localhost:3443/';
// X export const baseUrl = 'https://192.168.11.3:3443/';
// X export const baseUrl = 'https://127.0.0.1:3443/';
