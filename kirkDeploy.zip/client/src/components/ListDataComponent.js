/* eslint-disable react/jsx-pascal-case */
import React, { useEffect, Fragment } from 'react';
import { useState } from 'react';
// import { Control } from 'react-redux-form';
import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  Table,
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';
// import { fetchInputs } from '../redux/ActionCreators';
// import { fetchKirks, fetchInputs } from '../redux/ActionCreators';

function RenderInputTable({ input, deleteInput, updateInput, resetInputForm }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    updateInput(
      input._id,
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.condition,
      value.data,
      value.unit
    );
    resetInputForm();
  };

  return (
    <tr>
      <Modal
        isOpen={isOpen}
        toggle={toggleModal}
        size="lg"
        style={{ maxWidth: '1000px', width: '100%' }}
      >
        <ModalHeader toggle={toggleModal}>Update Input</ModalHeader>
        <ModalBody>
          <Form onSubmit={handleSubmit} model="input">
            <Row className="form-group mb-2">
              <Label htmlFor="date">date</Label>
              <Control.text
                model=".date"
                id="date"
                name="date"
                defaultValue={input.date}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="place">place</Label>
              <Control.text
                model=".place"
                id="place"
                name="place"
                defaultValue={input.place}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="person">person</Label>
              <Control.text
                model=".person"
                id="person"
                name="person"
                defaultValue={input.person}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="subject">subject</Label>
              <Control.text
                model=".subject"
                id="subject"
                name="subject"
                defaultValue={input.subject}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="reason">reason</Label>
              <Control.text
                model=".reason"
                id="reason"
                name="reason"
                defaultValue={input.reason}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="condition">condition</Label>
              <Control.text
                model=".condition"
                id="condition"
                name="condition"
                defaultValue={input.condition}
                className="form-control"
              />
            </Row>
            <Row className="form-group mb-2">
              <Label htmlFor="data">data</Label>
              <Control.text
                model=".data"
                id="data"
                name="data"
                defaultValue={input.data}
                className="form-control"
              />
              {/* </Row>
              <Row className="form-group mb-2"> */}
              <Label htmlFor="unit">unit</Label>
              <Control.text
                model=".unit"
                id="unit"
                name="unit"
                defaultValue={input.unit}
                className="form-control"
              />
            </Row>
            <Button type="submit" value="submit" color="primary">
              Submit
            </Button>
          </Form>
        </ModalBody>
      </Modal>

      <td>
        <Button outline color="primary" onClick={toggleModal}>
          <span className="fa fa-edit"></span>
        </Button>
      </td>
      <td>{input.date}</td>
      <td>{input.place}</td>
      <td>{input.person}</td>
      <td>{input.subject}</td>
      <td>{input.reason}</td>
      <td>{input.condition}</td>
      <td>{input.data}</td>
      <td>{input.unit}</td>
      <td>
        {' '}
        <Button
          outline
          color="danger"
          onClick={() => {
            if (window.confirm('Are you sure?')) deleteInput(input._id);
          }}
        >
          <span className="fa fa-times"></span>
        </Button>
      </td>
    </tr>
  );
}

function RenderInputItem({ input, deleteInput, updateInput, resetInputForm }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    updateInput(
      input._id,
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.condition,
      value.data,
      value.unit
    );
    resetInputForm();
  };

  return (
    <ListGroup>
      <ListGroupItem>
        <Button outline color="primary" onClick={toggleModal}>
          <span className="fa fa-edit"></span>
        </Button>
        <Modal
          isOpen={isOpen}
          toggle={toggleModal}
          size="lg"
          style={{ maxWidth: '1000px', width: '100%' }}
        >
          <ModalHeader toggle={toggleModal}>Update Input</ModalHeader>
          <ModalBody>
            <Form onSubmit={handleSubmit} model="input">
              <Row className="form-group mb-2">
                <Label htmlFor="date">date</Label>
                <Control.text
                  model=".date"
                  id="date"
                  name="date"
                  defaultValue={input.date}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="place">place</Label>
                <Control.text
                  model=".place"
                  id="place"
                  name="place"
                  defaultValue={input.place}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="person">person</Label>
                <Control.text
                  model=".person"
                  id="person"
                  name="person"
                  defaultValue={input.person}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="subject">subject</Label>
                <Control.text
                  model=".subject"
                  id="subject"
                  name="subject"
                  defaultValue={input.subject}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="reason">reason</Label>
                <Control.text
                  model=".reason"
                  id="reason"
                  name="reason"
                  defaultValue={input.reason}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="condition">condition</Label>
                <Control.text
                  model=".condition"
                  id="condition"
                  name="condition"
                  defaultValue={input.condition}
                  className="form-control"
                />
              </Row>
              <Row className="form-group mb-2">
                <Label htmlFor="data">data</Label>
                <Control.text
                  model=".data"
                  id="data"
                  name="data"
                  defaultValue={input.data}
                  className="form-control"
                />
                {/* </Row>
              <Row className="form-group mb-2"> */}
                <Label htmlFor="unit">unit</Label>
                <Control.text
                  model=".unit"
                  id="unit"
                  name="unit"
                  defaultValue={input.unit}
                  className="form-control"
                />
              </Row>
              <Button type="submit" value="submit" color="primary">
                Submit
              </Button>
            </Form>
          </ModalBody>
        </Modal>
        {`  ${input.date} `}
        {input.place.indexOf('http') === 0 ? (
          input.place ? (
            // <a href="http://www.google.com">Googe</a>
            <a href={input.place} target="_blank" rel="noreferrer">
              {input.place + ' '}{' '}
            </a>
          ) : (
            ''
          )
        ) : (
          input.place
        )}
        {`${input.person} `}
        {<b>{input.subject}</b>} {`${input.reason} `}
        {`${input.condition} `}
        {/* {input.data !== undefined ? (input.data ? `${input.data} ` : '') : ''} */}
        {input.data !== undefined ? (
          input.data ? (
            <code>{input.data}</code>
          ) : (
            ''
          )
        ) : (
          ''
        )}
        {`${input.unit} `}
        <Button
          outline
          color="danger"
          onClick={() => {
            if (window.confirm('Are you sure?')) deleteInput(input._id);
          }}
        >
          <span className="fa fa-times"></span>
        </Button>
      </ListGroupItem>
    </ListGroup>
    //   </div>
    // </div>
  );
}

export let input_num;
console.log('input_num in ListData is ', input_num);

export default function ListData(props) {
  // useEffect(() => {
  //   props.fetchInputs();
  // });
  if (props.isLoading) {
    return (
      <div className="container">
        <div className="row">
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className="container">
        <div className="row">
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    console.log('you are in keyword');
    const keywordArray = props.keyword.split(/(\s+)/);
    var keywords = [];
    let j = 0;
    for (let i = 0; i < keywordArray.length; i++) {
      if (keywordArray[i] !== ' ') {
        keywords[j] = keywordArray[i].toLowerCase();
        j = j + 1;
      }
    }
    console.log('keywords is ', keywords);

    // const test = currentKeyWord => currentKeyWord
    const foundInputs2 = props.inputs.filter(
      (curr) =>
        keywords.every((word) => curr.date.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.place.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.person.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.subject.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.reason.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.condition.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.data.toLowerCase().includes(word)) ||
        keywords.every((word) => curr.unit.toLowerCase().includes(word))
    );

    const inputList = foundInputs2.map((input) => {
      return (
        <Fragment>
          {/* <div key={input._id}> */}
          {/* <RenderInputItem */}
          <RenderInputTable
            input={input}
            deleteInput={props.deleteInput}
            updateInput={props.updateInput}
            resetInputForm={props.resetInputForm}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    input_num = inputList.length;
    console.log('number of inputs found is ', input_num);

    return (
      <div>
        {/* <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                {' '}
                <h5>{input_num} items</h5>
                {inputList.reverse()}
              </CardBody>
            </Col>
          </Row>
        </Card> */}
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <h5>{input_num} items</h5>
                <Table bordered responsive hover striped>
                  <thead>
                    <tr>
                      <th>Edit</th>
                      <th>date</th>
                      <th>place</th>
                      <th>person</th>
                      <th>subject</th>
                      <th>reason</th>
                      <th>condition</th>
                      <th>data</th>
                      <th>unit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>{inputList.reverse()}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else if (props.inputs !== null) {
    console.log('you are in inputs');
    console.log('keyword is ', props.keyword);
    const inputList = props.inputs.map((input) => {
      return (
        <Fragment>
          {/* <div key={input._id}> */}
          {/* <RenderInputItem */}
          <RenderInputTable
            input={input}
            deleteInput={props.deleteInput}
            updateInput={props.updateInput}
            resetInputForm={props.resetInputForm}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    input_num = inputList.length;
    console.log('number of inputs found is ', input_num);

    return (
      <div>
        <Card>
          <Row className="form-group">
            <Col>
              <CardBody>
                <h5>{input_num} items</h5>
                <Table bordered responsive hover striped>
                  <thead>
                    <tr>
                      <th>Edit</th>
                      <th>date</th>
                      <th>place</th>
                      <th>person</th>
                      <th>subject</th>
                      <th>reason</th>
                      <th>condition</th>
                      <th>data</th>
                      <th>unit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>{inputList.reverse()}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
      </div>
    );
  } else {
    return <div></div>;
  }
}
