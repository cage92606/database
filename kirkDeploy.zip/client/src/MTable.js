import MaterialTable from 'material-table';
import { data } from '../data';

const MTable = () => {
  //...
};
export default MTable;
