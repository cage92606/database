const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const authenticate = require('../authenticate.js') // *5
const cors = require('./cors') // *9
const Kirks = require('../models/kirks')

const kirkRouter = express.Router()

kirkRouter.use(bodyParser.json())

kirkRouter
  .route('/')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200)
    }
  }) // *9

  .get(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    Kirks.find(req.query)
      .then(
        (kirks) => {
          let myKirks = []
          for (i = 0; i < kirks.length; i++) {
            if (
              JSON.stringify(req.user._id) ===
              JSON.stringify('636fa4bc2900040016631d0d')
            ) {
              myKirks = kirks
              break
            } else if (
              JSON.stringify(req.user._id) === JSON.stringify(kirks[i].user)
            ) {
              myKirks.push(kirks[i])
            } else {
              continue
            }
          }
          if (!myKirks) {
            var err = new Error('You have no kirk!')
            err.status = 404 // Not found
            return next(err)
          } else {
            res.statusCode = 200
            res.setHeader('Content-Type', 'application/json')
            res.json(myKirks)
          }
        },
        (err) => next(err),
      )
      .catch((err) => next(err))
  })

  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    const kirk = req.body
    kirk.user = req.user._id
    // Kirks.create(req.body)
    Kirks.create(kirk)
      .then(
        (kirk) => {
          // console.log('Kirk Created', kirk);
          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk)
        },
        (err) => next(err),
      )
      .catch((err) => next(err))
  })
  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403 //forbidden
    res.end('PUT operation NOT supported on /kirks')
  })
// .delete(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
//   Kirks.remove({})
//     .then(
//       (resp) => {
//         res.statusCode = 200;
//         res.setHeader('Content-Type', 'application/json');
//         // res.set({ 'Access-Control-Allow-Origin': '*' });
//         res.json(resp);
//       },
//       (err) => next(err)
//     )
//     .catch((err) => next(err));
// });

kirkRouter
  .route('/:kirkId')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200)
    }
  }) // *9
  .get(cors.cors, (req, res, next) => {
    Kirks.findById(req.params.kirkId)
      .then(
        (kirk) => {
          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk)
        },
        (err) => next(err),
      )
      .catch((err) => next(err))
  })
  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403 //forbidden
    res.end(`POST operation NOT supported on /kirks/${req.params.kirkId}`)
  })
  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    console.log('You are in then(), right before findByIdAndUpdate')
    console.log('req.body is ', req.body)
    Kirks.findByIdAndUpdate(
      req.params.kirkId,
      // { $set: req.body },
      {
        $set: req.body,
      },
      // { $set: query },
      { new: true },
    )
      .then(
        (kirk) => {
          console.log('You are in then(), right before findById')

          // Kirks.findById(kirk._id).then((kirk) => {
          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk)
          // });
        },
        (err) => next(err),
      )
      .catch((err) => next(err))
  })

  .delete(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    Kirks.findByIdAndRemove(req.params.kirkId)
      .then(
        (resp) => {
          Kirks.find({}).then((kirks) => {
            let myKirks = []
            for (i = 0; i < kirks.length; i++) {
              if (
                JSON.stringify(req.user._id) ===
                JSON.stringify('636fa4692900040016631d0c')
              ) {
                myKirks = kirks
                break
              } else if (
                JSON.stringify(req.user._id) === JSON.stringify(kirks[i].user)
              ) {
                myKirks.push(kirks[i])
              } else {
                continue
              }
            }
            if (!myKirks) {
              var err = new Error('You have no kirk!')
              err.status = 404 // Not found
              return next(err)
            } else {
              res.statusCode = 200
              res.setHeader('Content-Type', 'application/json')
              res.json(myKirks)
            }
          })
        },
        (err) => next(err),
      )
      .catch((err) => next(err))
  })

module.exports = kirkRouter
