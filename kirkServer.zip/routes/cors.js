// *9 added this file
const express = require('express');
const cors = require('cors');
const app = express();

const whitelist = [
  'http://localhost:3000', // server
  'https://localhost:3443', // server
  'http://192.168.11.3:3001', // client
  'http://Mac-mini.local:3001', // client
  'https://Mac-mini.local:3443', // client
  'http://iPhone:3001',
];

var corsOptionsDelegate = (req, callback) => {
  var corsOptions;

  if (whitelist.indexOf(req.header('Origin')) !== -1) {
    corsOptions = { origin: true };
    // Access-Control-Allow-Origin not return
  } else {
    corsOptions = { origin: false };
    // Access-Control-Allow-Origin not return
  }
  callback(null, corsOptions);
};

exports.cors = cors();
exports.corsWithOptions = cors(corsOptionsDelegate);
