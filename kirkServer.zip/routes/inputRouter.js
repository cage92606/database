const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const authenticate = require('../authenticate.js'); // *5
const cors = require('./cors'); // *9
const Inputs = require('../models/inputs');

const inputRouter = express.Router();

inputRouter.use(bodyParser.json());

inputRouter
  .route('/')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200);
    }
  }) // *9

  .get(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    Inputs.find(req.query)
      .then(
        (inputs) => {
          let myInputs = [];
          for (i = 0; i < inputs.length; i++) {
            if (
              JSON.stringify(req.user._id) ===
              JSON.stringify('6281314ef6dca7bba4e2be3a')
            ) {
              myInputs = inputs;
              break;
            } else if (
              JSON.stringify(req.user._id) === JSON.stringify(inputs[i].user)
            ) {
              myInputs.push(inputs[i]);
            } else {
              continue;
            }
          }
          if (!myInputs) {
            var err = new Error('You have no input!');
            err.status = 404; // Not found
            return next(err);
          } else {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.json(myInputs);
          }
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    const input = req.body;
    input.user = req.user._id;
    Inputs.create(input)
      .then(
        (input) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(input);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end('PUT operation NOT supported on /inputs');
  });

inputRouter
  .route('/:inputId')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200);
    }
  }) // *9
  .get(cors.cors, (req, res, next) => {
    Inputs.findById(req.params.inputId)
      .then(
        (input) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(input);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end(`POST operation NOT supported on /inputs/${req.params.inputId}`);
  })

  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    Inputs.findByIdAndUpdate(
      req.params.inputId,
      {
        $set: req.body,
      },
      { new: true }
    )
      .then(
        (input) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.json(input);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .delete(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    Inputs.findByIdAndRemove(req.params.inputId)
      .then(
        (resp) => {
          Inputs.find({}).then((inputs) => {
            let myInputs = [];
            for (i = 0; i < inputs.length; i++) {
              if (
                JSON.stringify(req.user._id) ===
                JSON.stringify('6281314ef6dca7bba4e2be3a')
              ) {
                myInputs = inputs;
                break;
              } else if (
                JSON.stringify(req.user._id) === JSON.stringify(inputs[i].user)
              ) {
                myInputs.push(inputs[i]);
              } else {
                continue;
              }
            }
            if (!myInputs) {
              var err = new Error('You have no input!');
              err.status = 404; // Not found
              return next(err);
            } else {
              res.statusCode = 200;
              res.setHeader('Content-Type', 'application/json');
              res.json(myInputs);
            }
          });
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  });

module.exports = inputRouter;
