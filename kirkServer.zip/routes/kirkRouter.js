const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const Kirks = require('../models/kirks');

const kirkRouter = express.Router();

kirkRouter.use(bodyParser.json());

kirkRouter
  .route('/')
  .get((req, res, next) => {
    console.log(req);
    Kirks.find({})
      .then(
        (kirks) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirks);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })
  .post((req, res, next) => {
    Kirks.create(req.body)
      .then(
        (kirk) => {
          console.log('Kirk Created', kirk);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })
  .put((req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end('PUT operation NOT supported on /kirks');
  })
  .delete((req, res, next) => {
    Kirks.remove({})
      .then(
        (resp) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(resp);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  });

kirkRouter
  .route('/:kirkId')
  .get((req, res, next) => {
    Kirks.findById(req.params.kirkId)
      .then(
        (kirk) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })
  .post((req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end(`POST operation NOT supported on /kirks/${req.params.kirkId}`);
  })
  .put((req, res, next) => {
    Kirks.findByIdAndUpdate(
      req.params.kirkId,
      { $set: req.body },
      { new: true }
    )
      .then(
        (kirk) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(kirk);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })
  .delete((req, res, next) => {
    Kirks.findByIdAndRemove(req.params.kirkId)
      .then(
        (resp) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(resp);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  });

module.exports = kirkRouter;
