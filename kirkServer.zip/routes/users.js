var express = require('express');
const bodyParser = require('body-parser');
var User = require('../models/user');
var passport = require('passport'); // *4
var authenticate = require('../authenticate'); // *5
const cors = require('./cors'); // *9
const app = require('../app');
var router = express.Router();
router.use(bodyParser.json());
var config = require('../config'); // *5
var jwt = require('jsonwebtoken'); // *5
var nodemailer = require('nodemailer');
require('dotenv').config();
// app.set('view engine', 'ejs');
/* GET users listing. */
var config = require('../config'); // *5
var jwt = require('jsonwebtoken'); // *5

router.get('/', cors.corsWithOptions, function (req, res, next) {
  res.send('respond with a resource');
});

router.post('/signup', cors.corsWithOptions, (req, res, next) => {
  User.register(
    new User({ username: req.body.username, email: req.body.email }),
    req.body.password,
    (err, user) => {
      if (err) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        res.json({ err: err });
      } else {
        passport.authenticate('local')(req, res, () => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.json({ success: true, status: 'Registration Successful!' });
        });
      }
    }
  ); // *4
});

// router.post('/changepassword', cors.corsWithOptions, (req, res) => {
//   User.findByUsername(req.body.username, (err, user) => {
//     if (err) {
//       res.send(err);
//     } else {
//       user.changePassword(req.body.oldpassword, req.body.newpassword, function (
//         err
//       ) {
//         if (err) {
//           res.send(err);
//         } else {
//           res.send('successfully change password');
//         }
//       });
//     }
//   });
// });

router.post('/changepassword', cors.corsWithOptions, (req, res, next) => {
  // passport.authenticate('local', (err, user, info) => {
  User.findByUsername(req.body.username, (err, user) => {
    if (err) return next(err);

    if (!user) {
      res.statusCode = 401;
      res.setHeader('Content-Type', 'application/json');
      res.json({
        success: false,
        status: 'Password Change Unsuccessful!',
        err: info,
      });
    }
    req.logIn(user, (err) => {
      if (err) {
        res.statusCode = 401;
        res.setHeader('Content-Type', 'application/json');
        res.json({
          success: false,
          status: 'Login Unsuccessful!',
          err: 'Could not log in user!',
        });
      }

      user.changePassword(req.body.oldpassword, req.body.newpassword, function (
        err
      ) {
        if (err) {
          res.statusCode = 401;
          res.setHeader('Content-Type', 'application/json');
          res.json({
            success: false,
            status: 'Password Change Unsuccessful!',
            err: 'Could not change your password!',
          });
        } else {
          var token = authenticate.getToken({ _id: req.user._id });
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.json({
            success: true,
            status: 'Password Change Successful!',
            token: token,
            id: req.user._id,
          });
        }
      });
    });
  });
});

router.post('/login', cors.corsWithOptions, (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);

    if (!user) {
      res.statusCode = 401;
      res.setHeader('Content-Type', 'application/json');
      res.json({ success: false, status: 'Login Unsuccessful!', err: info });
    }
    req.logIn(user, (err) => {
      if (err) {
        res.statusCode = 401;
        res.setHeader('Content-Type', 'application/json');
        res.json({
          success: false,
          status: 'Login Unsuccessful!',
          err: 'Could not log in user!',
        });
      }
      console.log(process.env.AUTH_EMAIL);
      console.log(process.env.AUTH_PASS);
      var token = authenticate.getToken({ _id: req.user._id });
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.json({
        success: true,
        status: 'Login Successful!',
        token: token,
        id: req.user._id,
      });
    });
  })(req, res, next);
});

router.get('/logout', (req, res) => {
  if (req.session) {
    req.session.destroy();
    res.clearCookie('session-id');
    res.redirect('/');
  } else {
    var err = new Error('You are not logged in!');
    err.status = 403; // forbidden
    next(err);
  }
});

router.get('/checkJWTtoken', cors.corsWithOptions, (req, res) => {
  passport.authenticate('jwt', { session: false }, (err, user, info) => {
    if (err) return next(err);

    if (!user) {
      res.statusCode = 401;
      res.setHeader('Content-Type', 'application/json');
      return res.json({ status: 'JWT invalid!', success: false, err: info });
    } else {
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      return res.json({ status: 'JWT valid!', success: true, user: user });
    }
  })(req, res);
});

router.post(
  '/forgot-password',
  cors.corsWithOptions,
  async (req, res, next) => {
    try {
      const user = await User.findOne({ email: req.body.email }).exec();
      if (!user) {
        // return res.json({ status: 'User Not Exists!' });
        res.statusCode = 401;
        res.setHeader('Content-Type', 'application/json');
        return res.json({
          status: 'User Not Exists!',
          success: false,
          // err: info,
        });
      } else {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        // const secret = config.secretKey + user.password
        // const token = jwt.sign({ email: user.email, id: user._id }, secret, {
        //   expiresIn: '5m',
        // })
        // var token = authenticate.getToken({ _id: req.user._id });
        console.log('before token generation');
        const token = authenticate.getToken({
          _id: user._id,
          email: user.email,
        });

        console.log('after token generation');
        // const link = `https://kirk021.herokuapp.com/users/reset-password/${user._id}/${token}`;
        const link = `http://localhost:3000/users/reset-password/${user._id}/${token}`;
        console.log('link is ', link);
        var transporter = nodemailer.createTransport({
          // service: 'Zoho',
          host: 'smtp.zoho.jp',
          port: 465,
          secure: true, // use SSL
          auth: {
            user: process.env.AUTH_EMAIL,
            pass: process.env.AUTH_PASS,
          },
        });

        var mailOptions = {
          from: '"Kirk Manager" cage92606@zohomail.jp',
          // to: 'cage92606@gmail.com',
          to: user.email,
          subject: 'Password Reset',
          text: link,
        };
        console.log('email: ', user.email);
        transporter.sendMail(mailOptions, function (error, info) {
          if (error) {
            // console.log(error)
            console.log('error : ' + JSON.stringify(error));
            console.log('info : ' + JSON.stringify(info));
          } else {
            console.log('Email sent: ' + info.response);
            res.send(200);
            next();
          }
        });

        console.log(link);
        return res.json({ status: 'Verified', success: true, user: user });
      }
    } catch (error) {}
  }
);

router.get(
  '/reset-password/:id/:token',
  cors.corsWithOptions,
  async (req, res) => {
    const { id, token } = req.params;
    console.log(req.params);
    // const user = await User.findOne({ _id: id });
    const user = await User.findById(req.params.id);
    if (!user) {
      // console.log('User does not exist');
      return res.json({ status: 'User Not Exists!' });
    }
    // const secret = config.secretKey + user.password
    try {
      const verify = jwt.verify(token, config.secretKey);
      res.render('index', { email: verify.email, status: 'Not Verified' });
    } catch (error) {
      console.log(error);
      res.send('Not Verified on jwt.verify');
    }
    // res.send('Done')
  }
);

router.post(
  '/reset-password/:id/:token',
  cors.corsWithOptions,
  async (req, res) => {
    const { id, token } = req.params;
    const { password } = req.body;
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.json({ status: 'User Not Exists!' });
    }
    // User.findById(req.params.id).then(async (user) => {
    try {
      await user.setPassword(password, function (err, user) {
        if (err) {
          res.statusCode = 401;
          res.setHeader('Content-Type', 'application/json');
          res.json({
            success: false,
            message: 'Password could not be saved. Please try again!',
          });
        } else {
          // res.statusCode = 200;
          // res.setHeader('Content-Type', 'application/json');
          user.save();
          // res.json({
          //   success: true,
          //   message: 'Your new password has been saved successfully',
          // });
        }
        res.render('index', { email: user.email, status: 'Verified' });
      });
      // res.json({ status: 'Password Updated' });
    } catch (error) {
      console.log(error);
      res.json({ status: 'Something Went Wrong' });
      return next(error);
    }
  }
);

module.exports = router;
