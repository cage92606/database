const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const authenticate = require('../authenticate.js'); // *5
const cors = require('./cors'); // *9
const ProInputs = require('../models/proInputs');

const proInputRouter = express.Router();

proInputRouter.use(bodyParser.json());

proInputRouter
  .route('/')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200);
    }
  }) // *9

  .get(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    ProInputs.find(req.query)
      .then(
        (proInputs) => {
          let myProInputs = [];
          myProInputs = proInputs;
          if (!myProInputs) {
            var err = new Error('You have no proInput!');
            err.status = 404; // Not found
            return next(err);
          } else {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.json(myProInputs);
          }
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    const proInput = req.body;
    proInput.user = req.user._id;
    ProInputs.create(proInput)
      .then(
        (proInput) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(proInput);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end('PUT operation NOT supported on /proInputs');
  });

proInputRouter
  .route('/:proInputId')
  .options(cors.corsWithOptions, (req, res) => {
    {
      res.sendStatus(200);
    }
  }) // *9
  .get(cors.cors, (req, res, next) => {
    ProInputs.findById(req.params.proInputId)
      .then(
        (proInput) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          // res.set({ 'Access-Control-Allow-Origin': '*' });
          res.json(proInput);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403; //forbidden
    res.end(
      `POST operation NOT supported on /proInputs/${req.params.proInputId}`
    );
  })

  .put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    ProInputs.findByIdAndUpdate(
      req.params.proInputId,
      {
        $set: req.body,
      },
      { new: true }
    )
      .then(
        (proInput) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.json(proInput);
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  })

  .delete(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    ProInputs.findByIdAndRemove(req.params.proInputId)
      .then(
        (resp) => {
          ProInputs.find({}).then((proInputs) => {
            let myProInputs = [];
            for (i = 0; i < proInputs.length; i++) {
              if (
                JSON.stringify(req.user._id) ===
                JSON.stringify('6281314ef6dca7bba4e2be3a')
              ) {
                myProInputs = proInputs;
                break;
              } else if (
                JSON.stringify(req.user._id) ===
                JSON.stringify(proInputs[i].user)
              ) {
                myProInputs.push(proInputs[i]);
              } else {
                continue;
              }
            }
            if (!myProInputs) {
              var err = new Error('You have no proInput!');
              err.status = 404; // Not found
              return next(err);
            } else {
              res.statusCode = 200;
              res.setHeader('Content-Type', 'application/json');
              res.json(myProInputs);
            }
          });
        },
        (err) => next(err)
      )
      .catch((err) => next(err));
  });

module.exports = proInputRouter;
