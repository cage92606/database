var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session'); // *3
var FileStore = require('session-file-store')(session); //*3

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var kirkRouter = require('./routes/kirkRouter');

const mongoose = require('mongoose'); // *1
// const Dishes = require('./models/dishes'); // *1
// const Promotions = require('./models/promotions'); // *1
// const Leaders = require('./models/leaders'); // *1

const url = 'mongodb://localhost:27017/conFusion'; // *1
const connect = mongoose.connect(url); // *1

connect.then(
  // *1
  (db) => {
    console.log('Connected to server');
  },
  (err) => {
    console.log(err);
  }
);

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// app.use(cookieParser());

app.use(
  // *3
  session({
    name: 'session-id',
    secret: '12345-67890-09876-54321',
    saveUninitialized: false,
    resave: false,
    store: new FileStore(),
  })
);

app.use('/', indexRouter);
app.use('/users', usersRouter);
//
// function auth(req, res, next) {
//   console.log(req.session); // *3
//   // if (!req.signedCookies.user) { // *2
//   if (!req.session.user) {
//     var err = new Error('You are not authenticated');
//     err.status = 401;
//     return next(err); // if there is no auth-header go to the error handler at the bottom with the header so the browser will pop up login modal.
//   } else {
//     if (req.session.user === 'authenticated') {
//       // *3
//       next();
//     } else {
//       var err = new Error('You are not authenticated');

//       err.status = 403; // forbidden
//       next(err);
//     }
//   }
// }

// app.use(auth); // *1, auth must be here

app.use(express.static(path.join(__dirname, 'public')));

app.use('/kirks', kirkRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
