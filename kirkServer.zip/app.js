var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var session = require('express-session'); // *3
var FileStore = require('session-file-store')(session); //*3

var passport = require('passport');
var authenticate = require('./authenticate');
var config = require('./config'); // *5

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var kirkRouter = require('./routes/kirkRouter');
var inputRouter = require('./routes/inputRouter');

const cors = require('cors');

const mongoose = require('mongoose'); // *1
// const Dishes = require('./models/dishes'); // *1
// const Promotions = require('./models/promotions'); // *1
// const Leaders = require('./models/leaders'); // *1

const url = config.mongoUrl; // *1

const connect = mongoose.connect(url); // *1

connect.then(
  // *1
  (db) => {
    console.log('Connected to server');
  },
  (err) => {
    console.log(err);
  }
);

var app = express();

// Redirect all request to secPort automatically
// app.all('*', (req, res, next) => {
//   if (req.secure) {
//     return next(); // do nothing if from secPort
//   } else {
//     res.redirect(
//       307,
//       'https://' + req.hostname + ':' + app.get('secPort') + req.url
//     );
//   }
// }); // *7

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
// app.use(cookieParser());

// app.use(
//   // *3
//   session({
//     name: 'session-id',
//     secret: '12345-67890-09876-54321',
//     saveUninitialized: false,
//     resave: false,
//     store: new FileStore(),
//   })
// );

app.use(passport.initialize()); // *4

app.use(cors());

app.use('/', indexRouter); // * for production
app.use('/users', usersRouter);

// app.use(auth); // *1, auth must be here

app.use(express.static(path.join(__dirname, 'public')));

app.use('/kirks', kirkRouter);
app.use('/inputs', inputRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// Serve static assets in production // for production
if (process.env.NODE_ENV === 'production') {
  // Set static folder
  app.use(express.static('client/build'));

  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
  });
}

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
