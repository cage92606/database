module.exports = {
  secretKey: '12345-67890-09876-54321',
  // mongoUrl: 'mongodb://localhost:27017/conFusion',
  // mongoUrl: 'mongodb://192.168.11.3:27017/conFusion',
  mongoUrl: 'mongodb://0.0.0.0:27017/conFusion',
  // mongoUrl:
  //   'mongodb+srv://cage:cage32044@cluster0.5iz8q.gcp.mongodb.net/conFusion',
};
