module.exports = {
  secretKey: '12345-67890-09876-54321',
  // mongoUrl: 'mongodb://localhost:27017/conFusion',
  // mongoUrl: 'mongodb://192.168.11.3:27017/conFusion',
  mongoUrl: 'mongodb://0.0.0.0:27017/conFusion',
};
