const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const inputSchema = new Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    date: {
      type: String,
      required: true,
    },
    place: {
      type: String,
    },
    person: {
      type: String,
    },
    subject: {
      type: String,
    },
    reason: {
      type: String,
    },
    condition: {
      type: String,
    },
    data: {
      type: String,
    },
    unit: {
      type: String,
    },
    unit: {
      type: String,
    },
  },
  { timestamps: true }
);

var Inputs = mongoose.model('Input', inputSchema);

module.exports = Inputs;
