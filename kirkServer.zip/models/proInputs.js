const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const proInputSchema = new Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    date: {
      type: String,
      required: true,
    },
    place: {
      type: String,
    },
    person: {
      type: String,
    },
    subject: {
      type: String,
    },
    reason: {
      type: String,
    },
    condition1: {
      type: String,
    },
    condition2: {
      type: String,
    },
    condition3: {
      type: String,
    },
    condition4: {
      type: String,
    },
    condition5: {
      type: String,
    },
    condition6: {
      type: String,
    },
    condition7: {
      type: String,
    },
    condition8: {
      type: String,
    },
    condition9: {
      type: String,
    },
    condition10: {
      type: String,
    },
    condition11: {
      type: String,
    },
    condition12: {
      type: String,
    },
    condition13: {
      type: String,
    },
    condition14: {
      type: String,
    },
    condition15: {
      type: String,
    },
    condition16: {
      type: String,
    },
    condition17: {
      type: String,
    },
    condition18: {
      type: String,
    },
    condition19: {
      type: String,
    },
    condition20: {
      type: String,
    },
    data: {
      type: String,
    },
    unit: {
      type: String,
    },
    unit: {
      type: String,
    },
  },
  { timestamps: true }
);

var ProInputs = mongoose.model('ProInput', proInputSchema);

module.exports = ProInputs;
