const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const kirkSchema = new Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    date: {
      type: String,
      required: true,
    },
    place: {
      type: String,
    },
    person: {
      type: String,
    },
    subject: {
      type: String,
    },
    reason: {
      type: String,
    },
    how: {
      type: String,
    },
    data: {
      type: String,
    },
    work: {
      type: Boolean,
      default: false,
    },
    news: {
      type: Boolean,
      default: false,
    },
    buy: {
      type: Boolean,
      default: false,
    },
    utilities: {
      type: Boolean,
      default: false,
    },
    symptoms: {
      type: Boolean,
      default: false,
    },
    events: {
      type: Boolean,
      default: false,
    },
    health: {
      type: Boolean,
      default: false,
    },
    foods: {
      type: Boolean,
      default: false,
    },
    invests: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

var Kirks = mongoose.model('Kirk', kirkSchema);

module.exports = Kirks;
