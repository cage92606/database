const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const kirkSchema = new Schema(
  {
    date: {
      type: String,
      required: true,
    },
    place: {
      type: String,
    },
    person: {
      type: String,
    },
    subject: {
      type: String,
    },
    reason: {
      type: String,
    },
    how: {
      type: String,
    },
  },
  { timestamps: true }
);

var Kirks = mongoose.model('Kirk', kirkSchema);

module.exports = Kirks;
