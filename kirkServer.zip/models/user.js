const mongoose = require('mongoose');
const Schema = mongoose.Schema;
var passportLocalMongoose = require('passport-local-mongoose'); // *4

var User = new Schema({
  // username: {    // *4
  //   type: String,
  //   required: true,
  //   unique: true,
  // },
  // password: {
  //   type: String,
  //   required: true,
  // },
  firstname: {
    type: String,
    default: '',
  },
  lastname: {
    type: String,
    default: '',
  },
  admin: {
    type: Boolean,
    default: false,
  },
  email: {
    type: String,
    default: '',
  },
});

User.plugin(passportLocalMongoose);

module.exports = mongoose.model('User', User); // the name and the schema.
