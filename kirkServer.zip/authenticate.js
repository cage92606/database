var passport = require('passport');
var passport_admin = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var User = require('./models/user');
var JwtStrategy = require('passport-jwt').Strategy; // *5
var ExtractJwt = require('passport-jwt').ExtractJwt; // *5
var jwt = require('jsonwebtoken'); // *5

var config = require('./config'); // *5

exports.local = passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

exports.getToken = (user) => {
  // return jwt.sign(user, config.secretKey, { expiresIn: 3600000 });
  return jwt.sign(user, config.secretKey, { expiresIn: '2d' });
};

var opts = {}; // *5
opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();

opts.secretOrKey = config.secretKey; // *5

exports.jwtPassport = passport.use(
  // *5
  new JwtStrategy(opts, (jwt_payload, done) => {
    console.log('JWT payload: ', jwt_payload);
    User.findOne({ _id: jwt_payload._id }, (err, user) => {
      if (err) {
        return done(err, false);
      } else if (user) {
        return done(null, user);
      } else {
        return done(null, false); // *5 couldn't find the user
      }
    });
  })
);

exports.verifyUser = passport.authenticate('jwt', { session: false }); // *5

exports.jwtPassport = passport_admin.use(
  'admin',
  // *5
  new JwtStrategy(opts, (jwt_payload, done) => {
    console.log('JWT payload: ', jwt_payload);
    User.findOne({ _id: jwt_payload._id }, (err, user) => {
      if (err) {
        return done(err, false);
      } else if (user.admin) {
        return done(null, user);
      } else {
        return done(null, false); // *5 couldn't find the user
      }
    });
  })
);

exports.verifyAdmin = passport_admin.authenticate('admin', { session: false });
