export const baseUrl = 'http://localhost:3000/';
// export const baseUrl = 'https://kirk020.herokuapp.com/';
// export const baseUrl = 'https://kirk021.herokuapp.com/';
// export const baseUrl = 'https://localhost:3443/';
// X export const baseUrl = 'https://192.168.11.3:3443/';
// X export const baseUrl = 'https://127.0.0.1:3443/';
// export const baseUrl = 'https://shielded-mountain-50176.herokuapp.com';
