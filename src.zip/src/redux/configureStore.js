import { createStore, combineReducers, applyMiddleware, compose } from 'redux';
import { createForms } from 'react-redux-form';
import { Kirks, InitialKirk } from './kirks';
import { Inputs, InitialInput } from './inputs';
import { ProInputs, InitialProInput } from './proInputs';
import { FieldButtons, InitialFieldButtons } from './fieldButtons';
import { Auth } from './auth';
import thunk from 'redux-thunk';
import logger from 'redux-logger';

export const ConfigureStore = () => {
  const composeEnhancers =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

  const store = createStore(
    combineReducers({
      // these are reducer functions, not values
      // 'cause not Dishes() but Dishes
      kirks: Kirks,
      auth: Auth,
      inputs: Inputs,
      proInputs: ProInputs,
      fieldButtons: FieldButtons,
      // kirkNum,
      ...createForms({
        kirk: InitialKirk,
        input: InitialInput,
        proInput: InitialProInput
        // fieldButtons: InitialFieldButtons
        // kirkNum: InitialKirkNum,
      })
    }),
    composeEnhancers(applyMiddleware(thunk, logger))
    // applyMiddleware(thunk, logger)
  );
  console.log('Redux store:', store);
  return store;
};
