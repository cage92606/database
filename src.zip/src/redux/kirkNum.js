import * as ActionTypes from './ActionTypes';

// export const InitialKirkNum = 0;

export const kirkNum = (
  state = {
    kirkNum: null,
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.UPDATE_KIRKNUM:
      return {
        ...state,
        kirkNum: action.kirkNum,
      };
    default:
      return state;
  }
};
