import * as ActionTypes from './ActionTypes';

export const InitialProInput = {
  date: '',
  place: '',
  person: '',
  subject: '',
  reason: '',
  condition1: '',
  condition2: '',
  condition3: '',
  condition4: '',
  condition5: '',
  condition6: '',
  condition7: '',
  condition8: '',
  condition9: '',
  condition10: '',
  condition11: '',
  condition12: '',
  condition13: '',
  condition14: '',
  condition15: '',
  condition16: '',
  condition17: '',
  condition18: '',
  condition19: '',
  condition20: '',
  data: '',
  unit: '',
};

export const ProInputs = (
  state = {
    errMess: null,
    proInputs: [],
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.PROINPUTS_UPDATING:
      return {
        ...state,
        isUpdating: true,
        errMess: null,
      };

    case ActionTypes.ADD_PROINPUTS:
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: null,
        proInputs: action.payload,
      };

    case ActionTypes.PROINPUTS_LOADING:
      return {
        ...state,
        isLoading: true,
        isUpdating: false,
        errMess: null,
        proInputs: [],
      };

    case ActionTypes.PROINPUTS_FAILED:
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: action.payload,
        proInputs: [],
      };

    case ActionTypes.ADD_PROINPUT:
      var proInput = action.payload;
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        proInputs: state.proInputs.concat(proInput),
      };

    case ActionTypes.EDITED_PROINPUT:
      const index = state.proInputs.findIndex((curr) => {
        return curr._id === action.payload._id;
      });
      state.proInputs[index] = action.payload;
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: null,
        proInputs: state.proInputs,
      };

    default:
      return state;
  }
};
