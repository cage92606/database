import * as ActionTypes from './ActionTypes';

export const InitialInput = {
  date: '',
  place: '',
  person: '',
  subject: '',
  reason: '',
  condition: '',
  data: '',
  unit: '',
};

export const Inputs = (
  state = {
    errMess: null,
    inputs: [],
  },
  action
) => {
  switch (action.type) {
    case ActionTypes.INPUTS_UPDATING:
      return {
        ...state,
        isUpdating: true,
        errMess: null,
      };
    case ActionTypes.ADD_INPUTS:
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: null,
        inputs: action.payload,
      };

    case ActionTypes.INPUTS_LOADING:
      return {
        ...state,
        isLoading: true,
        isUpdating: false,
        errMess: null,
        // inputs: [],  // 2023.11.18
      };

    case ActionTypes.INPUTS_FAILED:
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: action.payload,
        inputs: [],
      };

    case ActionTypes.ADD_INPUT:
      var input = action.payload;
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        inputs: state.inputs.concat(input),
      };

    case ActionTypes.EDITED_INPUT:
      const index = state.inputs.findIndex((curr) => {
        return curr._id === action.payload._id;
      });
      state.inputs[index] = action.payload;
      return {
        ...state,
        isLoading: false,
        isUpdating: false,
        errMess: null,
        inputs: state.inputs,
      };

    default:
      return state;
  }
};
