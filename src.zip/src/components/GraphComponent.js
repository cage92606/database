import React, { useEffect, useRef } from 'react';
import { Network } from 'vis-network';

const Graph = () => {
  const container = useRef(null);

  const nodes = [
    { id: 1, label: 'Node 1', level: 5 },
    { id: 2, label: 'Node 2', level: 4 },
    { id: 3, label: 'Node 3', level: 3 },
    { id: 4, label: 'Node 4', level: 2 },
    { id: 5, label: 'Node 5', level: 1 },
    { id: 6, label: 'Decision Node', shape: 'diamond', level: 0 }
  ];

  const edges = [
    { from: 1, to: 3, arrows: 'to' },
    { from: 1, to: 2 },
    { from: 2, to: 4 },
    { from: 2, to: 5 },
    { from: 3, to: 3, arrows: 'to' },
    { from: 6, to: 5, arrows: 'from' },
    { from: 6, to: 4 }
  ];

  const options = {
    nodes: {
      shape: 'box'
    }
    // layout: {
    //   hierarchical: {
    //     enabled: true,
    //     direction: 'DU', // 'UD' for Up-Down, 'DU' for Down-Up
    //     sortMethod: 'directed' // optional, just to make the layout the same every time
    //   }
    // }
    // physics: false
  };

  // var data = {
  //   nodes: nodes,
  //   edges: edges
  // };

  useEffect(() => {
    const data = {
      nodes: nodes,
      edges: edges
    };

    new Network(container.current, data, options);
  }, []);

  // useEffect(() => {
  //   const network =
  //     container.current &&
  //     new Network(container.current, { nodes, edges }, options);
  // }, [container, nodes, edges]);

  return <div ref={container} style={{ height: '800px', width: '1000px' }} />;
  // return (
  //   <div ref={container} style={{ height: 'max-height', width: 'inherit' }} />
  // );
};

export default Graph;
