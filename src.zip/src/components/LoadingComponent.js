import React from 'react';

export const Loading = () => {
  return (
    // <div className="col-12 row justify-content-center">
    <div className="col-12">
      {/* fa-pulse: blinking
      fa-3x: speed
      fa-fw: forward, meaning CCW 
      text-primary: color of the spinner */}
      {/* <span className="fa fa-spinner fa-pulse fa-3x fa-fw text-primary"></span> */}
      <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
      <span class="sr-only">Loading...</span>
      <br></br>
      <br></br>
      <br></br>
      {/* <p>Loading . . .</p> */}
    </div>
  );
};
