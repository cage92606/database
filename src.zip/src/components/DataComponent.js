/* eslint-disable react/jsx-pascal-case */
import React, { Component, useState } from 'react';
import {
  Col,
  Row,
  // Form,
  // FormGroup,
  Label,
  Input,
  Button,
  FormText
} from 'reactstrap';
import { Control, Form, Errors, actions } from 'react-redux-form';
// import { fetchKirks, fetchInputs } from '../redux/ActionCreators';

// useEffect(() => {
//   props.fetchInputs();
// });

// document.getElementById('clearButton').addEventListener('click', function () {
//   document.getElementById('decemberIncome').value = '';
//   document.getElementById('decemberExpenses').value = '';
// });

class Data extends Component {
  constructor (props) {
    super(props);
    this.state = {
      // flags for date, place, person, subject, reason, condition, data, unit
      inputDateFlag: '',
      inputPlaceFlag: '',
      inputPersonFlag: '',
      inputSubjectFlag: '',
      inputReasonFlag: '',
      inputConditionFlag: '',
      inputDataFlag: '',
      inputUnitFlag: ''
    };
    this.clearAllBoxes = this.clearAllBoxes.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.clearBox = this.clearBox.bind(this);
    this.setInputDateFlag = this.setInputDateFlag.bind(this);
    this.setInputPlaceFlag = this.setInputPlaceFlag.bind(this);
    this.setInputPersonFlag = this.setInputPersonFlag.bind(this);
    this.setInputSubjectFlag = this.setInputSubjectFlag.bind(this);
    this.setInputReasonFlag = this.setInputReasonFlag.bind(this);
    this.setInputConditionFlag = this.setInputConditionFlag.bind(this);
    this.setInputDataFlag = this.setInputDataFlag.bind(this);
    this.setInputUnitFlag = this.setInputUnitFlag.bind(this);
  }

  setInputDateFlag (flag) {
    this.setState({ inputDateFlag: flag });
  }

  setInputPlaceFlag (flag) {
    this.setState({ inputPlaceFlag: flag });
  }

  setInputPersonFlag (flag) {
    this.setState({ inputPersonFlag: flag });
  }

  setInputSubjectFlag (flag) {
    this.setState({ inputSubjectFlag: flag });
  }

  setInputReasonFlag (flag) {
    this.setState({ inputReasonFlag: flag });
  }

  setInputConditionFlag (flag) {
    this.setState({ inputConditionFlag: flag });
  }

  setInputDataFlag (flag) {
    this.setState({ inputDataFlag: flag });
  }

  setInputUnitFlag (flag) {
    this.setState({ inputUnitFlag: flag });
  }

  // componentDidUpdate() {
  //   this.props.fetchInputs();
  //   // console.log('kirkNum on main is ', this.props.kirkNum);
  // }

  clearBox (id) {
    document.getElementById(id).value = '';
  }

  clearAllBoxes () {
    this.props.resetInputForm();
  }

  handleSubmit = value => {
    this.props.postInput(
      value.date,
      value.place,
      value.person,
      value.subject,
      value.reason,
      value.condition,
      value.data,
      value.unit
    );
    // this.props.resetInputForm();
    // document.getElementById('inputs_submit').disabled = 'true';
    // document.getElementById('inputs_submit').addEventListener('click', (e) => {
    //   e.target.disabled = 'true';
    //   alert('disabled');
    // });
  };

  render () {
    const onClear = id => {
      return () => {
        this.clearBox(id);
      };
    };

    return (
      <div className='container main'>
        <div className='row'>
          <div className='mb-2 col-6'>
            <h1>
              <b>Data</b>
            </h1>
          </div>
          <div className='mb-2 col-6 align-self-center' align='right'>
            <Button outline color='secondary' onClick={this.clearAllBoxes}>
              Clear
            </Button>
          </div>
        </div>
        {/* <div className="col-12 col-md-9"> */}
        <p>Take any data you want to collect, analyze and know more.</p>
        <Form model='input' onSubmit={value => this.handleSubmit(value)}>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='date'>
              date
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.date'
                  id='date'
                  name='date'
                  placeholder='2022-1-1'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputDateFlag}
                  onChange={e => this.setInputDateFlag(e.target.value)}
                />
                {this.state.inputDateFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputDateFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent',
                      border: 'none',
                      color: '#ccc'
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='place'>
              place
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.place'
                  id='place'
                  name='place'
                  placeholder='where?'
                  className='form-control'
                  value={this.state.inputPlaceFlag}
                  onChange={e => this.setInputPlaceFlag(e.target.value)}
                />
                {this.state.inputPlaceFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputPlaceFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='person'>
              person
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.person'
                  id='person'
                  name='person'
                  placeholder='who?'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputPersonFlag}
                  onChange={e => this.setInputPersonFlag(e.target.value)}
                />
                {this.state.inputPersonFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputPersonFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='subject'>
              subject
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.subject'
                  id='subject'
                  name='subject'
                  placeholder='what?'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputSubjectFlag}
                  onChange={e => this.setInputSubjectFlag(e.target.value)}
                />
                {this.state.inputSubjectFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputSubjectFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='reason'>
              reason
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.textarea
                  model='.reason'
                  id='reason'
                  name='reason'
                  placeholder='why?'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputReasonFlag}
                  onChange={e => this.setInputReasonFlag(e.target.value)}
                />
                {this.state.inputReasonFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputReasonFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label sm={2} htmlFor='condition'>
              condition
            </Label>
            <Col sm={10}>
              <div style={{ position: 'relative' }}>
                <Control.textarea
                  model='.condition'
                  type='text'
                  id='condition'
                  name='condition'
                  placeholder='how?'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputConditionFlag}
                  onChange={e => this.setInputConditionFlag(e.target.value)}
                />
                {this.state.inputConditionFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputConditionFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          <Row className='form-group mb-2'>
            <Label xs={2} htmlFor='data'>
              data
            </Label>
            <Col xs={4}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.data'
                  id='data'
                  name='data'
                  placeholder='12.3'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputDataFlag}
                  onChange={e => this.setInputDataFlag(e.target.value)}
                />
                {this.state.inputDataFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputDataFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
            <Label xs={2} htmlFor='unit'>
              unit
            </Label>
            <Col xs={4}>
              <div style={{ position: 'relative' }}>
                <Control.text
                  model='.unit'
                  id='unit'
                  name='unit'
                  placeholder='g'
                  className='form-control'
                  style={{ paddingRight: '30px' }} // Add padding to the input box
                  value={this.state.inputUnitFlag}
                  onChange={e => this.setInputUnitFlag(e.target.value)}
                />
                {this.state.inputUnitFlag && (
                  <button
                    type='button'
                    onClick={() => this.setInputUnitFlag('')}
                    style={{
                      position: 'absolute',
                      top: '50%',
                      right: '10px',
                      transform: 'translateY(-50%)',
                      backgroundColor: 'transparent', // Make the button background transparent
                      border: 'none', // Remove the button border
                      color: '#ccc' // Change the color of the "X" to grey
                    }}
                  >
                    X
                  </button>
                )}
              </div>
            </Col>
          </Row>
          {/* <FormGroup>
          <Label for="item">item</Label>
          <Input id="item" name="item" type="select">
            <option>body_temp</option>
            <option>spo2</option>
            <option>heart_rate</option>
            <option>bowel_move</option>
            <option>pb_high</option>
            <option>pb_high</option>
          </Input>
        </FormGroup> */}
          {/* <FormGroup>
          <Label for="item">item</Label>
          <Input id="item" multiple name="item" type="select">
            <option>body_temp</option>
            <option>spo2</option>
            <option>heart_rate</option>
            <option>bowel_move</option>
            <option>pb_high</option>
            <option>pb_high</option>
          </Input>
        </FormGroup> */}
          {/* <FormGroup row> */}
          <Row className='form-group mt-5'>
            <Button
              type='submit'
              color='secondary'
              disabled={this.props.isUpdating} // 2023.11.18
            >
              Submit
            </Button>
          </Row>
          {/* </FormGroup> */}
        </Form>
      </div>
    );
  }
}

export default Data;
