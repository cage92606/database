/* eslint-disable react/jsx-pascal-case */
import React, { useEffect, Fragment } from 'react';
import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';

import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  Table,
  Fade
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';
import { CSVLink, CSVDownload } from 'react-csv';
import Pagination from './Pagination';

function RenderProInputTable ({
  proInput,
  deleteProInput,
  updateProInput,
  resetProInputForm,
  auth,
  isUpdating
}) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    if (window.confirm('OK to change data?')) {
      updateProInput(
        proInput._id,
        value.date,
        value.place,
        value.person,
        value.subject,
        value.reason,
        value.condition1,
        value.condition2,
        value.condition3,
        value.condition4,
        value.condition5,
        value.condition6,
        value.condition7,
        value.condition8,
        value.condition9,
        value.condition10,
        value.condition11,
        value.condition12,
        value.condition13,
        value.condition14,
        value.condition15,
        value.condition16,
        value.condition17,
        value.condition18,
        value.condition19,
        value.condition20,
        value.data,
        value.unit
      );
      // resetProInputForm();
    }
  };

  return (
    <tr>
      <Modal
        isOpen={isOpen}
        toggle={toggleModal}
        size='lg'
        style={{ maxWidth: '1000px', width: '100%' }}
        className='my-modal'
      >
        <ModalHeader toggle={toggleModal}>Update ProInput</ModalHeader>
        <ModalBody>
          <Form onSubmit={handleSubmit} model='proInput'>
            <Row className='form-group mb-2'>
              <Label htmlFor='date'>date</Label>
              <Col sm={10}>
                <Control.text
                  model='.date'
                  id='date'
                  name='date'
                  defaultValue={proInput.date}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='place'>place</Label>
              <Col sm={10}>
                <Control.text
                  model='.place'
                  id='place'
                  name='place'
                  defaultValue={proInput.place}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='person'>person</Label>
              <Col sm={10}>
                <Control.text
                  model='.person'
                  id='person'
                  name='person'
                  defaultValue={proInput.person}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='subject'>subject</Label>
              <Col sm={10}>
                <Control.text
                  model='.subject'
                  id='subject'
                  name='subject'
                  defaultValue={proInput.subject}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='reason'>reason</Label>
              <Col sm={10}>
                <Control.textarea
                  model='.reason'
                  id='reason'
                  name='reason'
                  defaultValue={proInput.reason}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label>condition</Label>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition1'
                  model='.condition1'
                  id='condition1'
                  name='condition1'
                  defaultValue={proInput.condition1}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition2'
                  model='.condition2'
                  id='condition2'
                  name='condition2'
                  defaultValue={proInput.condition2}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition3'
                  model='.condition3'
                  id='condition3'
                  name='condition3'
                  defaultValue={proInput.condition3}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition4'
                  model='.condition4'
                  id='condition4'
                  name='condition4'
                  defaultValue={proInput.condition4}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition5'
                  model='.condition5'
                  id='condition5'
                  name='condition5'
                  defaultValue={proInput.condition5}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition6'
                  model='.condition6'
                  id='condition6'
                  name='condition6'
                  defaultValue={proInput.condition6}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition7'
                  model='.condition7'
                  id='condition7'
                  name='condition7'
                  defaultValue={proInput.condition7}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition8'
                  model='.condition8'
                  id='condition8'
                  name='condition8'
                  defaultValue={proInput.condition8}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition9'
                  model='.condition9'
                  id='condition9'
                  name='condition9'
                  defaultValue={proInput.condition9}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition10'
                  model='.condition10'
                  id='condition10'
                  name='condition10'
                  defaultValue={proInput.condition10}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition11'
                  model='.condition11'
                  id='condition11'
                  name='condition11'
                  defaultValue={proInput.condition11}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition12'
                  model='.condition12'
                  id='condition12'
                  name='condition12'
                  defaultValue={proInput.condition12}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition13'
                  model='.condition13'
                  id='condition13'
                  name='condition13'
                  defaultValue={proInput.condition13}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition14'
                  model='.condition14'
                  id='condition14'
                  name='condition14'
                  defaultValue={proInput.condition14}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition15'
                  model='.condition15'
                  id='condition15'
                  name='condition15'
                  defaultValue={proInput.condition15}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition16'
                  model='.condition16'
                  id='condition16'
                  name='condition16'
                  defaultValue={proInput.condition16}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition17'
                  model='.condition17'
                  id='condition17'
                  name='condition17'
                  defaultValue={proInput.condition17}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition18'
                  model='.condition18'
                  id='condition18'
                  name='condition18'
                  defaultValue={proInput.condition18}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition19'
                  model='.condition19'
                  id='condition19'
                  name='condition19'
                  defaultValue={proInput.condition19}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition20'
                  model='.condition20'
                  id='condition20'
                  name='condition20'
                  defaultValue={proInput.condition20}
                  className='form-control'
                />
              </Col>
            </Row>

            <Row className='form-group mb-2'>
              <Label htmlFor='data'>data</Label>
              <Col sm={4}>
                <Control.text
                  model='.data'
                  id='data'
                  name='data'
                  defaultValue={proInput.data}
                  className='form-control'
                />
              </Col>
              {/* </Row>
              <Row className="form-group mb-2"> */}
              <Label htmlFor='unit'>unit</Label>
              <Col sm={4}>
                <Control.text
                  model='.unit'
                  id='unit'
                  name='unit'
                  defaultValue={proInput.unit}
                  className='form-control'
                />
              </Col>
            </Row>
            <Button type='submit' value='submit' color='primary'>
              Submit
            </Button>
          </Form>
        </ModalBody>
      </Modal>

      <td className='sticky-td'>
        {auth.id === proInput.user ? (
          <Button
            outline
            color='primary'
            onClick={toggleModal}
            style={{ border: 'none' }}
          >
            <span className='fa fa-edit'></span>
          </Button>
        ) : (
          <Button outline color='secondary' style={{ border: 'none' }}>
            <span className='fa fa-edit'></span>
          </Button>
        )}
      </td>
      <td>{proInput.date}</td>
      <td>
        {proInput.place.indexOf('http') === 0 ||
        proInput.place.indexOf('/') === 0 ? (
          proInput.place ? (
            proInput.place.indexOf('http') === 0 ? (
              <a href={proInput.place} target='_blank' rel='noreferrer'>
                {0 ? (
                  <span className='fa fa-link'></span>
                ) : proInput.place.indexOf('www') !== -1 ? (
                  // If the first word is 'www', use the second word
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : proInput.place.split('//')[1].split('/')[0].split('.')
                    .length === 2 ? (
                  // otherwise and if domain consists of 2 words, use the first word
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                ) : // otherwise use whichever is longer among the first and second words
                proInput.place.split('//')[1].split('/')[0].split('.')[0]
                    .length <
                  proInput.place.split('//')[1].split('/')[0].split('.')[1]
                    .length ? (
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : (
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                )}
              </a>
            ) : (
              <a
                href={`file:${proInput.place}`}
                target='_blank'
                rel='noreferrer'
              >
                <span className='fa fa-folder-open'></span>
              </a>
            )
          ) : (
            ''
          )
        ) : (
          <code>{proInput.place}</code>
        )}
      </td>
      <td>{proInput.person}</td>
      <td>
        <b>{proInput.subject}</b>
      </td>
      <td>{proInput.reason}</td>
      <td
        style={
          isNaN(proInput.condition1.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition1}
      </td>
      <td
        style={
          isNaN(proInput.condition2.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition2}
      </td>
      <td
        style={
          isNaN(proInput.condition3.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition3}
      </td>
      <td
        style={
          isNaN(proInput.condition4.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition4}
      </td>
      <td
        style={
          isNaN(proInput.condition5.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition5}
      </td>
      <td
        style={
          isNaN(proInput.condition6.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition6}
      </td>
      <td
        style={
          isNaN(proInput.condition7.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition7}
      </td>
      <td
        style={
          isNaN(proInput.condition8.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition8}
      </td>
      <td
        style={
          isNaN(proInput.condition9.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition9}
      </td>
      <td
        style={
          isNaN(proInput.condition10.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition10}
      </td>
      <td
        style={
          isNaN(proInput.condition11.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition11}
      </td>
      <td
        style={
          isNaN(proInput.condition12.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition12}
      </td>
      <td
        style={
          isNaN(proInput.condition13.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition13}
      </td>
      <td
        style={
          isNaN(proInput.condition14.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition14}
      </td>
      <td
        style={
          isNaN(proInput.condition15.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition15}
      </td>
      <td
        style={
          isNaN(proInput.condition16.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition16}
      </td>
      <td
        style={
          isNaN(proInput.condition17.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition17}
      </td>
      <td
        style={
          isNaN(proInput.condition18.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition18}
      </td>
      <td
        style={
          isNaN(proInput.condition19.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition19}
      </td>
      <td
        style={
          isNaN(proInput.condition20.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition20}
      </td>
      <td
        style={
          isNaN(proInput.data.replace(/,/g, '')) ? {} : { textAlign: 'right' }
        }
      >
        {proInput.data.indexOf('http') === 0 ||
        proInput.data.indexOf('/') === 0 ? (
          proInput.data ? (
            proInput.data.indexOf('http') === 0 ? (
              <a href={proInput.data} target='_blank' rel='noreferrer'>
                {0 ? (
                  // {0 ? (
                  <span className='fa fa-link'></span>
                ) : proInput.data.indexOf('www') !== -1 ? (
                  // If the first word is 'www', use the second word
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : proInput.data.split('//')[1].split('/')[0].split('.')
                    .length === 2 ? (
                  // otherwise and if domain consists of 2 words, use the first word
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                ) : // otherwise use whichever is longer among the first and second words
                proInput.data.split('//')[1].split('/')[0].split('.')[0]
                    .length <
                  proInput.data.split('//')[1].split('/')[0].split('.')[1]
                    .length ? (
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : (
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                )}
              </a>
            ) : (
              <a
                href={`file:${proInput.data}`}
                target='_blank'
                rel='noreferrer'
              >
                <span className='fa fa-folder-open'></span>
              </a>
            )
          ) : (
            ''
          )
        ) : (
          <code>{proInput.data}</code>
        )}
      </td>
      <td>{proInput.unit}</td>
      <td className='sticky-td'>
        {auth.id === proInput.user ? (
          <Button
            outline
            color='danger'
            disabled={isUpdating} // 2023.11.18
            onClick={() => {
              if (window.confirm('Are you sure?')) deleteProInput(proInput._id);
            }}
            style={{ border: 'none' }}
          >
            <span className='fa fa-times'></span>
          </Button>
        ) : (
          <span></span>
        )}
      </td>
    </tr>
  );
}

export let proInput_num;

export default function ListData (props) {
  // const searchDone = (display) => {
  //   setDisplay(display);
  // };

  const toggledProInputFieldButton = useSelector(
    state => state.fieldButtons.toggledProInputFieldButton
  );

  const isProInputIdAscending = useSelector(
    state => state.fieldButtons.isProInputIdAscending
  );
  const isProInputDateAscending = useSelector(
    state => state.fieldButtons.isProInputDateAscending
  );
  const isProInputPlaceAscending = useSelector(
    state => state.fieldButtons.isProInputPlaceAscending
  );
  const isProInputPersonAscending = useSelector(
    state => state.fieldButtons.isProInputPersonAscending
  );
  const isProInputSubjectAscending = useSelector(
    state => state.fieldButtons.isProInputSubjectAscending
  );
  const isProInputReasonAscending = useSelector(
    state => state.fieldButtons.isProInputReasonAscending
  );
  const isProInputCondition1Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition1Ascending
  );
  const isProInputCondition2Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition2Ascending
  );
  const isProInputCondition3Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition3Ascending
  );
  const isProInputCondition4Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition4Ascending
  );
  const isProInputCondition5Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition5Ascending
  );
  const isProInputCondition6Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition6Ascending
  );
  const isProInputCondition7Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition7Ascending
  );
  const isProInputCondition8Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition8Ascending
  );
  const isProInputCondition9Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition9Ascending
  );
  const isProInputCondition10Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition10Ascending
  );
  const isProInputCondition11Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition11Ascending
  );
  const isProInputCondition12Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition12Ascending
  );
  const isProInputCondition13Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition13Ascending
  );
  const isProInputCondition14Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition14Ascending
  );
  const isProInputCondition15Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition15Ascending
  );
  const isProInputCondition16Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition16Ascending
  );
  const isProInputCondition17Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition17Ascending
  );
  const isProInputCondition18Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition18Ascending
  );
  const isProInputCondition19Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition19Ascending
  );
  const isProInputCondition20Ascending = useSelector(
    state => state.fieldButtons.isProInputCondition20Ascending
  );
  const isProInputDataAscending = useSelector(
    state => state.fieldButtons.isProInputDataAscending
  );
  const isProInputUnitAscending = useSelector(
    state => state.fieldButtons.isProInputUnitAscending
  );

  const dispatch = useDispatch();
  const toggleIsProInputIdAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_ID_ASCENDING' });
  };
  const toggleIsProInputDateAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_DATE_ASCENDING' });
  };
  const toggleIsProInputPlaceAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_PLACE_ASCENDING' });
  };
  const toggleIsProInputPersonAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_PERSON_ASCENDING' });
  };
  const toggleIsProInputSubjectAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_SUBJECT_ASCENDING' });
  };
  const toggleIsProInputReasonAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_REASON_ASCENDING' });
  };
  const toggleIsProInputCondition1Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION1_ASCENDING' });
  };
  const toggleIsProInputCondition2Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION2_ASCENDING' });
  };
  const toggleIsProInputCondition3Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION3_ASCENDING' });
  };
  const toggleIsProInputCondition4Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION4_ASCENDING' });
  };
  const toggleIsProInputCondition5Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION5_ASCENDING' });
  };
  const toggleIsProInputCondition6Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION6_ASCENDING' });
  };
  const toggleIsProInputCondition7Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION7_ASCENDING' });
  };
  const toggleIsProInputCondition8Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION8_ASCENDING' });
  };
  const toggleIsProInputCondition9Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION9_ASCENDING' });
  };
  const toggleIsProInputCondition10Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION10_ASCENDING' });
  };
  const toggleIsProInputCondition11Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION11_ASCENDING' });
  };
  const toggleIsProInputCondition12Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION12_ASCENDING' });
  };
  const toggleIsProInputCondition13Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION13_ASCENDING' });
  };
  const toggleIsProInputCondition14Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION14_ASCENDING' });
  };
  const toggleIsProInputCondition15Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION15_ASCENDING' });
  };
  const toggleIsProInputCondition16Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION16_ASCENDING' });
  };
  const toggleIsProInputCondition17Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION17_ASCENDING' });
  };
  const toggleIsProInputCondition18Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION18_ASCENDING' });
  };
  const toggleIsProInputCondition19Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION19_ASCENDING' });
  };
  const toggleIsProInputCondition20Ascending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_CONDITION20_ASCENDING' });
  };
  const toggleIsProInputDataAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_DATA_ASCENDING' });
  };
  const toggleIsProInputUnitAscending = () => {
    dispatch({ type: 'TOGGLE_IS_PRO_INPUT_UNIT_ASCENDING' });
  };

  const [currentPage, setCurrentPage] = useState(1);
  const [proInputListPerPage] = useState(1000);

  const paginate = pageNumber => setCurrentPage(pageNumber);

  if (props.isLoading) {
    return (
      <div className='container'>
        <div className='row'>
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className='container'>
        <div className='row'>
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    // console.log('setIsKeywordChanged is now ', setIsKeywordChanged);

    const keywordAndArray = props.keyword.split('|');
    var keywords = [];
    var exwords = [];
    for (let k = 0; k < keywordAndArray.length; k++) {
      let keywordArray = keywordAndArray[k].split(/(\s+)/);
      var keywords_temp = [];
      var exwords_temp = [];
      let j = 0;
      let m = 0;
      for (let i = 0; i < keywordArray.length; i++) {
        if ((keywordArray[i] !== ' ') & (keywordArray[i] !== '')) {
          if (keywordArray[i].split('')[0] === '!') {
            exwords_temp[m] = keywordArray[i]
              .toLowerCase()
              .split('')
              .splice(1)
              .join('');
            m = m + 1;
          } else {
            keywords_temp[j] = keywordArray[i].toLowerCase();
            j = j + 1;
          }
        }
      }
      keywords.push(keywords_temp); // OR演算子で分割した各々のキーワード群
      exwords.push(exwords_temp);
    }
    var foundProInputs = [];
    for (let i = 0; i < keywords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs_temp = props.proInputs.filter(curr => {
        const test = keywords[i].map(
          keyword =>
            curr.date.toLowerCase().includes(keyword) ||
            curr.place.toLowerCase().includes(keyword) ||
            curr.person.toLowerCase().includes(keyword) ||
            curr.subject.toLowerCase().includes(keyword) ||
            curr.reason.toLowerCase().includes(keyword) ||
            curr.condition1.toLowerCase().includes(keyword) ||
            curr.condition2.toLowerCase().includes(keyword) ||
            curr.condition3.toLowerCase().includes(keyword) ||
            curr.condition4.toLowerCase().includes(keyword) ||
            curr.condition5.toLowerCase().includes(keyword) ||
            curr.condition6.toLowerCase().includes(keyword) ||
            curr.condition7.toLowerCase().includes(keyword) ||
            curr.condition8.toLowerCase().includes(keyword) ||
            curr.condition9.toLowerCase().includes(keyword) ||
            curr.condition10.toLowerCase().includes(keyword) ||
            curr.condition11.toLowerCase().includes(keyword) ||
            curr.condition12.toLowerCase().includes(keyword) ||
            curr.condition13.toLowerCase().includes(keyword) ||
            curr.condition14.toLowerCase().includes(keyword) ||
            curr.condition15.toLowerCase().includes(keyword) ||
            curr.condition16.toLowerCase().includes(keyword) ||
            curr.condition17.toLowerCase().includes(keyword) ||
            curr.condition18.toLowerCase().includes(keyword) ||
            curr.condition19.toLowerCase().includes(keyword) ||
            curr.condition20.toLowerCase().includes(keyword) ||
            curr.data.toLowerCase().includes(keyword) ||
            curr.unit.toLowerCase().includes(keyword)
        );
        return test.every(logic => logic === true);
      });
      foundProInputs = foundProInputs.concat(foundProInputs_temp);
      //     }
    }
    var foundProInputs2 = [];
    for (let i = 0; i < exwords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs2_temp = foundProInputs.filter(curr => {
        const test = exwords[i].map(
          exword =>
            curr.date.toLowerCase().includes(exword) ||
            curr.place.toLowerCase().includes(exword) ||
            curr.person.toLowerCase().includes(exword) ||
            curr.subject.toLowerCase().includes(exword) ||
            curr.reason.toLowerCase().includes(exword) ||
            curr.condition1.toLowerCase().includes(exword) ||
            curr.condition2.toLowerCase().includes(exword) ||
            curr.condition3.toLowerCase().includes(exword) ||
            curr.condition4.toLowerCase().includes(exword) ||
            curr.condition5.toLowerCase().includes(exword) ||
            curr.condition6.toLowerCase().includes(exword) ||
            curr.condition7.toLowerCase().includes(exword) ||
            curr.condition8.toLowerCase().includes(exword) ||
            curr.condition9.toLowerCase().includes(exword) ||
            curr.condition10.toLowerCase().includes(exword) ||
            curr.condition11.toLowerCase().includes(exword) ||
            curr.condition12.toLowerCase().includes(exword) ||
            curr.condition13.toLowerCase().includes(exword) ||
            curr.condition14.toLowerCase().includes(exword) ||
            curr.condition15.toLowerCase().includes(exword) ||
            curr.condition16.toLowerCase().includes(exword) ||
            curr.condition17.toLowerCase().includes(exword) ||
            curr.condition18.toLowerCase().includes(exword) ||
            curr.condition19.toLowerCase().includes(exword) ||
            curr.condition20.toLowerCase().includes(exword) ||
            curr.data.toLowerCase().includes(exword) ||
            curr.unit.toLowerCase().includes(exword)
        );
        return test.every(logic => logic === false);
      });
      foundProInputs2 = foundProInputs2.concat(foundProInputs2_temp);
      //     }
      // props.proInputs.sort((a, b) => {
      //   return a._id.localeCompare(b._id);
      // });

      foundProInputs2.sort((a, b) => {
        return a._id.localeCompare(b._id);
      });
    }

    const conv = proInputDate => {
      let day = proInputDate.split(' ').find(element => element.includes('-'));
      if (day) {
        const len = day.split('-')[0].length;
        const firstnumber = day.split('-')[0];
        const secondnumber = day.split('-')[1];
        const thirdnumber = day.split('-')[2];

        if (len === 1 || len === 2) {
          // In the case of like "25-2023-1"
          if (thirdnumber === '1')
            day = `January-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '2')
            day = `Febrary-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '3')
            day = `March-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '4')
            day = `April-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '5')
            day = `May-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '6')
            day = `June-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '7')
            day = `July-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '8')
            day = `August-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '9')
            day = `September-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '10')
            day = `October-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '11')
            day = `November-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '12')
            day = `December-${secondnumber}-${firstnumber}`;
        }
      }

      const time = proInputDate
        .split(' ')
        .find(element => element.includes(':'));

      return day;
    };

    switch (toggledProInputFieldButton) {
      case 'ID':
        if (isProInputIdAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a._id.localeCompare(b._id);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b._id.localeCompare(a._id);
          });
        }
        break;
      case 'DATE':
        if (isProInputDateAscending === false) {
          foundProInputs2.sort((a, b) => {
            return new Date(conv(a.date)) - new Date(conv(b.date));
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return new Date(conv(b.date)) - new Date(conv(a.date));
          });
        }
        break;
      case 'PLACE':
        if (isProInputPlaceAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.place.localeCompare(b.place);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.place.localeCompare(a.place);
          });
        }
        break;
      case 'PERSON':
        if (isProInputPersonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.person.localeCompare(b.person);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.person.localeCompare(a.person);
          });
        }
        break;
      case 'SUBJECT':
        if (isProInputSubjectAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.subject.localeCompare(b.subject);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.subject.localeCompare(a.subject);
          });
        }
        break;
      case 'REASON':
        if (isProInputReasonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.reason.localeCompare(b.reason);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.reason.localeCompare(a.reason);
          });
        }
        break;
      case 'CONDITION1':
        if (isProInputCondition1Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition1
              .replaceAll(',', '')
              .localeCompare(b.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition1
              .replaceAll(',', '')
              .localeCompare(a.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION2':
        if (isProInputCondition2Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition2
              .replaceAll(',', '')
              .localeCompare(b.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition2
              .replaceAll(',', '')
              .localeCompare(a.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION3':
        if (isProInputCondition3Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition3

              .replaceAll(',', '')
              .localeCompare(b.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition3
              .replaceAll(',', '')
              .localeCompare(a.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION4':
        if (isProInputCondition4Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition4
              .replaceAll(',', '')
              .localeCompare(b.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition4
              .replaceAll(',', '')
              .localeCompare(a.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION5':
        if (isProInputCondition5Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition5
              .replaceAll(',', '')
              .localeCompare(b.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition5
              .replaceAll(',', '')
              .localeCompare(a.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION6':
        if (isProInputCondition6Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition6
              .replaceAll(',', '')
              .localeCompare(b.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition6
              .replaceAll(',', '')
              .localeCompare(a.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION7':
        if (isProInputCondition7Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition7
              .replaceAll(',', '')
              .localeCompare(b.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition7
              .replaceAll(',', '')
              .localeCompare(a.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION8':
        if (isProInputCondition8Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition8
              .replaceAll(',', '')
              .localeCompare(b.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition8
              .replaceAll(',', '')
              .localeCompare(a.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION9':
        if (isProInputCondition9Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition9
              .replaceAll(',', '')
              .localeCompare(b.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition9
              .replaceAll(',', '')
              .localeCompare(a.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION10':
        if (isProInputCondition10Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition10
              .replaceAll(',', '')
              .localeCompare(b.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition10
              .replaceAll(',', '')
              .localeCompare(a.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION11':
        if (isProInputCondition11Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition11
              .replaceAll(',', '')
              .localeCompare(b.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition11
              .replaceAll(',', '')
              .localeCompare(a.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION12':
        if (isProInputCondition12Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition12
              .replaceAll(',', '')
              .localeCompare(b.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition12
              .replaceAll(',', '')
              .localeCompare(a.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION13':
        if (isProInputCondition13Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition13
              .replaceAll(',', '')
              .localeCompare(b.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition13
              .replaceAll(',', '')
              .localeCompare(a.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION14':
        if (isProInputCondition14Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition14
              .replaceAll(',', '')
              .localeCompare(b.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition14
              .replaceAll(',', '')
              .localeCompare(a.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION15':
        if (isProInputCondition15Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition15
              .replaceAll(',', '')
              .localeCompare(b.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition15
              .replaceAll(',', '')
              .localeCompare(a.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION16':
        if (isProInputCondition16Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition16
              .replaceAll(',', '')
              .localeCompare(b.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition16
              .replaceAll(',', '')
              .localeCompare(a.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION17':
        if (isProInputCondition17Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition17
              .replaceAll(',', '')
              .localeCompare(b.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition17
              .replaceAll(',', '')
              .localeCompare(a.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION18':
        if (isProInputCondition18Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition18
              .replaceAll(',', '')
              .localeCompare(b.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition18
              .replaceAll(',', '')
              .localeCompare(a.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION19':
        if (isProInputCondition19Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition19
              .replaceAll(',', '')
              .localeCompare(b.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition19
              .replaceAll(',', '')
              .localeCompare(a.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION20':
        if (isProInputCondition20Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition20
              .replaceAll(',', '')
              .localeCompare(b.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition20
              .replaceAll(',', '')
              .localeCompare(a.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'DATA':
        if (isProInputDataAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.data.localeCompare(b.data);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.data.localeCompare(a.data);
          });
        }
        break;
      case 'UNIT':
        if (isProInputUnitAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.unit.localeCompare(b.unit);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.unit.localeCompare(a.unit);
          });
        }
        break;
      default:
        if (isProInputIdAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a._id.localeCompare(b._id);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b._id.localeCompare(a._id);
          });
        }
    }

    function onlyUnique (value, index, array) {
      return array.indexOf(value) === index;
    }
    foundProInputs2 = foundProInputs2.filter(onlyUnique);

    const csvData = foundProInputs2;

    const proInputList = foundProInputs2.map(proInput => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
            isUpdating={props.isUpdating}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    proInput_num = proInputList.length;

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div>
        <Card>
          <Row className='form-group'>
            <Col>
              <CardBody>
                <div className='row'>
                  <div className='col-6'>
                    {/* <h5>{proInput_num} items</h5> */}
                    <Button
                      outline
                      color={
                        isProInputIdAscending === false
                          ? 'primary'
                          : 'secondary'
                      }
                      // color='secondary'
                      onClick={toggleIsProInputIdAscending}
                      // style={{ border: 'none' }}
                    >
                      {proInput_num} items
                    </Button>
                  </div>
                  <div className='col-6'>
                    <CSVLink
                      data={csvData}
                      className='fa fa-arrow-down'
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped>
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputDateAscending}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputPlaceAscending}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputPersonAscending}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputSubjectAscending}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputReasonAscending}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition1Ascending}
                        >
                          c1
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition2Ascending}
                        >
                          c2
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition3Ascending}
                        >
                          c3
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition4Ascending}
                        >
                          c4
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition5Ascending}
                        >
                          c5
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition6Ascending}
                        >
                          c6
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition7Ascending}
                        >
                          c7
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition8Ascending}
                        >
                          c8
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition9Ascending}
                        >
                          c9
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition10Ascending}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition11Ascending}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition12Ascending}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition13Ascending}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition14Ascending}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition15Ascending}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition16Ascending}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition17Ascending}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition18Ascending}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition19Ascending}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition20Ascending}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputDataAscending}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputUnitAscending}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else if (props.proInputs !== null) {
    const proInputList = props.proInputs.map(proInput => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
            isUpdating={props.isUpdating}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    // const toggleDateSort = async () => {
    const conv = proInputDate => {
      let day = proInputDate.split(' ').find(element => element.includes('-'));
      if (day) {
        const len = day.split('-')[0].length;
        const firstnumber = day.split('-')[0];
        const secondnumber = day.split('-')[1];
        const thirdnumber = day.split('-')[2];

        if (len === 1 || len === 2) {
          // In the case of like "25-2023-1"
          if (thirdnumber === '1')
            day = `January-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '2')
            day = `Febrary-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '3')
            day = `March-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '4')
            day = `April-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '5')
            day = `May-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '6')
            day = `June-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '7')
            day = `July-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '8')
            day = `August-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '9')
            day = `September-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '10')
            day = `October-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '11')
            day = `November-${secondnumber}-${firstnumber}`;
          else if (thirdnumber === '12')
            day = `December-${secondnumber}-${firstnumber}`;
        }
      }

      const time = proInputDate
        .split(' ')
        .find(element => element.includes(':'));

      return day;
    };

    switch (toggledProInputFieldButton) {
      case 'ID':
        if (isProInputIdAscending === false) {
          props.proInputs.sort((a, b) => {
            return a._id.localeCompare(b._id);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b._id.localeCompare(a._id);
          });
        }
        break;
      case 'DATE':
        if (isProInputDateAscending === false) {
          props.proInputs.sort((a, b) => {
            return new Date(conv(a.date)) - new Date(conv(b.date));
          });
        } else {
          props.proInputs.sort((a, b) => {
            return new Date(conv(b.date)) - new Date(conv(a.date));
          });
        }
        break;
      case 'PLACE':
        if (isProInputPlaceAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.place.localeCompare(b.place);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.place.localeCompare(a.place);
          });
        }
        break;
      case 'PERSON':
        if (isProInputPersonAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.person.localeCompare(b.person);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.person.localeCompare(a.person);
          });
        }
        break;
      case 'SUBJECT':
        if (isProInputSubjectAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.subject.localeCompare(b.subject);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.subject.localeCompare(a.subject);
          });
        }
        break;
      case 'REASON':
        if (isProInputReasonAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.reason.localeCompare(b.reason);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.reason.localeCompare(a.reason);
          });
        }
        break;
      case 'CONDITION1':
        if (isProInputCondition1Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition1
              .replaceAll(',', '')
              .localeCompare(b.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition1
              .replaceAll(',', '')
              .localeCompare(a.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION2':
        if (isProInputCondition2Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition2
              .replaceAll(',', '')
              .localeCompare(b.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition2
              .replaceAll(',', '')
              .localeCompare(a.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION3':
        if (isProInputCondition3Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition3

              .replaceAll(',', '')
              .localeCompare(b.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition3
              .replaceAll(',', '')
              .localeCompare(a.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION4':
        if (isProInputCondition4Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition4
              .replaceAll(',', '')
              .localeCompare(b.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition4
              .replaceAll(',', '')
              .localeCompare(a.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION5':
        if (isProInputCondition5Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition5
              .replaceAll(',', '')
              .localeCompare(b.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition5
              .replaceAll(',', '')
              .localeCompare(a.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION6':
        if (isProInputCondition6Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition6
              .replaceAll(',', '')
              .localeCompare(b.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition6
              .replaceAll(',', '')
              .localeCompare(a.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION7':
        if (isProInputCondition7Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition7
              .replaceAll(',', '')
              .localeCompare(b.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition7
              .replaceAll(',', '')
              .localeCompare(a.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION8':
        if (isProInputCondition8Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition8
              .replaceAll(',', '')
              .localeCompare(b.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition8
              .replaceAll(',', '')
              .localeCompare(a.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION9':
        if (isProInputCondition9Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition9
              .replaceAll(',', '')
              .localeCompare(b.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition9
              .replaceAll(',', '')
              .localeCompare(a.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION10':
        if (isProInputCondition10Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition10
              .replaceAll(',', '')
              .localeCompare(b.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition10
              .replaceAll(',', '')
              .localeCompare(a.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION11':
        if (isProInputCondition11Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition11
              .replaceAll(',', '')
              .localeCompare(b.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition11
              .replaceAll(',', '')
              .localeCompare(a.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION12':
        if (isProInputCondition12Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition12
              .replaceAll(',', '')
              .localeCompare(b.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition12
              .replaceAll(',', '')
              .localeCompare(a.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION13':
        if (isProInputCondition13Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition13
              .replaceAll(',', '')
              .localeCompare(b.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition13
              .replaceAll(',', '')
              .localeCompare(a.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION14':
        if (isProInputCondition14Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition14
              .replaceAll(',', '')
              .localeCompare(b.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition14
              .replaceAll(',', '')
              .localeCompare(a.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION15':
        if (isProInputCondition15Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition15
              .replaceAll(',', '')
              .localeCompare(b.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition15
              .replaceAll(',', '')
              .localeCompare(a.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION16':
        if (isProInputCondition16Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition16
              .replaceAll(',', '')
              .localeCompare(b.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition16
              .replaceAll(',', '')
              .localeCompare(a.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION17':
        if (isProInputCondition17Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition17
              .replaceAll(',', '')
              .localeCompare(b.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition17
              .replaceAll(',', '')
              .localeCompare(a.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION18':
        if (isProInputCondition18Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition18
              .replaceAll(',', '')
              .localeCompare(b.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition18
              .replaceAll(',', '')
              .localeCompare(a.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION19':
        if (isProInputCondition19Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition19
              .replaceAll(',', '')
              .localeCompare(b.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition19
              .replaceAll(',', '')
              .localeCompare(a.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'CONDITION20':
        if (isProInputCondition20Ascending === false) {
          props.proInputs.sort((a, b) => {
            return a.condition20
              .replaceAll(',', '')
              .localeCompare(b.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.condition20
              .replaceAll(',', '')
              .localeCompare(a.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        }
        break;
      case 'DATA':
        if (isProInputDataAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.data.localeCompare(b.data);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.data.localeCompare(a.data);
          });
        }
        break;
      case 'UNIT':
        if (isProInputUnitAscending === false) {
          props.proInputs.sort((a, b) => {
            return a.unit.localeCompare(b.unit);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b.unit.localeCompare(a.unit);
          });
        }
        break;
      default:
        if (isProInputIdAscending === false) {
          props.proInputs.sort((a, b) => {
            return a._id.localeCompare(b._id);
          });
        } else {
          props.proInputs.sort((a, b) => {
            return b._id.localeCompare(a._id);
          });
        }
    }

    proInput_num = proInputList.length;
    const csvData = props.proInputs;

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div class='table-responsive'>
        <Card>
          <Row className='form-group'>
            <Col>
              <CardBody>
                <div className='row'>
                  <div className='col-6'>
                    {/* <h5>{proInput_num} items</h5> */}
                    <Button
                      outline
                      color={
                        isProInputIdAscending === false
                          ? 'primary'
                          : 'secondary'
                      }
                      // color='secondary'
                      onClick={toggleIsProInputIdAscending}
                      // style={{ border: 'none' }}
                    >
                      {proInput_num} items
                    </Button>
                  </div>
                  <div className='col-6'>
                    <CSVLink
                      data={csvData}
                      className='fa fa-arrow-down'
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped class='table'>
                  {/* <Table bordered responsive hover striped class="tableFixHead"> */}
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputDateAscending}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputPlaceAscending}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputPersonAscending}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputSubjectAscending}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputReasonAscending}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition1Ascending}
                        >
                          c1
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition2Ascending}
                        >
                          c2
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition3Ascending}
                        >
                          c3
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition4Ascending}
                        >
                          c4
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition5Ascending}
                        >
                          c5
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition6Ascending}
                        >
                          c6
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition7Ascending}
                        >
                          c7
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition8Ascending}
                        >
                          c8
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition9Ascending}
                        >
                          c9
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition10Ascending}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition11Ascending}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition12Ascending}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition13Ascending}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition14Ascending}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition15Ascending}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition16Ascending}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition17Ascending}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition18Ascending}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition19Ascending}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputCondition20Ascending}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputDataAscending}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleIsProInputUnitAscending}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else {
    return <div></div>;
  }
}
