/* eslint-disable react/jsx-pascal-case */
import React, { useEffect, Fragment } from 'react';
import { useState } from 'react';
import {
  Card,
  CardBody,
  Button,
  Label,
  Col,
  Row,
  Modal,
  ModalHeader,
  ModalBody,
  Table,
  Fade
} from 'reactstrap';
import { ListGroup, ListGroupItem } from 'reactstrap';
import { Loading } from './LoadingComponent';
import { Control, Form } from 'react-redux-form';
import { CSVLink, CSVDownload } from 'react-csv';
import Pagination from './Pagination';

function RenderProInputTable ({
  proInput,
  deleteProInput,
  updateProInput,
  resetProInputForm,
  auth,
  isUpdating
}) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (value, event) => {
    toggleModal();
    if (window.confirm('OK to change data?')) {
      updateProInput(
        proInput._id,
        value.date,
        value.place,
        value.person,
        value.subject,
        value.reason,
        value.condition1,
        value.condition2,
        value.condition3,
        value.condition4,
        value.condition5,
        value.condition6,
        value.condition7,
        value.condition8,
        value.condition9,
        value.condition10,
        value.condition11,
        value.condition12,
        value.condition13,
        value.condition14,
        value.condition15,
        value.condition16,
        value.condition17,
        value.condition18,
        value.condition19,
        value.condition20,
        value.data,
        value.unit
      );
      // resetProInputForm();
    }
  };

  return (
    <tr>
      <Modal
        isOpen={isOpen}
        toggle={toggleModal}
        size='lg'
        style={{ maxWidth: '1000px', width: '100%' }}
        className='my-modal'
      >
        <ModalHeader toggle={toggleModal}>Update ProInput</ModalHeader>
        <ModalBody>
          <Form onSubmit={handleSubmit} model='proInput'>
            <Row className='form-group mb-2'>
              <Label htmlFor='date'>date</Label>
              <Col sm={10}>
                <Control.text
                  model='.date'
                  id='date'
                  name='date'
                  defaultValue={proInput.date}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='place'>place</Label>
              <Col sm={10}>
                <Control.text
                  model='.place'
                  id='place'
                  name='place'
                  defaultValue={proInput.place}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='person'>person</Label>
              <Col sm={10}>
                <Control.text
                  model='.person'
                  id='person'
                  name='person'
                  defaultValue={proInput.person}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='subject'>subject</Label>
              <Col sm={10}>
                <Control.text
                  model='.subject'
                  id='subject'
                  name='subject'
                  defaultValue={proInput.subject}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label htmlFor='reason'>reason</Label>
              <Col sm={10}>
                <Control.textarea
                  model='.reason'
                  id='reason'
                  name='reason'
                  defaultValue={proInput.reason}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Label>condition</Label>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition1'
                  model='.condition1'
                  id='condition1'
                  name='condition1'
                  defaultValue={proInput.condition1}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition2'
                  model='.condition2'
                  id='condition2'
                  name='condition2'
                  defaultValue={proInput.condition2}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition3'
                  model='.condition3'
                  id='condition3'
                  name='condition3'
                  defaultValue={proInput.condition3}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition4'
                  model='.condition4'
                  id='condition4'
                  name='condition4'
                  defaultValue={proInput.condition4}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition5'
                  model='.condition5'
                  id='condition5'
                  name='condition5'
                  defaultValue={proInput.condition5}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition6'
                  model='.condition6'
                  id='condition6'
                  name='condition6'
                  defaultValue={proInput.condition6}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition7'
                  model='.condition7'
                  id='condition7'
                  name='condition7'
                  defaultValue={proInput.condition7}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition8'
                  model='.condition8'
                  id='condition8'
                  name='condition8'
                  defaultValue={proInput.condition8}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition9'
                  model='.condition9'
                  id='condition9'
                  name='condition9'
                  defaultValue={proInput.condition9}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition10'
                  model='.condition10'
                  id='condition10'
                  name='condition10'
                  defaultValue={proInput.condition10}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition11'
                  model='.condition11'
                  id='condition11'
                  name='condition11'
                  defaultValue={proInput.condition11}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition12'
                  model='.condition12'
                  id='condition12'
                  name='condition12'
                  defaultValue={proInput.condition12}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition13'
                  model='.condition13'
                  id='condition13'
                  name='condition13'
                  defaultValue={proInput.condition13}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition14'
                  model='.condition14'
                  id='condition14'
                  name='condition14'
                  defaultValue={proInput.condition14}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition15'
                  model='.condition15'
                  id='condition15'
                  name='condition15'
                  defaultValue={proInput.condition15}
                  className='form-control'
                />
              </Col>
            </Row>
            <Row className='form-group mb-2'>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition16'
                  model='.condition16'
                  id='condition16'
                  name='condition16'
                  defaultValue={proInput.condition16}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition17'
                  model='.condition17'
                  id='condition17'
                  name='condition17'
                  defaultValue={proInput.condition17}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition18'
                  model='.condition18'
                  id='condition18'
                  name='condition18'
                  defaultValue={proInput.condition18}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition19'
                  model='.condition19'
                  id='condition19'
                  name='condition19'
                  defaultValue={proInput.condition19}
                  className='form-control'
                />
              </Col>
              <Col sm={2}>
                <Control.text
                  htmlFor='condition20'
                  model='.condition20'
                  id='condition20'
                  name='condition20'
                  defaultValue={proInput.condition20}
                  className='form-control'
                />
              </Col>
            </Row>

            <Row className='form-group mb-2'>
              <Label htmlFor='data'>data</Label>
              <Col sm={4}>
                <Control.text
                  model='.data'
                  id='data'
                  name='data'
                  defaultValue={proInput.data}
                  className='form-control'
                />
              </Col>
              {/* </Row>
              <Row className="form-group mb-2"> */}
              <Label htmlFor='unit'>unit</Label>
              <Col sm={4}>
                <Control.text
                  model='.unit'
                  id='unit'
                  name='unit'
                  defaultValue={proInput.unit}
                  className='form-control'
                />
              </Col>
            </Row>
            <Button type='submit' value='submit' color='primary'>
              Submit
            </Button>
          </Form>
        </ModalBody>
      </Modal>

      <td className='sticky-td'>
        {auth.id === proInput.user ? (
          <Button
            outline
            color='primary'
            onClick={toggleModal}
            style={{ border: 'none' }}
          >
            <span className='fa fa-edit'></span>
          </Button>
        ) : (
          <Button outline color='secondary' style={{ border: 'none' }}>
            <span className='fa fa-edit'></span>
          </Button>
        )}
      </td>
      <td>{proInput.date}</td>
      <td>
        {proInput.place.indexOf('http') === 0 ||
        proInput.place.indexOf('/') === 0 ? (
          proInput.place ? (
            proInput.place.indexOf('http') === 0 ? (
              <a href={proInput.place} target='_blank' rel='noreferrer'>
                {0 ? (
                  <span className='fa fa-link'></span>
                ) : proInput.place.indexOf('www') !== -1 ? (
                  // If the first word is 'www', use the second word
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : proInput.place.split('//')[1].split('/')[0].split('.')
                    .length === 2 ? (
                  // otherwise and if domain consists of 2 words, use the first word
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                ) : // otherwise use whichever is longer among the first and second words
                proInput.place.split('//')[1].split('/')[0].split('.')[0]
                    .length <
                  proInput.place.split('//')[1].split('/')[0].split('.')[1]
                    .length ? (
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : (
                  <span>
                    {proInput.place.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                )}
              </a>
            ) : (
              <a
                href={`file:${proInput.place}`}
                target='_blank'
                rel='noreferrer'
              >
                <span className='fa fa-folder-open'></span>
              </a>
            )
          ) : (
            ''
          )
        ) : (
          <code>{proInput.place}</code>
        )}
      </td>
      <td>{proInput.person}</td>
      <td>
        <b>{proInput.subject}</b>
      </td>
      <td>{proInput.reason}</td>
      <td
        style={
          isNaN(proInput.condition1.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition1}
      </td>
      <td
        style={
          isNaN(proInput.condition2.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition2}
      </td>
      <td
        style={
          isNaN(proInput.condition3.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition3}
      </td>
      <td
        style={
          isNaN(proInput.condition4.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition4}
      </td>
      <td
        style={
          isNaN(proInput.condition5.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition5}
      </td>
      <td
        style={
          isNaN(proInput.condition6.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition6}
      </td>
      <td
        style={
          isNaN(proInput.condition7.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition7}
      </td>
      <td
        style={
          isNaN(proInput.condition8.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition8}
      </td>
      <td
        style={
          isNaN(proInput.condition9.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition9}
      </td>
      <td
        style={
          isNaN(proInput.condition10.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition10}
      </td>
      <td
        style={
          isNaN(proInput.condition11.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition11}
      </td>
      <td
        style={
          isNaN(proInput.condition12.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition12}
      </td>
      <td
        style={
          isNaN(proInput.condition13.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition13}
      </td>
      <td
        style={
          isNaN(proInput.condition14.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition14}
      </td>
      <td
        style={
          isNaN(proInput.condition15.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition15}
      </td>
      <td
        style={
          isNaN(proInput.condition16.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition16}
      </td>
      <td
        style={
          isNaN(proInput.condition17.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition17}
      </td>
      <td
        style={
          isNaN(proInput.condition18.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition18}
      </td>
      <td
        style={
          isNaN(proInput.condition19.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition19}
      </td>
      <td
        style={
          isNaN(proInput.condition20.replace(/,/g, ''))
            ? {}
            : { textAlign: 'right' }
        }
      >
        {proInput.condition20}
      </td>
      <td
        style={
          isNaN(proInput.data.replace(/,/g, '')) ? {} : { textAlign: 'right' }
        }
      >
        {proInput.data.indexOf('http') === 0 ||
        proInput.data.indexOf('/') === 0 ? (
          proInput.data ? (
            proInput.data.indexOf('http') === 0 ? (
              <a href={proInput.data} target='_blank' rel='noreferrer'>
                {0 ? (
                  // {0 ? (
                  <span className='fa fa-link'></span>
                ) : proInput.data.indexOf('www') !== -1 ? (
                  // If the first word is 'www', use the second word
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : proInput.data.split('//')[1].split('/')[0].split('.')
                    .length === 2 ? (
                  // otherwise and if domain consists of 2 words, use the first word
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                ) : // otherwise use whichever is longer among the first and second words
                proInput.data.split('//')[1].split('/')[0].split('.')[0]
                    .length <
                  proInput.data.split('//')[1].split('/')[0].split('.')[1]
                    .length ? (
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[1]}
                  </span>
                ) : (
                  <span>
                    {proInput.data.split('//')[1].split('/')[0].split('.')[0]}
                  </span>
                )}
              </a>
            ) : (
              <a
                href={`file:${proInput.data}`}
                target='_blank'
                rel='noreferrer'
              >
                <span className='fa fa-folder-open'></span>
              </a>
            )
          ) : (
            ''
          )
        ) : (
          <code>{proInput.data}</code>
        )}
      </td>
      <td>{proInput.unit}</td>
      <td className='sticky-td'>
        {auth.id === proInput.user ? (
          <Button
            outline
            color='danger'
            disabled={isUpdating} // 2023.11.18
            onClick={() => {
              if (window.confirm('Are you sure?')) deleteProInput(proInput._id);
            }}
            style={{ border: 'none' }}
          >
            <span className='fa fa-times'></span>
          </Button>
        ) : (
          <span></span>
        )}
      </td>
    </tr>
  );
}

export let proInput_num;

export default function ListData (props) {
  // const searchDone = (display) => {
  //   setDisplay(display);
  // };

  const [isDateAscending, setIsDateAscending] = useState(true);
  const [isPlaceAscending, setIsPlaceAscending] = useState(true);
  const [isPersonAscending, setIsPersonAscending] = useState(true);
  const [isSubjectAscending, setIsSubjectAscending] = useState(true);
  const [isReasonAscending, setIsReasonAscending] = useState(true);
  const [isCondition1Ascending, setIsCondition1Ascending] = useState(true);
  const [isCondition2Ascending, setIsCondition2Ascending] = useState(true);
  const [isCondition3Ascending, setIsCondition3Ascending] = useState(true);
  const [isCondition4Ascending, setIsCondition4Ascending] = useState(true);
  const [isCondition5Ascending, setIsCondition5Ascending] = useState(true);
  const [isCondition6Ascending, setIsCondition6Ascending] = useState(true);
  const [isCondition7Ascending, setIsCondition7Ascending] = useState(true);
  const [isCondition8Ascending, setIsCondition8Ascending] = useState(true);
  const [isCondition9Ascending, setIsCondition9Ascending] = useState(true);
  const [isCondition10Ascending, setIsCondition10Ascending] = useState(true);
  const [isCondition11Ascending, setIsCondition11Ascending] = useState(true);
  const [isCondition12Ascending, setIsCondition12Ascending] = useState(true);
  const [isCondition13Ascending, setIsCondition13Ascending] = useState(true);
  const [isCondition14Ascending, setIsCondition14Ascending] = useState(true);
  const [isCondition15Ascending, setIsCondition15Ascending] = useState(true);
  const [isCondition16Ascending, setIsCondition16Ascending] = useState(true);
  const [isCondition17Ascending, setIsCondition17Ascending] = useState(true);
  const [isCondition18Ascending, setIsCondition18Ascending] = useState(true);
  const [isCondition19Ascending, setIsCondition19Ascending] = useState(true);
  const [isCondition20Ascending, setIsCondition20Ascending] = useState(true);
  const [isDataAscending, setIsDataAscending] = useState(true);
  const [isUnitAscending, setIsUnitAscending] = useState(true);
  const [isAnyFieldBtnPushed, setIsAnyFieldBtnPushed] = useState(false);

  const [isDateBtnPushed, setIsDateBtnPushed] = useState(false);
  const [isPlaceBtnPushed, setIsPlaceBtnPushed] = useState(false);
  const [isPersonBtnPushed, setIsPersonBtnPushed] = useState(false);
  const [isSubjectBtnPushed, setIsSubjectBtnPushed] = useState(false);
  const [isReasonBtnPushed, setIsReasonBtnPushed] = useState(false);
  const [isCondition1BtnPushed, setIsCondition1BtnPushed] = useState(false);
  const [isCondition2BtnPushed, setIsCondition2BtnPushed] = useState(false);
  const [isCondition3BtnPushed, setIsCondition3BtnPushed] = useState(false);
  const [isCondition4BtnPushed, setIsCondition4BtnPushed] = useState(false);
  const [isCondition5BtnPushed, setIsCondition5BtnPushed] = useState(false);
  const [isCondition6BtnPushed, setIsCondition6BtnPushed] = useState(false);
  const [isCondition7BtnPushed, setIsCondition7BtnPushed] = useState(false);
  const [isCondition8BtnPushed, setIsCondition8BtnPushed] = useState(false);
  const [isCondition9BtnPushed, setIsCondition9BtnPushed] = useState(false);
  const [isCondition10BtnPushed, setIsCondition10BtnPushed] = useState(false);
  const [isCondition11BtnPushed, setIsCondition11BtnPushed] = useState(false);
  const [isCondition12BtnPushed, setIsCondition12BtnPushed] = useState(false);
  const [isCondition13BtnPushed, setIsCondition13BtnPushed] = useState(false);
  const [isCondition14BtnPushed, setIsCondition14BtnPushed] = useState(false);
  const [isCondition15BtnPushed, setIsCondition15BtnPushed] = useState(false);
  const [isCondition16BtnPushed, setIsCondition16BtnPushed] = useState(false);
  const [isCondition17BtnPushed, setIsCondition17BtnPushed] = useState(false);
  const [isCondition18BtnPushed, setIsCondition18BtnPushed] = useState(false);
  const [isCondition19BtnPushed, setIsCondition19BtnPushed] = useState(false);
  const [isCondition20BtnPushed, setIsCondition20BtnPushed] = useState(false);
  const [isDataBtnPushed, setIsDataBtnPushed] = useState(false);
  const [isUnitBtnPushed, setIsUnitBtnPushed] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [proInputListPerPage] = useState(1000);

  const paginate = pageNumber => setCurrentPage(pageNumber);

  if (props.isLoading) {
    return (
      <div className='container'>
        <div className='row'>
          <Loading />
        </div>
      </div>
    );
  } else if (props.errMess) {
    return (
      <div className='container'>
        <div className='row'>
          <h4>{props.errMess}</h4>
        </div>
      </div>
    );
  } else if (props.keyword !== '') {
    // console.log('setIsKeywordChanged is now ', setIsKeywordChanged);

    const keywordAndArray = props.keyword.split('|');
    var keywords = [];
    var exwords = [];
    for (let k = 0; k < keywordAndArray.length; k++) {
      let keywordArray = keywordAndArray[k].split(/(\s+)/);
      var keywords_temp = [];
      var exwords_temp = [];
      let j = 0;
      let m = 0;
      for (let i = 0; i < keywordArray.length; i++) {
        if ((keywordArray[i] !== ' ') & (keywordArray[i] !== '')) {
          if (keywordArray[i].split('')[0] === '!') {
            exwords_temp[m] = keywordArray[i]
              .toLowerCase()
              .split('')
              .splice(1)
              .join('');
            m = m + 1;
          } else {
            keywords_temp[j] = keywordArray[i].toLowerCase();
            j = j + 1;
          }
        }
      }
      keywords.push(keywords_temp); // OR演算子で分割した各々のキーワード群
      exwords.push(exwords_temp);
    }
    var foundProInputs = [];
    for (let i = 0; i < keywords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs_temp = props.proInputs.filter(curr => {
        const test = keywords[i].map(
          keyword =>
            curr.date.toLowerCase().includes(keyword) ||
            curr.place.toLowerCase().includes(keyword) ||
            curr.person.toLowerCase().includes(keyword) ||
            curr.subject.toLowerCase().includes(keyword) ||
            curr.reason.toLowerCase().includes(keyword) ||
            curr.condition1.toLowerCase().includes(keyword) ||
            curr.condition2.toLowerCase().includes(keyword) ||
            curr.condition3.toLowerCase().includes(keyword) ||
            curr.condition4.toLowerCase().includes(keyword) ||
            curr.condition5.toLowerCase().includes(keyword) ||
            curr.condition6.toLowerCase().includes(keyword) ||
            curr.condition7.toLowerCase().includes(keyword) ||
            curr.condition8.toLowerCase().includes(keyword) ||
            curr.condition9.toLowerCase().includes(keyword) ||
            curr.condition10.toLowerCase().includes(keyword) ||
            curr.condition11.toLowerCase().includes(keyword) ||
            curr.condition12.toLowerCase().includes(keyword) ||
            curr.condition13.toLowerCase().includes(keyword) ||
            curr.condition14.toLowerCase().includes(keyword) ||
            curr.condition15.toLowerCase().includes(keyword) ||
            curr.condition16.toLowerCase().includes(keyword) ||
            curr.condition17.toLowerCase().includes(keyword) ||
            curr.condition18.toLowerCase().includes(keyword) ||
            curr.condition19.toLowerCase().includes(keyword) ||
            curr.condition20.toLowerCase().includes(keyword) ||
            curr.data.toLowerCase().includes(keyword) ||
            curr.unit.toLowerCase().includes(keyword)
        );
        return test.every(logic => logic === true);
      });
      foundProInputs = foundProInputs.concat(foundProInputs_temp);
      //     }
    }
    var foundProInputs2 = [];
    for (let i = 0; i < exwords.length; i++) {
      //     for (let j = 0; j < keywords[i].length; j++) {
      const foundProInputs2_temp = foundProInputs.filter(curr => {
        const test = exwords[i].map(
          exword =>
            curr.date.toLowerCase().includes(exword) ||
            curr.place.toLowerCase().includes(exword) ||
            curr.person.toLowerCase().includes(exword) ||
            curr.subject.toLowerCase().includes(exword) ||
            curr.reason.toLowerCase().includes(exword) ||
            curr.condition1.toLowerCase().includes(exword) ||
            curr.condition2.toLowerCase().includes(exword) ||
            curr.condition3.toLowerCase().includes(exword) ||
            curr.condition4.toLowerCase().includes(exword) ||
            curr.condition5.toLowerCase().includes(exword) ||
            curr.condition6.toLowerCase().includes(exword) ||
            curr.condition7.toLowerCase().includes(exword) ||
            curr.condition8.toLowerCase().includes(exword) ||
            curr.condition9.toLowerCase().includes(exword) ||
            curr.condition10.toLowerCase().includes(exword) ||
            curr.condition11.toLowerCase().includes(exword) ||
            curr.condition12.toLowerCase().includes(exword) ||
            curr.condition13.toLowerCase().includes(exword) ||
            curr.condition14.toLowerCase().includes(exword) ||
            curr.condition15.toLowerCase().includes(exword) ||
            curr.condition16.toLowerCase().includes(exword) ||
            curr.condition17.toLowerCase().includes(exword) ||
            curr.condition18.toLowerCase().includes(exword) ||
            curr.condition19.toLowerCase().includes(exword) ||
            curr.condition20.toLowerCase().includes(exword) ||
            curr.data.toLowerCase().includes(exword) ||
            curr.unit.toLowerCase().includes(exword)
        );
        return test.every(logic => logic === false);
      });
      foundProInputs2 = foundProInputs2.concat(foundProInputs2_temp);
      //     }
      props.proInputs.sort((a, b) => {
        return a._id.localeCompare(b._id);
      });
    }

    // const first = 'Format';
    // foundProInputs2.sort(
    //   (a, b) =>
    //     (b.person.indexOf(first) === 0) - (b.person.indexOf(first) === 0)
    // );

    // 2023.5.5
    // Field buttons didn't work upon listing search result because it is always
    // overwritten by the sort here. So added this condition to not execute it
    // if one of the buttons are being pushed

    // console.log('isAnyFieldBtnPushed is ', isAnyFieldBtnPushed);
    // console.log('isPlaceAscending is ', isPlaceAscending);

    if (
      // isDateAscending &
      // isPlaceAscending &
      // isPersonAscending &
      // isSubjectAscending &
      // isReasonAscending &
      // isConditionAscending &
      // isDataAscending &
      // isUnitAscending
      !isAnyFieldBtnPushed
    ) {
      props.proInputs.sort((a, b) => {
        return a._id.localeCompare(b._id);
      });
    } else {
      if (isDateBtnPushed) {
        const conv = proInputDate => {
          let day = proInputDate
            .split(' ')
            .find(element => element.includes('-'));
          if (day) {
            const len = day.split('-')[0].length;
            const firstnumber = day.split('-')[0];
            const secondnumber = day.split('-')[1];
            const thirdnumber = day.split('-')[2];

            if (len === 1 || len === 2) {
              // In the case of like "25-2023-1"
              if (thirdnumber === '1')
                day = `January-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '2')
                day = `Febrary-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '3')
                day = `March-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '4')
                day = `April-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '5')
                day = `May-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '6')
                day = `June-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '7')
                day = `July-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '8')
                day = `August-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '9')
                day = `September-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '10')
                day = `October-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '11')
                day = `November-${secondnumber}-${firstnumber}`;
              else if (thirdnumber === '12')
                day = `December-${secondnumber}-${firstnumber}`;
            }
          }

          const time = proInputDate
            .split(' ')
            .find(element => element.includes(':'));

          return day;
        };
        if (isDateAscending === false) {
          foundProInputs2.sort((a, b) => {
            // return a.date.localeCompare(b.date);
            return new Date(conv(a.date)) - new Date(conv(b.date));
          });
        } else {
          foundProInputs2.sort((a, b) => {
            // return a.date.localeCompare(b.date).reverse();
            return new Date(conv(b.date)) - new Date(conv(a.date));
          });
        }
      } else if (isPlaceBtnPushed) {
        if (isPlaceAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.place.localeCompare(b.place);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.place.localeCompare(a.place);
          });
        }
        // setIsPlaceBtnPushed(false);
      } else if (isPersonBtnPushed) {
        if (isPersonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.person.localeCompare(b.person);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.person.localeCompare(a.person);
          });
        }
        // setIsPersonBtnPushed(false);
      } else if (isSubjectBtnPushed) {
        if (isSubjectAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.subject.localeCompare(b.subject);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.subject.localeCompare(a.subject);
          });
        }
        // setIsSubjectBtnPushed(false);
      } else if (isReasonBtnPushed) {
        if (isReasonAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.reason.localeCompare(b.reason);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.reason.localeCompare(a.reason);
          });
        }
      } else if (isCondition1BtnPushed) {
        if (isCondition1Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition1
              .replaceAll(',', '')
              .localeCompare(b.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition1
              .replaceAll(',', '')
              .localeCompare(a.condition1.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition2BtnPushed) {
        if (isCondition2Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition2
              .replaceAll(',', '')
              .localeCompare(b.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition2
              .replaceAll(',', '')
              .localeCompare(a.condition2.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition3BtnPushed) {
        if (isCondition3Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition3
              .replaceAll(',', '')
              .localeCompare(b.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition3
              .replaceAll(',', '')
              .localeCompare(a.condition3.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition4BtnPushed) {
        if (isCondition4Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition4
              .replaceAll(',', '')
              .localeCompare(b.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition4
              .replaceAll(',', '')
              .localeCompare(a.condition4.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition5BtnPushed) {
        if (isCondition5Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition5
              .replaceAll(',', '')
              .localeCompare(b.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition5
              .replaceAll(',', '')
              .localeCompare(a.condition5.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition6BtnPushed) {
        if (isCondition6Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition6
              .replaceAll(',', '')
              .localeCompare(b.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition6
              .replaceAll(',', '')
              .localeCompare(a.condition6.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition7BtnPushed) {
        if (isCondition7Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition7
              .replaceAll(',', '')
              .localeCompare(b.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition7
              .replaceAll(',', '')
              .localeCompare(a.condition7.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition8BtnPushed) {
        if (isCondition8Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition8
              .replaceAll(',', '')
              .localeCompare(b.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition8
              .replaceAll(',', '')
              .localeCompare(a.condition8.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition9BtnPushed) {
        if (isCondition9Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition9
              .replaceAll(',', '')
              .localeCompare(b.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition9
              .replaceAll(',', '')
              .localeCompare(a.condition9.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition10BtnPushed) {
        if (isCondition10Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition10
              .replaceAll(',', '')
              .localeCompare(b.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition10
              .replaceAll(',', '')
              .localeCompare(a.condition10.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition11BtnPushed) {
        if (isCondition11Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition11
              .replaceAll(',', '')
              .localeCompare(b.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition11
              .replaceAll(',', '')
              .localeCompare(a.condition11.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition12BtnPushed) {
        if (isCondition12Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition12
              .replaceAll(',', '')
              .localeCompare(b.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition12
              .replaceAll(',', '')
              .localeCompare(a.condition12.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition13BtnPushed) {
        if (isCondition13Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition13
              .replaceAll(',', '')
              .localeCompare(b.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition13
              .replaceAll(',', '')
              .localeCompare(a.condition13.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition14BtnPushed) {
        if (isCondition14Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition14
              .replaceAll(',', '')
              .localeCompare(b.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition14
              .replaceAll(',', '')
              .localeCompare(a.condition14.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition15BtnPushed) {
        if (isCondition15Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition15
              .replaceAll(',', '')
              .localeCompare(b.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition15
              .replaceAll(',', '')
              .localeCompare(a.condition15.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition16BtnPushed) {
        if (isCondition16Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition16
              .replaceAll(',', '')
              .localeCompare(b.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition16
              .replaceAll(',', '')
              .localeCompare(a.condition16.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition17BtnPushed) {
        if (isCondition17Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition17
              .replaceAll(',', '')
              .localeCompare(b.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition17
              .replaceAll(',', '')
              .localeCompare(a.condition17.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition18BtnPushed) {
        if (isCondition18Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition18
              .replaceAll(',', '')
              .localeCompare(b.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition18
              .replaceAll(',', '')
              .localeCompare(a.condition18.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition19BtnPushed) {
        if (isCondition19Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition19
              .replaceAll(',', '')
              .localeCompare(b.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition19
              .replaceAll(',', '')
              .localeCompare(a.condition19.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isCondition20BtnPushed) {
        if (isCondition20Ascending === false) {
          foundProInputs2.sort((a, b) => {
            return a.condition20
              .replaceAll(',', '')
              .localeCompare(b.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.condition20
              .replaceAll(',', '')
              .localeCompare(a.condition20.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isDataBtnPushed) {
        if (isDataAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.data
              .replaceAll(',', '')
              .localeCompare(b.data.replaceAll(',', ''), undefined, {
                numeric: true
              });
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.data
              .replaceAll(',', '')
              .localeCompare(a.data.replaceAll(',', ''), undefined, {
                numeric: true
              });
            // .reverse();
          });
        }
      } else if (isUnitBtnPushed) {
        if (isUnitAscending === false) {
          foundProInputs2.sort((a, b) => {
            return a.unit.localeCompare(b.unit);
          });
        } else {
          foundProInputs2.sort((a, b) => {
            return b.unit.localeCompare(a.unit);
          });
        }
      }
    }

    function onlyUnique (value, index, array) {
      return array.indexOf(value) === index;
    }
    foundProInputs2 = foundProInputs2.filter(onlyUnique);

    const csvData = foundProInputs2;

    const proInputList = foundProInputs2.map(proInput => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
            isUpdating={props.isUpdating}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    const toggleDateSort = async () => {
      setIsDateAscending(!isDateAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(true);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const togglePlaceSort = () => {
      setIsPlaceAscending(!isPlaceAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(true);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const togglePersonSort = () => {
      setIsPersonAscending(!isPersonAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(true);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleSubjectSort = () => {
      setIsSubjectAscending(!isSubjectAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(true);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleReasonSort = () => {
      setIsReasonAscending(!isReasonAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(true);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition1Sort = () => {
      setIsCondition1Ascending(!isCondition1Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(true);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition2Sort = () => {
      setIsCondition2Ascending(!isCondition2Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(true);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition3Sort = () => {
      setIsCondition3Ascending(!isCondition3Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(true);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition4Sort = () => {
      setIsCondition4Ascending(!isCondition4Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(true);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition5Sort = () => {
      setIsCondition5Ascending(!isCondition5Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(true);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition6Sort = () => {
      setIsCondition6Ascending(!isCondition6Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(true);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition7Sort = () => {
      setIsCondition7Ascending(!isCondition7Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(true);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition8Sort = () => {
      setIsCondition8Ascending(!isCondition8Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(true);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition9Sort = () => {
      setIsCondition9Ascending(!isCondition9Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(true);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition10Sort = () => {
      setIsCondition10Ascending(!isCondition10Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(true);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition11Sort = () => {
      setIsCondition11Ascending(!isCondition11Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(true);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition12Sort = () => {
      setIsCondition12Ascending(!isCondition12Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(true);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition13Sort = () => {
      setIsCondition13Ascending(!isCondition13Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(true);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition14Sort = () => {
      setIsCondition14Ascending(!isCondition14Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(true);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition15Sort = () => {
      setIsCondition15Ascending(!isCondition15Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(true);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition16Sort = () => {
      setIsCondition16Ascending(!isCondition16Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(true);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition17Sort = () => {
      setIsCondition17Ascending(!isCondition17Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(true);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition18Sort = () => {
      setIsCondition18Ascending(!isCondition18Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(true);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition19Sort = () => {
      setIsCondition19Ascending(!isCondition19Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(true);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleCondition20Sort = () => {
      setIsCondition20Ascending(!isCondition20Ascending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(true);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(false);
    };

    const toggleDataSort = () => {
      setIsDataAscending(!isDataAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(true);
      setIsUnitBtnPushed(false);
    };

    const toggleUnitSort = () => {
      setIsUnitAscending(!isUnitAscending);
      setIsAnyFieldBtnPushed(true);
      setIsDateBtnPushed(false);
      setIsPlaceBtnPushed(false);
      setIsPersonBtnPushed(false);
      setIsSubjectBtnPushed(false);
      setIsReasonBtnPushed(false);
      setIsCondition1BtnPushed(false);
      setIsCondition2BtnPushed(false);
      setIsCondition3BtnPushed(false);
      setIsCondition4BtnPushed(false);
      setIsCondition5BtnPushed(false);
      setIsCondition6BtnPushed(false);
      setIsCondition7BtnPushed(false);
      setIsCondition8BtnPushed(false);
      setIsCondition9BtnPushed(false);
      setIsCondition10BtnPushed(false);
      setIsCondition11BtnPushed(false);
      setIsCondition12BtnPushed(false);
      setIsCondition13BtnPushed(false);
      setIsCondition14BtnPushed(false);
      setIsCondition15BtnPushed(false);
      setIsCondition16BtnPushed(false);
      setIsCondition17BtnPushed(false);
      setIsCondition18BtnPushed(false);
      setIsCondition19BtnPushed(false);
      setIsCondition20BtnPushed(false);
      setIsDataBtnPushed(false);
      setIsUnitBtnPushed(true);
    };

    proInput_num = proInputList.length;

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div>
        <Card>
          <Row className='form-group'>
            <Col>
              <CardBody>
                <div className='row'>
                  <div className='col-6'>
                    <h5>{proInput_num} items</h5>
                  </div>
                  <div className='col-6'>
                    <CSVLink
                      data={csvData}
                      className='fa fa-arrow-down'
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped>
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleDateSort}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={togglePlaceSort}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={togglePersonSort}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleSubjectSort}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleReasonSort}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition1Sort}
                        >
                          c1
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition2Sort}
                        >
                          c2
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition3Sort}
                        >
                          c3
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition4Sort}
                        >
                          c4
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition5Sort}
                        >
                          c5
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition6Sort}
                        >
                          c6
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition7Sort}
                        >
                          c7
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition8Sort}
                        >
                          c8
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition9Sort}
                        >
                          c9
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition10Sort}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition11Sort}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition12Sort}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition13Sort}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition14Sort}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition15Sort}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition16Sort}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition17Sort}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition18Sort}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition19Sort}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition20Sort}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleDataSort}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleUnitSort}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else if (props.proInputs !== null) {
    const proInputList = props.proInputs.map(proInput => {
      return (
        <Fragment>
          <RenderProInputTable
            proInput={proInput}
            deleteProInput={props.deleteProInput}
            updateProInput={props.updateProInput}
            resetProInputForm={props.resetProInputForm}
            auth={props.auth}
            isUpdating={props.isUpdating}
          />
          {/* </div> */}
        </Fragment>
      );
    });

    const toggleDateSort = async () => {
      const conv = proInputDate => {
        let day = proInputDate
          .split(' ')
          .find(element => element.includes('-'));
        if (day) {
          const len = day.split('-')[0].length;
          const firstnumber = day.split('-')[0];
          const secondnumber = day.split('-')[1];
          const thirdnumber = day.split('-')[2];

          if (len === 1 || len === 2) {
            // In the case of like "25-2023-1"
            if (thirdnumber === '1')
              day = `January-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '2')
              day = `Febrary-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '3')
              day = `March-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '4')
              day = `April-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '5')
              day = `May-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '6')
              day = `June-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '7')
              day = `July-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '8')
              day = `August-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '9')
              day = `September-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '10')
              day = `October-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '11')
              day = `November-${secondnumber}-${firstnumber}`;
            else if (thirdnumber === '12')
              day = `December-${secondnumber}-${firstnumber}`;
          }
        }

        const time = proInputDate
          .split(' ')
          .find(element => element.includes(':'));

        return day;
      };

      if (isDateAscending === false) {
        props.proInputs.sort((a, b) => {
          // return a.date.localeCompare(b.date);
          return new Date(conv(a.date)) - new Date(conv(b.date));
        });
      } else {
        props.proInputs.sort((a, b) => {
          // return a.date.localeCompare(b.date).reverse();
          return new Date(conv(b.date)) - new Date(conv(a.date));
        });
      }
      setIsDateAscending(!isDateAscending);
    };

    const togglePlaceSort = () => {
      setIsPlaceAscending(!isPlaceAscending);

      if (isPlaceAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.place.localeCompare(b.place);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.place.localeCompare(b.place).reverse();
        });
      }
    };

    const togglePersonSort = () => {
      setIsPersonAscending(!isPersonAscending);

      if (isPersonAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.person.localeCompare(b.person);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.person.localeCompare(b.person).reverse();
        });
      }
    };

    const toggleSubjectSort = () => {
      setIsSubjectAscending(!isSubjectAscending);

      if (isSubjectAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.subject.localeCompare(b.subject);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.subject.localeCompare(b.subject).reverse();
        });
      }
    };

    const toggleReasonSort = () => {
      setIsReasonAscending(!isReasonAscending);

      if (isReasonAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.reason.localeCompare(b.reason);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.reason.localeCompare(b.reason).reverse();
        });
      }
    };

    const toggleCondition1Sort = () => {
      setIsCondition1Ascending(!isCondition1Ascending);
      if (isCondition1Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition1.replaceAll(',', '').localeCompare(
            b.condition1.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition1
            .replaceAll(',', '')
            .localeCompare(
              b.condition1.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition2Sort = () => {
      setIsCondition2Ascending(!isCondition2Ascending);
      if (isCondition2Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition2.replaceAll(',', '').localeCompare(
            b.condition2.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition2
            .replaceAll(',', '')
            .localeCompare(
              b.condition2.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition3Sort = () => {
      setIsCondition3Ascending(!isCondition3Ascending);
      if (isCondition3Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition3.replaceAll(',', '').localeCompare(
            b.condition3.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition3
            .replaceAll(',', '')
            .localeCompare(
              b.condition3.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition4Sort = () => {
      setIsCondition4Ascending(!isCondition4Ascending);
      if (isCondition4Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition4.replaceAll(',', '').localeCompare(
            b.condition4.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition4
            .replaceAll(',', '')
            .localeCompare(
              b.condition4.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition5Sort = () => {
      setIsCondition5Ascending(!isCondition5Ascending);
      if (isCondition5Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition5.replaceAll(',', '').localeCompare(
            b.condition5.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition5
            .replaceAll(',', '')
            .localeCompare(
              b.condition5.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition6Sort = () => {
      setIsCondition6Ascending(!isCondition6Ascending);
      if (isCondition6Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition6.replaceAll(',', '').localeCompare(
            b.condition6.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition6
            .replaceAll(',', '')
            .localeCompare(
              b.condition6.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition7Sort = () => {
      setIsCondition7Ascending(!isCondition7Ascending);
      if (isCondition7Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition7.replaceAll(',', '').localeCompare(
            b.condition7.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition7
            .replaceAll(',', '')
            .localeCompare(
              b.condition7.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition8Sort = () => {
      setIsCondition8Ascending(!isCondition8Ascending);
      if (isCondition8Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition8.replaceAll(',', '').localeCompare(
            b.condition8.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition8
            .replaceAll(',', '')
            .localeCompare(
              b.condition8.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition9Sort = () => {
      setIsCondition9Ascending(!isCondition9Ascending);
      if (isCondition9Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition9.replaceAll(',', '').localeCompare(
            b.condition9.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition9
            .replaceAll(',', '')
            .localeCompare(
              b.condition9.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition10Sort = () => {
      setIsCondition10Ascending(!isCondition10Ascending);
      if (isCondition10Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition10.replaceAll(',', '').localeCompare(
            b.condition10.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition10
            .replaceAll(',', '')
            .localeCompare(
              b.condition10.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition11Sort = () => {
      setIsCondition11Ascending(!isCondition11Ascending);
      if (isCondition11Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition11.replaceAll(',', '').localeCompare(
            b.condition11.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition11
            .replaceAll(',', '')
            .localeCompare(
              b.condition11.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition12Sort = () => {
      setIsCondition12Ascending(!isCondition12Ascending);
      if (isCondition12Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition12.replaceAll(',', '').localeCompare(
            b.condition12.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition12
            .replaceAll(',', '')
            .localeCompare(
              b.condition12.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition13Sort = () => {
      setIsCondition13Ascending(!isCondition13Ascending);
      if (isCondition13Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition13.replaceAll(',', '').localeCompare(
            b.condition13.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition13
            .replaceAll(',', '')
            .localeCompare(
              b.condition13.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition14Sort = () => {
      setIsCondition14Ascending(!isCondition14Ascending);
      if (isCondition14Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition14.replaceAll(',', '').localeCompare(
            b.condition14.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition14
            .replaceAll(',', '')
            .localeCompare(
              b.condition14.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition15Sort = () => {
      setIsCondition15Ascending(!isCondition15Ascending);
      if (isCondition15Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition15.replaceAll(',', '').localeCompare(
            b.condition15.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition15
            .replaceAll(',', '')
            .localeCompare(
              b.condition15.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition16Sort = () => {
      setIsCondition16Ascending(!isCondition16Ascending);
      if (isCondition16Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition16.replaceAll(',', '').localeCompare(
            b.condition16.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition16
            .replaceAll(',', '')
            .localeCompare(
              b.condition16.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition17Sort = () => {
      setIsCondition17Ascending(!isCondition17Ascending);
      if (isCondition17Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition17.replaceAll(',', '').localeCompare(
            b.condition17.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition17
            .replaceAll(',', '')
            .localeCompare(
              b.condition17.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition18Sort = () => {
      setIsCondition18Ascending(!isCondition18Ascending);
      if (isCondition18Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition18.replaceAll(',', '').localeCompare(
            b.condition18.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition18
            .replaceAll(',', '')
            .localeCompare(
              b.condition18.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition19Sort = () => {
      setIsCondition19Ascending(!isCondition19Ascending);
      if (isCondition19Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition19.replaceAll(',', '').localeCompare(
            b.condition19.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition19
            .replaceAll(',', '')
            .localeCompare(
              b.condition19.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleCondition20Sort = () => {
      setIsCondition20Ascending(!isCondition20Ascending);
      if (isCondition20Ascending === false) {
        props.proInputs.sort((a, b) => {
          return a.condition20.replaceAll(',', '').localeCompare(
            b.condition20.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.condition20
            .replaceAll(',', '')
            .localeCompare(
              b.condition20.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleDataSort = () => {
      setIsDataAscending(!isDataAscending);

      if (isDataAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.data.replaceAll(',', '').localeCompare(
            b.data.replaceAll(',', ''),
            // 'en-u-kn-true'
            undefined,
            { numeric: true }
            // { ignorePunctuation: true }
          );
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.data
            .replaceAll(',', '')
            .localeCompare(
              b.data.replaceAll(',', ''),
              // 'en-u-kn-true'
              undefined,
              { numeric: true }
              // { ignorePunctuation: true }
            )
            .reverse();
        });
      }
    };

    const toggleUnitSort = () => {
      setIsUnitAscending(!isUnitAscending);

      if (isUnitAscending === false) {
        props.proInputs.sort((a, b) => {
          return a.unit.localeCompare(b.unit);
        });
      } else {
        props.proInputs.reverse((a, b) => {
          return a.unit.localeCompare(b.unit).reverse();
        });
      }
    };

    proInput_num = proInputList.length;
    const csvData = props.proInputs;

    // Get current posts
    const indexOfLastProInputList = currentPage * proInputListPerPage;
    const indexOfFirstProInputList =
      indexOfLastProInputList - proInputListPerPage;
    const currentProInputList = proInputList
      .reverse()
      .slice(indexOfFirstProInputList, indexOfLastProInputList);

    return (
      <div class='table-responsive'>
        <Card>
          <Row className='form-group'>
            <Col>
              <CardBody>
                <div className='row'>
                  <div className='col-6'>
                    <h5>{proInput_num} items</h5>
                  </div>
                  <div className='col-6'>
                    <CSVLink
                      data={csvData}
                      className='fa fa-arrow-down'
                    ></CSVLink>
                  </div>
                </div>
                <Table bordered responsive hover striped class='table'>
                  {/* <Table bordered responsive hover striped class="tableFixHead"> */}
                  <thead>
                    <tr>
                      <th></th> {/* for Edit */}
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleDateSort}
                        >
                          date
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={togglePlaceSort}
                        >
                          place
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={togglePersonSort}
                        >
                          person
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleSubjectSort}
                        >
                          subject
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleReasonSort}
                        >
                          reason
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition1Sort}
                        >
                          c01
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition2Sort}
                        >
                          c02
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition3Sort}
                        >
                          c03
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition4Sort}
                        >
                          c04
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition5Sort}
                        >
                          c05
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition6Sort}
                        >
                          c06
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition7Sort}
                        >
                          c07
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition8Sort}
                        >
                          c08
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition9Sort}
                        >
                          c09
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition10Sort}
                        >
                          c10
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition11Sort}
                        >
                          c11
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition12Sort}
                        >
                          c12
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition13Sort}
                        >
                          c13
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition14Sort}
                        >
                          c14
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition15Sort}
                        >
                          c15
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition16Sort}
                        >
                          c16
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition17Sort}
                        >
                          c17
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition18Sort}
                        >
                          c18
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition19Sort}
                        >
                          c19
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleCondition20Sort}
                        >
                          c20
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleDataSort}
                        >
                          data
                        </Button>
                      </th>
                      <th>
                        <Button
                          outline
                          color='secondary'
                          onClick={toggleUnitSort}
                        >
                          unit
                        </Button>
                      </th>
                      <th></th> {/* for Delete */}
                    </tr>
                  </thead>
                  <tbody>{currentProInputList}</tbody>
                </Table>
              </CardBody>
            </Col>
          </Row>
        </Card>
        <Pagination
          proInputListPerPage={proInputListPerPage}
          totalProInputList={proInputList.length}
          paginate={paginate}
        />
      </div>
    );
  } else {
    return <div></div>;
  }
}
