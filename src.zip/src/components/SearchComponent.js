import React, { Component, useState, Fragment } from 'react';
import ListKirk from './ListKirkComponent';
// import { XIcon } from '@heroicons/react/solid';
// import { Input } from 'semantic-ui-react';

export default function Search({ findKirks }) {
  const [keyword, setKeyword] = useState('');
  // const [value, setValue] = useState('')

  const handleChange = (event) => {
    // event.preventDefault();
    setKeyword(event.target.value);
    setTimeout(() => findKirks(event.target.value), 500);
    // findKirks(event.target.value);
  };
  return (
    <Fragment>
      {/* <form onSubmit={handleSubmit}> */}
      {/* <form> */}
      <input
        // icon="search"
        type="search"
        id="keyword"
        // autocorrect="off"
        name="keyword"
        value={keyword}
        // onChange={() => findKirks()}
        onChange={handleChange}
        placeholder="Search..."
        size="15"
        // size="20"
      />
      {/* <input type="submit" value="Submit" /> */}
      {/* {keyword && <span className="h-5">x</span>} */}
      {/* </form> */}
    </Fragment>
  );
}
